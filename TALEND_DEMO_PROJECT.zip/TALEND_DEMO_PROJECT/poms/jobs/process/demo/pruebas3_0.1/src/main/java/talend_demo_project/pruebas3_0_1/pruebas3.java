
package talend_demo_project.pruebas3_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: pruebas3 Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 7.3.1.20200219_1130
 * @status
 */
public class pruebas3 implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "pruebas3.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager.getLogger(pruebas3.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "pruebas3";
	private final String projectName = "TALEND_DEMO_PROJECT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_cVIWQJbuEeun1OgscY9O6g", "0.1");
	org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					pruebas3.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(pruebas3.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_4_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDataStewardshipTaskOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMatchGroup_1_GroupOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tMatchGroup_1_GroupIn_error(exception, errorComponent, globalMap);

	}

	public void tMatchGroup_1_GroupIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tSortRow_1_SortOut_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		tSortRow_1_SortIn_error(exception, errorComponent, globalMap);

	}

	public void tSortRow_1_SortIn_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class row11_0Struct implements routines.system.IPersistableRow<row11_0Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int Id_Result;

		public int getId_Result() {
			return this.Id_Result;
		}

		public int Id_Driver;

		public int getId_Driver() {
			return this.Id_Driver;
		}

		public int Id_Constructor;

		public int getId_Constructor() {
			return this.Id_Constructor;
		}

		public int Id_Race;

		public int getId_Race() {
			return this.Id_Race;
		}

		public int Id_circuit;

		public int getId_circuit() {
			return this.Id_circuit;
		}

		public int Id_Status;

		public int getId_Status() {
			return this.Id_Status;
		}

		public String DriverRef;

		public String getDriverRef() {
			return this.DriverRef;
		}

		public String DriverNumber;

		public String getDriverNumber() {
			return this.DriverNumber;
		}

		public String Code;

		public String getCode() {
			return this.Code;
		}

		public String Forename;

		public String getForename() {
			return this.Forename;
		}

		public String Surname;

		public String getSurname() {
			return this.Surname;
		}

		public String Dob;

		public String getDob() {
			return this.Dob;
		}

		public String Nationality;

		public String getNationality() {
			return this.Nationality;
		}

		public int Number;

		public int getNumber() {
			return this.Number;
		}

		public int Grid;

		public int getGrid() {
			return this.Grid;
		}

		public int Position;

		public int getPosition() {
			return this.Position;
		}

		public String PositionText;

		public String getPositionText() {
			return this.PositionText;
		}

		public String PositionOrder;

		public String getPositionOrder() {
			return this.PositionOrder;
		}

		public String Points;

		public String getPoints() {
			return this.Points;
		}

		public String Laps;

		public String getLaps() {
			return this.Laps;
		}

		public String Time;

		public String getTime() {
			return this.Time;
		}

		public String Milliseconds;

		public String getMilliseconds() {
			return this.Milliseconds;
		}

		public String FastestLap;

		public String getFastestLap() {
			return this.FastestLap;
		}

		public String Rank;

		public String getRank() {
			return this.Rank;
		}

		public String FastestLapTime;

		public String getFastestLapTime() {
			return this.FastestLapTime;
		}

		public String FastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.FastestLapSpeed;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String RaceName;

		public String getRaceName() {
			return this.RaceName;
		}

		public int RaceYear;

		public int getRaceYear() {
			return this.RaceYear;
		}

		public int Round;

		public int getRound() {
			return this.Round;
		}

		public String RaceDate;

		public String getRaceDate() {
			return this.RaceDate;
		}

		public String RaceTime;

		public String getRaceTime() {
			return this.RaceTime;
		}

		public String CircuitRef;

		public String getCircuitRef() {
			return this.CircuitRef;
		}

		public String CircuitName;

		public String getCircuitName() {
			return this.CircuitName;
		}

		public String CircuitLocation;

		public String getCircuitLocation() {
			return this.CircuitLocation;
		}

		public String CircuitCountry;

		public String getCircuitCountry() {
			return this.CircuitCountry;
		}

		public String Lat;

		public String getLat() {
			return this.Lat;
		}

		public String Lng;

		public String getLng() {
			return this.Lng;
		}

		public String Alt;

		public String getAlt() {
			return this.Alt;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.Id_Result = dis.readInt();

					this.Id_Driver = dis.readInt();

					this.Id_Constructor = dis.readInt();

					this.Id_Race = dis.readInt();

					this.Id_circuit = dis.readInt();

					this.Id_Status = dis.readInt();

					this.DriverRef = readString(dis);

					this.DriverNumber = readString(dis);

					this.Code = readString(dis);

					this.Forename = readString(dis);

					this.Surname = readString(dis);

					this.Dob = readString(dis);

					this.Nationality = readString(dis);

					this.Number = dis.readInt();

					this.Grid = dis.readInt();

					this.Position = dis.readInt();

					this.PositionText = readString(dis);

					this.PositionOrder = readString(dis);

					this.Points = readString(dis);

					this.Laps = readString(dis);

					this.Time = readString(dis);

					this.Milliseconds = readString(dis);

					this.FastestLap = readString(dis);

					this.Rank = readString(dis);

					this.FastestLapTime = readString(dis);

					this.FastestLapSpeed = readString(dis);

					this.FastLapandTime = readString(dis);

					this.RaceName = readString(dis);

					this.RaceYear = dis.readInt();

					this.Round = dis.readInt();

					this.RaceDate = readString(dis);

					this.RaceTime = readString(dis);

					this.CircuitRef = readString(dis);

					this.CircuitName = readString(dis);

					this.CircuitLocation = readString(dis);

					this.CircuitCountry = readString(dis);

					this.Lat = readString(dis);

					this.Lng = readString(dis);

					this.Alt = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Id_Result);

				// int

				dos.writeInt(this.Id_Driver);

				// int

				dos.writeInt(this.Id_Constructor);

				// int

				dos.writeInt(this.Id_Race);

				// int

				dos.writeInt(this.Id_circuit);

				// int

				dos.writeInt(this.Id_Status);

				// String

				writeString(this.DriverRef, dos);

				// String

				writeString(this.DriverNumber, dos);

				// String

				writeString(this.Code, dos);

				// String

				writeString(this.Forename, dos);

				// String

				writeString(this.Surname, dos);

				// String

				writeString(this.Dob, dos);

				// String

				writeString(this.Nationality, dos);

				// int

				dos.writeInt(this.Number);

				// int

				dos.writeInt(this.Grid);

				// int

				dos.writeInt(this.Position);

				// String

				writeString(this.PositionText, dos);

				// String

				writeString(this.PositionOrder, dos);

				// String

				writeString(this.Points, dos);

				// String

				writeString(this.Laps, dos);

				// String

				writeString(this.Time, dos);

				// String

				writeString(this.Milliseconds, dos);

				// String

				writeString(this.FastestLap, dos);

				// String

				writeString(this.Rank, dos);

				// String

				writeString(this.FastestLapTime, dos);

				// String

				writeString(this.FastestLapSpeed, dos);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.RaceName, dos);

				// int

				dos.writeInt(this.RaceYear);

				// int

				dos.writeInt(this.Round);

				// String

				writeString(this.RaceDate, dos);

				// String

				writeString(this.RaceTime, dos);

				// String

				writeString(this.CircuitRef, dos);

				// String

				writeString(this.CircuitName, dos);

				// String

				writeString(this.CircuitLocation, dos);

				// String

				writeString(this.CircuitCountry, dos);

				// String

				writeString(this.Lat, dos);

				// String

				writeString(this.Lng, dos);

				// String

				writeString(this.Alt, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Id_Result=" + String.valueOf(Id_Result));
			sb.append(",Id_Driver=" + String.valueOf(Id_Driver));
			sb.append(",Id_Constructor=" + String.valueOf(Id_Constructor));
			sb.append(",Id_Race=" + String.valueOf(Id_Race));
			sb.append(",Id_circuit=" + String.valueOf(Id_circuit));
			sb.append(",Id_Status=" + String.valueOf(Id_Status));
			sb.append(",DriverRef=" + DriverRef);
			sb.append(",DriverNumber=" + DriverNumber);
			sb.append(",Code=" + Code);
			sb.append(",Forename=" + Forename);
			sb.append(",Surname=" + Surname);
			sb.append(",Dob=" + Dob);
			sb.append(",Nationality=" + Nationality);
			sb.append(",Number=" + String.valueOf(Number));
			sb.append(",Grid=" + String.valueOf(Grid));
			sb.append(",Position=" + String.valueOf(Position));
			sb.append(",PositionText=" + PositionText);
			sb.append(",PositionOrder=" + PositionOrder);
			sb.append(",Points=" + Points);
			sb.append(",Laps=" + Laps);
			sb.append(",Time=" + Time);
			sb.append(",Milliseconds=" + Milliseconds);
			sb.append(",FastestLap=" + FastestLap);
			sb.append(",Rank=" + Rank);
			sb.append(",FastestLapTime=" + FastestLapTime);
			sb.append(",FastestLapSpeed=" + FastestLapSpeed);
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",RaceName=" + RaceName);
			sb.append(",RaceYear=" + String.valueOf(RaceYear));
			sb.append(",Round=" + String.valueOf(Round));
			sb.append(",RaceDate=" + RaceDate);
			sb.append(",RaceTime=" + RaceTime);
			sb.append(",CircuitRef=" + CircuitRef);
			sb.append(",CircuitName=" + CircuitName);
			sb.append(",CircuitLocation=" + CircuitLocation);
			sb.append(",CircuitCountry=" + CircuitCountry);
			sb.append(",Lat=" + Lat);
			sb.append(",Lng=" + Lng);
			sb.append(",Alt=" + Alt);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Id_Result);

			sb.append("|");

			sb.append(Id_Driver);

			sb.append("|");

			sb.append(Id_Constructor);

			sb.append("|");

			sb.append(Id_Race);

			sb.append("|");

			sb.append(Id_circuit);

			sb.append("|");

			sb.append(Id_Status);

			sb.append("|");

			if (DriverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverRef);
			}

			sb.append("|");

			if (DriverNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverNumber);
			}

			sb.append("|");

			if (Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Code);
			}

			sb.append("|");

			if (Forename == null) {
				sb.append("<null>");
			} else {
				sb.append(Forename);
			}

			sb.append("|");

			if (Surname == null) {
				sb.append("<null>");
			} else {
				sb.append(Surname);
			}

			sb.append("|");

			if (Dob == null) {
				sb.append("<null>");
			} else {
				sb.append(Dob);
			}

			sb.append("|");

			if (Nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(Nationality);
			}

			sb.append("|");

			sb.append(Number);

			sb.append("|");

			sb.append(Grid);

			sb.append("|");

			sb.append(Position);

			sb.append("|");

			if (PositionText == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionText);
			}

			sb.append("|");

			if (PositionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionOrder);
			}

			sb.append("|");

			if (Points == null) {
				sb.append("<null>");
			} else {
				sb.append(Points);
			}

			sb.append("|");

			if (Laps == null) {
				sb.append("<null>");
			} else {
				sb.append(Laps);
			}

			sb.append("|");

			if (Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Time);
			}

			sb.append("|");

			if (Milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(Milliseconds);
			}

			sb.append("|");

			if (FastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLap);
			}

			sb.append("|");

			if (Rank == null) {
				sb.append("<null>");
			} else {
				sb.append(Rank);
			}

			sb.append("|");

			if (FastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapTime);
			}

			sb.append("|");

			if (FastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapSpeed);
			}

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (RaceName == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceName);
			}

			sb.append("|");

			sb.append(RaceYear);

			sb.append("|");

			sb.append(Round);

			sb.append("|");

			if (RaceDate == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceDate);
			}

			sb.append("|");

			if (RaceTime == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceTime);
			}

			sb.append("|");

			if (CircuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitRef);
			}

			sb.append("|");

			if (CircuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitName);
			}

			sb.append("|");

			if (CircuitLocation == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitLocation);
			}

			sb.append("|");

			if (CircuitCountry == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitCountry);
			}

			sb.append("|");

			if (Lat == null) {
				sb.append("<null>");
			} else {
				sb.append(Lat);
			}

			sb.append("|");

			if (Lng == null) {
				sb.append("<null>");
			} else {
				sb.append(Lng);
			}

			sb.append("|");

			if (Alt == null) {
				sb.append("<null>");
			} else {
				sb.append(Alt);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11_0Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row12_0Struct implements routines.system.IPersistableRow<row12_0Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int Id_Result;

		public int getId_Result() {
			return this.Id_Result;
		}

		public int Id_Driver;

		public int getId_Driver() {
			return this.Id_Driver;
		}

		public int Id_Constructor;

		public int getId_Constructor() {
			return this.Id_Constructor;
		}

		public int Id_Race;

		public int getId_Race() {
			return this.Id_Race;
		}

		public int Id_circuit;

		public int getId_circuit() {
			return this.Id_circuit;
		}

		public int Id_Status;

		public int getId_Status() {
			return this.Id_Status;
		}

		public String DriverRef;

		public String getDriverRef() {
			return this.DriverRef;
		}

		public String DriverNumber;

		public String getDriverNumber() {
			return this.DriverNumber;
		}

		public String Code;

		public String getCode() {
			return this.Code;
		}

		public String Forename;

		public String getForename() {
			return this.Forename;
		}

		public String Surname;

		public String getSurname() {
			return this.Surname;
		}

		public String Dob;

		public String getDob() {
			return this.Dob;
		}

		public String Nationality;

		public String getNationality() {
			return this.Nationality;
		}

		public int Number;

		public int getNumber() {
			return this.Number;
		}

		public int Grid;

		public int getGrid() {
			return this.Grid;
		}

		public int Position;

		public int getPosition() {
			return this.Position;
		}

		public String PositionText;

		public String getPositionText() {
			return this.PositionText;
		}

		public String PositionOrder;

		public String getPositionOrder() {
			return this.PositionOrder;
		}

		public String Points;

		public String getPoints() {
			return this.Points;
		}

		public String Laps;

		public String getLaps() {
			return this.Laps;
		}

		public String Time;

		public String getTime() {
			return this.Time;
		}

		public String Milliseconds;

		public String getMilliseconds() {
			return this.Milliseconds;
		}

		public String FastestLap;

		public String getFastestLap() {
			return this.FastestLap;
		}

		public String Rank;

		public String getRank() {
			return this.Rank;
		}

		public String FastestLapTime;

		public String getFastestLapTime() {
			return this.FastestLapTime;
		}

		public String FastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.FastestLapSpeed;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String RaceName;

		public String getRaceName() {
			return this.RaceName;
		}

		public int RaceYear;

		public int getRaceYear() {
			return this.RaceYear;
		}

		public int Round;

		public int getRound() {
			return this.Round;
		}

		public String RaceDate;

		public String getRaceDate() {
			return this.RaceDate;
		}

		public String RaceTime;

		public String getRaceTime() {
			return this.RaceTime;
		}

		public String CircuitRef;

		public String getCircuitRef() {
			return this.CircuitRef;
		}

		public String CircuitName;

		public String getCircuitName() {
			return this.CircuitName;
		}

		public String CircuitLocation;

		public String getCircuitLocation() {
			return this.CircuitLocation;
		}

		public String CircuitCountry;

		public String getCircuitCountry() {
			return this.CircuitCountry;
		}

		public String Lat;

		public String getLat() {
			return this.Lat;
		}

		public String Lng;

		public String getLng() {
			return this.Lng;
		}

		public String Alt;

		public String getAlt() {
			return this.Alt;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.Id_Result = dis.readInt();

					this.Id_Driver = dis.readInt();

					this.Id_Constructor = dis.readInt();

					this.Id_Race = dis.readInt();

					this.Id_circuit = dis.readInt();

					this.Id_Status = dis.readInt();

					this.DriverRef = readString(dis);

					this.DriverNumber = readString(dis);

					this.Code = readString(dis);

					this.Forename = readString(dis);

					this.Surname = readString(dis);

					this.Dob = readString(dis);

					this.Nationality = readString(dis);

					this.Number = dis.readInt();

					this.Grid = dis.readInt();

					this.Position = dis.readInt();

					this.PositionText = readString(dis);

					this.PositionOrder = readString(dis);

					this.Points = readString(dis);

					this.Laps = readString(dis);

					this.Time = readString(dis);

					this.Milliseconds = readString(dis);

					this.FastestLap = readString(dis);

					this.Rank = readString(dis);

					this.FastestLapTime = readString(dis);

					this.FastestLapSpeed = readString(dis);

					this.FastLapandTime = readString(dis);

					this.RaceName = readString(dis);

					this.RaceYear = dis.readInt();

					this.Round = dis.readInt();

					this.RaceDate = readString(dis);

					this.RaceTime = readString(dis);

					this.CircuitRef = readString(dis);

					this.CircuitName = readString(dis);

					this.CircuitLocation = readString(dis);

					this.CircuitCountry = readString(dis);

					this.Lat = readString(dis);

					this.Lng = readString(dis);

					this.Alt = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Id_Result);

				// int

				dos.writeInt(this.Id_Driver);

				// int

				dos.writeInt(this.Id_Constructor);

				// int

				dos.writeInt(this.Id_Race);

				// int

				dos.writeInt(this.Id_circuit);

				// int

				dos.writeInt(this.Id_Status);

				// String

				writeString(this.DriverRef, dos);

				// String

				writeString(this.DriverNumber, dos);

				// String

				writeString(this.Code, dos);

				// String

				writeString(this.Forename, dos);

				// String

				writeString(this.Surname, dos);

				// String

				writeString(this.Dob, dos);

				// String

				writeString(this.Nationality, dos);

				// int

				dos.writeInt(this.Number);

				// int

				dos.writeInt(this.Grid);

				// int

				dos.writeInt(this.Position);

				// String

				writeString(this.PositionText, dos);

				// String

				writeString(this.PositionOrder, dos);

				// String

				writeString(this.Points, dos);

				// String

				writeString(this.Laps, dos);

				// String

				writeString(this.Time, dos);

				// String

				writeString(this.Milliseconds, dos);

				// String

				writeString(this.FastestLap, dos);

				// String

				writeString(this.Rank, dos);

				// String

				writeString(this.FastestLapTime, dos);

				// String

				writeString(this.FastestLapSpeed, dos);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.RaceName, dos);

				// int

				dos.writeInt(this.RaceYear);

				// int

				dos.writeInt(this.Round);

				// String

				writeString(this.RaceDate, dos);

				// String

				writeString(this.RaceTime, dos);

				// String

				writeString(this.CircuitRef, dos);

				// String

				writeString(this.CircuitName, dos);

				// String

				writeString(this.CircuitLocation, dos);

				// String

				writeString(this.CircuitCountry, dos);

				// String

				writeString(this.Lat, dos);

				// String

				writeString(this.Lng, dos);

				// String

				writeString(this.Alt, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Id_Result=" + String.valueOf(Id_Result));
			sb.append(",Id_Driver=" + String.valueOf(Id_Driver));
			sb.append(",Id_Constructor=" + String.valueOf(Id_Constructor));
			sb.append(",Id_Race=" + String.valueOf(Id_Race));
			sb.append(",Id_circuit=" + String.valueOf(Id_circuit));
			sb.append(",Id_Status=" + String.valueOf(Id_Status));
			sb.append(",DriverRef=" + DriverRef);
			sb.append(",DriverNumber=" + DriverNumber);
			sb.append(",Code=" + Code);
			sb.append(",Forename=" + Forename);
			sb.append(",Surname=" + Surname);
			sb.append(",Dob=" + Dob);
			sb.append(",Nationality=" + Nationality);
			sb.append(",Number=" + String.valueOf(Number));
			sb.append(",Grid=" + String.valueOf(Grid));
			sb.append(",Position=" + String.valueOf(Position));
			sb.append(",PositionText=" + PositionText);
			sb.append(",PositionOrder=" + PositionOrder);
			sb.append(",Points=" + Points);
			sb.append(",Laps=" + Laps);
			sb.append(",Time=" + Time);
			sb.append(",Milliseconds=" + Milliseconds);
			sb.append(",FastestLap=" + FastestLap);
			sb.append(",Rank=" + Rank);
			sb.append(",FastestLapTime=" + FastestLapTime);
			sb.append(",FastestLapSpeed=" + FastestLapSpeed);
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",RaceName=" + RaceName);
			sb.append(",RaceYear=" + String.valueOf(RaceYear));
			sb.append(",Round=" + String.valueOf(Round));
			sb.append(",RaceDate=" + RaceDate);
			sb.append(",RaceTime=" + RaceTime);
			sb.append(",CircuitRef=" + CircuitRef);
			sb.append(",CircuitName=" + CircuitName);
			sb.append(",CircuitLocation=" + CircuitLocation);
			sb.append(",CircuitCountry=" + CircuitCountry);
			sb.append(",Lat=" + Lat);
			sb.append(",Lng=" + Lng);
			sb.append(",Alt=" + Alt);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Id_Result);

			sb.append("|");

			sb.append(Id_Driver);

			sb.append("|");

			sb.append(Id_Constructor);

			sb.append("|");

			sb.append(Id_Race);

			sb.append("|");

			sb.append(Id_circuit);

			sb.append("|");

			sb.append(Id_Status);

			sb.append("|");

			if (DriverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverRef);
			}

			sb.append("|");

			if (DriverNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverNumber);
			}

			sb.append("|");

			if (Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Code);
			}

			sb.append("|");

			if (Forename == null) {
				sb.append("<null>");
			} else {
				sb.append(Forename);
			}

			sb.append("|");

			if (Surname == null) {
				sb.append("<null>");
			} else {
				sb.append(Surname);
			}

			sb.append("|");

			if (Dob == null) {
				sb.append("<null>");
			} else {
				sb.append(Dob);
			}

			sb.append("|");

			if (Nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(Nationality);
			}

			sb.append("|");

			sb.append(Number);

			sb.append("|");

			sb.append(Grid);

			sb.append("|");

			sb.append(Position);

			sb.append("|");

			if (PositionText == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionText);
			}

			sb.append("|");

			if (PositionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionOrder);
			}

			sb.append("|");

			if (Points == null) {
				sb.append("<null>");
			} else {
				sb.append(Points);
			}

			sb.append("|");

			if (Laps == null) {
				sb.append("<null>");
			} else {
				sb.append(Laps);
			}

			sb.append("|");

			if (Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Time);
			}

			sb.append("|");

			if (Milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(Milliseconds);
			}

			sb.append("|");

			if (FastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLap);
			}

			sb.append("|");

			if (Rank == null) {
				sb.append("<null>");
			} else {
				sb.append(Rank);
			}

			sb.append("|");

			if (FastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapTime);
			}

			sb.append("|");

			if (FastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapSpeed);
			}

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (RaceName == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceName);
			}

			sb.append("|");

			sb.append(RaceYear);

			sb.append("|");

			sb.append(Round);

			sb.append("|");

			if (RaceDate == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceDate);
			}

			sb.append("|");

			if (RaceTime == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceTime);
			}

			sb.append("|");

			if (CircuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitRef);
			}

			sb.append("|");

			if (CircuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitName);
			}

			sb.append("|");

			if (CircuitLocation == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitLocation);
			}

			sb.append("|");

			if (CircuitCountry == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitCountry);
			}

			sb.append("|");

			if (Lat == null) {
				sb.append("<null>");
			} else {
				sb.append(Lat);
			}

			sb.append("|");

			if (Lng == null) {
				sb.append("<null>");
			} else {
				sb.append(Lng);
			}

			sb.append("|");

			if (Alt == null) {
				sb.append("<null>");
			} else {
				sb.append(Alt);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row12_0Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class copyOfout1Struct implements routines.system.IPersistableRow<copyOfout1Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int Id_Result;

		public int getId_Result() {
			return this.Id_Result;
		}

		public int Id_Driver;

		public int getId_Driver() {
			return this.Id_Driver;
		}

		public int Id_Constructor;

		public int getId_Constructor() {
			return this.Id_Constructor;
		}

		public int Id_Race;

		public int getId_Race() {
			return this.Id_Race;
		}

		public int Id_circuit;

		public int getId_circuit() {
			return this.Id_circuit;
		}

		public int Id_Status;

		public int getId_Status() {
			return this.Id_Status;
		}

		public String DriverRef;

		public String getDriverRef() {
			return this.DriverRef;
		}

		public String DriverNumber;

		public String getDriverNumber() {
			return this.DriverNumber;
		}

		public String Code;

		public String getCode() {
			return this.Code;
		}

		public String Forename;

		public String getForename() {
			return this.Forename;
		}

		public String Surname;

		public String getSurname() {
			return this.Surname;
		}

		public String Dob;

		public String getDob() {
			return this.Dob;
		}

		public String Nationality;

		public String getNationality() {
			return this.Nationality;
		}

		public int Number;

		public int getNumber() {
			return this.Number;
		}

		public int Grid;

		public int getGrid() {
			return this.Grid;
		}

		public int Position;

		public int getPosition() {
			return this.Position;
		}

		public String PositionText;

		public String getPositionText() {
			return this.PositionText;
		}

		public String PositionOrder;

		public String getPositionOrder() {
			return this.PositionOrder;
		}

		public String Points;

		public String getPoints() {
			return this.Points;
		}

		public String Laps;

		public String getLaps() {
			return this.Laps;
		}

		public String Time;

		public String getTime() {
			return this.Time;
		}

		public String Milliseconds;

		public String getMilliseconds() {
			return this.Milliseconds;
		}

		public String FastestLap;

		public String getFastestLap() {
			return this.FastestLap;
		}

		public String Rank;

		public String getRank() {
			return this.Rank;
		}

		public String FastestLapTime;

		public String getFastestLapTime() {
			return this.FastestLapTime;
		}

		public String FastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.FastestLapSpeed;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String RaceName;

		public String getRaceName() {
			return this.RaceName;
		}

		public int RaceYear;

		public int getRaceYear() {
			return this.RaceYear;
		}

		public int Round;

		public int getRound() {
			return this.Round;
		}

		public String RaceDate;

		public String getRaceDate() {
			return this.RaceDate;
		}

		public String RaceTime;

		public String getRaceTime() {
			return this.RaceTime;
		}

		public String CircuitRef;

		public String getCircuitRef() {
			return this.CircuitRef;
		}

		public String CircuitName;

		public String getCircuitName() {
			return this.CircuitName;
		}

		public String CircuitLocation;

		public String getCircuitLocation() {
			return this.CircuitLocation;
		}

		public String CircuitCountry;

		public String getCircuitCountry() {
			return this.CircuitCountry;
		}

		public String Lat;

		public String getLat() {
			return this.Lat;
		}

		public String Lng;

		public String getLng() {
			return this.Lng;
		}

		public String Alt;

		public String getAlt() {
			return this.Alt;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.Id_Result = dis.readInt();

					this.Id_Driver = dis.readInt();

					this.Id_Constructor = dis.readInt();

					this.Id_Race = dis.readInt();

					this.Id_circuit = dis.readInt();

					this.Id_Status = dis.readInt();

					this.DriverRef = readString(dis);

					this.DriverNumber = readString(dis);

					this.Code = readString(dis);

					this.Forename = readString(dis);

					this.Surname = readString(dis);

					this.Dob = readString(dis);

					this.Nationality = readString(dis);

					this.Number = dis.readInt();

					this.Grid = dis.readInt();

					this.Position = dis.readInt();

					this.PositionText = readString(dis);

					this.PositionOrder = readString(dis);

					this.Points = readString(dis);

					this.Laps = readString(dis);

					this.Time = readString(dis);

					this.Milliseconds = readString(dis);

					this.FastestLap = readString(dis);

					this.Rank = readString(dis);

					this.FastestLapTime = readString(dis);

					this.FastestLapSpeed = readString(dis);

					this.FastLapandTime = readString(dis);

					this.RaceName = readString(dis);

					this.RaceYear = dis.readInt();

					this.Round = dis.readInt();

					this.RaceDate = readString(dis);

					this.RaceTime = readString(dis);

					this.CircuitRef = readString(dis);

					this.CircuitName = readString(dis);

					this.CircuitLocation = readString(dis);

					this.CircuitCountry = readString(dis);

					this.Lat = readString(dis);

					this.Lng = readString(dis);

					this.Alt = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Id_Result);

				// int

				dos.writeInt(this.Id_Driver);

				// int

				dos.writeInt(this.Id_Constructor);

				// int

				dos.writeInt(this.Id_Race);

				// int

				dos.writeInt(this.Id_circuit);

				// int

				dos.writeInt(this.Id_Status);

				// String

				writeString(this.DriverRef, dos);

				// String

				writeString(this.DriverNumber, dos);

				// String

				writeString(this.Code, dos);

				// String

				writeString(this.Forename, dos);

				// String

				writeString(this.Surname, dos);

				// String

				writeString(this.Dob, dos);

				// String

				writeString(this.Nationality, dos);

				// int

				dos.writeInt(this.Number);

				// int

				dos.writeInt(this.Grid);

				// int

				dos.writeInt(this.Position);

				// String

				writeString(this.PositionText, dos);

				// String

				writeString(this.PositionOrder, dos);

				// String

				writeString(this.Points, dos);

				// String

				writeString(this.Laps, dos);

				// String

				writeString(this.Time, dos);

				// String

				writeString(this.Milliseconds, dos);

				// String

				writeString(this.FastestLap, dos);

				// String

				writeString(this.Rank, dos);

				// String

				writeString(this.FastestLapTime, dos);

				// String

				writeString(this.FastestLapSpeed, dos);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.RaceName, dos);

				// int

				dos.writeInt(this.RaceYear);

				// int

				dos.writeInt(this.Round);

				// String

				writeString(this.RaceDate, dos);

				// String

				writeString(this.RaceTime, dos);

				// String

				writeString(this.CircuitRef, dos);

				// String

				writeString(this.CircuitName, dos);

				// String

				writeString(this.CircuitLocation, dos);

				// String

				writeString(this.CircuitCountry, dos);

				// String

				writeString(this.Lat, dos);

				// String

				writeString(this.Lng, dos);

				// String

				writeString(this.Alt, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Id_Result=" + String.valueOf(Id_Result));
			sb.append(",Id_Driver=" + String.valueOf(Id_Driver));
			sb.append(",Id_Constructor=" + String.valueOf(Id_Constructor));
			sb.append(",Id_Race=" + String.valueOf(Id_Race));
			sb.append(",Id_circuit=" + String.valueOf(Id_circuit));
			sb.append(",Id_Status=" + String.valueOf(Id_Status));
			sb.append(",DriverRef=" + DriverRef);
			sb.append(",DriverNumber=" + DriverNumber);
			sb.append(",Code=" + Code);
			sb.append(",Forename=" + Forename);
			sb.append(",Surname=" + Surname);
			sb.append(",Dob=" + Dob);
			sb.append(",Nationality=" + Nationality);
			sb.append(",Number=" + String.valueOf(Number));
			sb.append(",Grid=" + String.valueOf(Grid));
			sb.append(",Position=" + String.valueOf(Position));
			sb.append(",PositionText=" + PositionText);
			sb.append(",PositionOrder=" + PositionOrder);
			sb.append(",Points=" + Points);
			sb.append(",Laps=" + Laps);
			sb.append(",Time=" + Time);
			sb.append(",Milliseconds=" + Milliseconds);
			sb.append(",FastestLap=" + FastestLap);
			sb.append(",Rank=" + Rank);
			sb.append(",FastestLapTime=" + FastestLapTime);
			sb.append(",FastestLapSpeed=" + FastestLapSpeed);
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",RaceName=" + RaceName);
			sb.append(",RaceYear=" + String.valueOf(RaceYear));
			sb.append(",Round=" + String.valueOf(Round));
			sb.append(",RaceDate=" + RaceDate);
			sb.append(",RaceTime=" + RaceTime);
			sb.append(",CircuitRef=" + CircuitRef);
			sb.append(",CircuitName=" + CircuitName);
			sb.append(",CircuitLocation=" + CircuitLocation);
			sb.append(",CircuitCountry=" + CircuitCountry);
			sb.append(",Lat=" + Lat);
			sb.append(",Lng=" + Lng);
			sb.append(",Alt=" + Alt);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Id_Result);

			sb.append("|");

			sb.append(Id_Driver);

			sb.append("|");

			sb.append(Id_Constructor);

			sb.append("|");

			sb.append(Id_Race);

			sb.append("|");

			sb.append(Id_circuit);

			sb.append("|");

			sb.append(Id_Status);

			sb.append("|");

			if (DriverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverRef);
			}

			sb.append("|");

			if (DriverNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverNumber);
			}

			sb.append("|");

			if (Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Code);
			}

			sb.append("|");

			if (Forename == null) {
				sb.append("<null>");
			} else {
				sb.append(Forename);
			}

			sb.append("|");

			if (Surname == null) {
				sb.append("<null>");
			} else {
				sb.append(Surname);
			}

			sb.append("|");

			if (Dob == null) {
				sb.append("<null>");
			} else {
				sb.append(Dob);
			}

			sb.append("|");

			if (Nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(Nationality);
			}

			sb.append("|");

			sb.append(Number);

			sb.append("|");

			sb.append(Grid);

			sb.append("|");

			sb.append(Position);

			sb.append("|");

			if (PositionText == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionText);
			}

			sb.append("|");

			if (PositionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionOrder);
			}

			sb.append("|");

			if (Points == null) {
				sb.append("<null>");
			} else {
				sb.append(Points);
			}

			sb.append("|");

			if (Laps == null) {
				sb.append("<null>");
			} else {
				sb.append(Laps);
			}

			sb.append("|");

			if (Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Time);
			}

			sb.append("|");

			if (Milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(Milliseconds);
			}

			sb.append("|");

			if (FastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLap);
			}

			sb.append("|");

			if (Rank == null) {
				sb.append("<null>");
			} else {
				sb.append(Rank);
			}

			sb.append("|");

			if (FastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapTime);
			}

			sb.append("|");

			if (FastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapSpeed);
			}

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (RaceName == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceName);
			}

			sb.append("|");

			sb.append(RaceYear);

			sb.append("|");

			sb.append(Round);

			sb.append("|");

			if (RaceDate == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceDate);
			}

			sb.append("|");

			if (RaceTime == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceTime);
			}

			sb.append("|");

			if (CircuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitRef);
			}

			sb.append("|");

			if (CircuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitName);
			}

			sb.append("|");

			if (CircuitLocation == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitLocation);
			}

			sb.append("|");

			if (CircuitCountry == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitCountry);
			}

			sb.append("|");

			if (Lat == null) {
				sb.append("<null>");
			} else {
				sb.append(Lat);
			}

			sb.append("|");

			if (Lng == null) {
				sb.append("<null>");
			} else {
				sb.append(Lng);
			}

			sb.append("|");

			if (Alt == null) {
				sb.append("<null>");
			} else {
				sb.append(Alt);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(copyOfout1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class copyOfout4_0Struct implements routines.system.IPersistableRow<copyOfout4_0Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int Id_Result;

		public int getId_Result() {
			return this.Id_Result;
		}

		public int Id_Driver;

		public int getId_Driver() {
			return this.Id_Driver;
		}

		public int Id_Constructor;

		public int getId_Constructor() {
			return this.Id_Constructor;
		}

		public int Id_Race;

		public int getId_Race() {
			return this.Id_Race;
		}

		public int Id_circuit;

		public int getId_circuit() {
			return this.Id_circuit;
		}

		public int Id_Status;

		public int getId_Status() {
			return this.Id_Status;
		}

		public String DriverRef;

		public String getDriverRef() {
			return this.DriverRef;
		}

		public String DriverNumber;

		public String getDriverNumber() {
			return this.DriverNumber;
		}

		public String Code;

		public String getCode() {
			return this.Code;
		}

		public String Forename;

		public String getForename() {
			return this.Forename;
		}

		public String Surname;

		public String getSurname() {
			return this.Surname;
		}

		public String Dob;

		public String getDob() {
			return this.Dob;
		}

		public String Nationality;

		public String getNationality() {
			return this.Nationality;
		}

		public int Number;

		public int getNumber() {
			return this.Number;
		}

		public int Grid;

		public int getGrid() {
			return this.Grid;
		}

		public int Position;

		public int getPosition() {
			return this.Position;
		}

		public String PositionText;

		public String getPositionText() {
			return this.PositionText;
		}

		public String PositionOrder;

		public String getPositionOrder() {
			return this.PositionOrder;
		}

		public String Points;

		public String getPoints() {
			return this.Points;
		}

		public String Laps;

		public String getLaps() {
			return this.Laps;
		}

		public String Time;

		public String getTime() {
			return this.Time;
		}

		public String Milliseconds;

		public String getMilliseconds() {
			return this.Milliseconds;
		}

		public String FastestLap;

		public String getFastestLap() {
			return this.FastestLap;
		}

		public String Rank;

		public String getRank() {
			return this.Rank;
		}

		public String FastestLapTime;

		public String getFastestLapTime() {
			return this.FastestLapTime;
		}

		public String FastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.FastestLapSpeed;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String RaceName;

		public String getRaceName() {
			return this.RaceName;
		}

		public int RaceYear;

		public int getRaceYear() {
			return this.RaceYear;
		}

		public int Round;

		public int getRound() {
			return this.Round;
		}

		public String RaceDate;

		public String getRaceDate() {
			return this.RaceDate;
		}

		public String RaceTime;

		public String getRaceTime() {
			return this.RaceTime;
		}

		public String CircuitRef;

		public String getCircuitRef() {
			return this.CircuitRef;
		}

		public String CircuitName;

		public String getCircuitName() {
			return this.CircuitName;
		}

		public String CircuitLocation;

		public String getCircuitLocation() {
			return this.CircuitLocation;
		}

		public String CircuitCountry;

		public String getCircuitCountry() {
			return this.CircuitCountry;
		}

		public String Lat;

		public String getLat() {
			return this.Lat;
		}

		public String Lng;

		public String getLng() {
			return this.Lng;
		}

		public String Alt;

		public String getAlt() {
			return this.Alt;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.Id_Result = dis.readInt();

					this.Id_Driver = dis.readInt();

					this.Id_Constructor = dis.readInt();

					this.Id_Race = dis.readInt();

					this.Id_circuit = dis.readInt();

					this.Id_Status = dis.readInt();

					this.DriverRef = readString(dis);

					this.DriverNumber = readString(dis);

					this.Code = readString(dis);

					this.Forename = readString(dis);

					this.Surname = readString(dis);

					this.Dob = readString(dis);

					this.Nationality = readString(dis);

					this.Number = dis.readInt();

					this.Grid = dis.readInt();

					this.Position = dis.readInt();

					this.PositionText = readString(dis);

					this.PositionOrder = readString(dis);

					this.Points = readString(dis);

					this.Laps = readString(dis);

					this.Time = readString(dis);

					this.Milliseconds = readString(dis);

					this.FastestLap = readString(dis);

					this.Rank = readString(dis);

					this.FastestLapTime = readString(dis);

					this.FastestLapSpeed = readString(dis);

					this.FastLapandTime = readString(dis);

					this.RaceName = readString(dis);

					this.RaceYear = dis.readInt();

					this.Round = dis.readInt();

					this.RaceDate = readString(dis);

					this.RaceTime = readString(dis);

					this.CircuitRef = readString(dis);

					this.CircuitName = readString(dis);

					this.CircuitLocation = readString(dis);

					this.CircuitCountry = readString(dis);

					this.Lat = readString(dis);

					this.Lng = readString(dis);

					this.Alt = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Id_Result);

				// int

				dos.writeInt(this.Id_Driver);

				// int

				dos.writeInt(this.Id_Constructor);

				// int

				dos.writeInt(this.Id_Race);

				// int

				dos.writeInt(this.Id_circuit);

				// int

				dos.writeInt(this.Id_Status);

				// String

				writeString(this.DriverRef, dos);

				// String

				writeString(this.DriverNumber, dos);

				// String

				writeString(this.Code, dos);

				// String

				writeString(this.Forename, dos);

				// String

				writeString(this.Surname, dos);

				// String

				writeString(this.Dob, dos);

				// String

				writeString(this.Nationality, dos);

				// int

				dos.writeInt(this.Number);

				// int

				dos.writeInt(this.Grid);

				// int

				dos.writeInt(this.Position);

				// String

				writeString(this.PositionText, dos);

				// String

				writeString(this.PositionOrder, dos);

				// String

				writeString(this.Points, dos);

				// String

				writeString(this.Laps, dos);

				// String

				writeString(this.Time, dos);

				// String

				writeString(this.Milliseconds, dos);

				// String

				writeString(this.FastestLap, dos);

				// String

				writeString(this.Rank, dos);

				// String

				writeString(this.FastestLapTime, dos);

				// String

				writeString(this.FastestLapSpeed, dos);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.RaceName, dos);

				// int

				dos.writeInt(this.RaceYear);

				// int

				dos.writeInt(this.Round);

				// String

				writeString(this.RaceDate, dos);

				// String

				writeString(this.RaceTime, dos);

				// String

				writeString(this.CircuitRef, dos);

				// String

				writeString(this.CircuitName, dos);

				// String

				writeString(this.CircuitLocation, dos);

				// String

				writeString(this.CircuitCountry, dos);

				// String

				writeString(this.Lat, dos);

				// String

				writeString(this.Lng, dos);

				// String

				writeString(this.Alt, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Id_Result=" + String.valueOf(Id_Result));
			sb.append(",Id_Driver=" + String.valueOf(Id_Driver));
			sb.append(",Id_Constructor=" + String.valueOf(Id_Constructor));
			sb.append(",Id_Race=" + String.valueOf(Id_Race));
			sb.append(",Id_circuit=" + String.valueOf(Id_circuit));
			sb.append(",Id_Status=" + String.valueOf(Id_Status));
			sb.append(",DriverRef=" + DriverRef);
			sb.append(",DriverNumber=" + DriverNumber);
			sb.append(",Code=" + Code);
			sb.append(",Forename=" + Forename);
			sb.append(",Surname=" + Surname);
			sb.append(",Dob=" + Dob);
			sb.append(",Nationality=" + Nationality);
			sb.append(",Number=" + String.valueOf(Number));
			sb.append(",Grid=" + String.valueOf(Grid));
			sb.append(",Position=" + String.valueOf(Position));
			sb.append(",PositionText=" + PositionText);
			sb.append(",PositionOrder=" + PositionOrder);
			sb.append(",Points=" + Points);
			sb.append(",Laps=" + Laps);
			sb.append(",Time=" + Time);
			sb.append(",Milliseconds=" + Milliseconds);
			sb.append(",FastestLap=" + FastestLap);
			sb.append(",Rank=" + Rank);
			sb.append(",FastestLapTime=" + FastestLapTime);
			sb.append(",FastestLapSpeed=" + FastestLapSpeed);
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",RaceName=" + RaceName);
			sb.append(",RaceYear=" + String.valueOf(RaceYear));
			sb.append(",Round=" + String.valueOf(Round));
			sb.append(",RaceDate=" + RaceDate);
			sb.append(",RaceTime=" + RaceTime);
			sb.append(",CircuitRef=" + CircuitRef);
			sb.append(",CircuitName=" + CircuitName);
			sb.append(",CircuitLocation=" + CircuitLocation);
			sb.append(",CircuitCountry=" + CircuitCountry);
			sb.append(",Lat=" + Lat);
			sb.append(",Lng=" + Lng);
			sb.append(",Alt=" + Alt);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Id_Result);

			sb.append("|");

			sb.append(Id_Driver);

			sb.append("|");

			sb.append(Id_Constructor);

			sb.append("|");

			sb.append(Id_Race);

			sb.append("|");

			sb.append(Id_circuit);

			sb.append("|");

			sb.append(Id_Status);

			sb.append("|");

			if (DriverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverRef);
			}

			sb.append("|");

			if (DriverNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverNumber);
			}

			sb.append("|");

			if (Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Code);
			}

			sb.append("|");

			if (Forename == null) {
				sb.append("<null>");
			} else {
				sb.append(Forename);
			}

			sb.append("|");

			if (Surname == null) {
				sb.append("<null>");
			} else {
				sb.append(Surname);
			}

			sb.append("|");

			if (Dob == null) {
				sb.append("<null>");
			} else {
				sb.append(Dob);
			}

			sb.append("|");

			if (Nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(Nationality);
			}

			sb.append("|");

			sb.append(Number);

			sb.append("|");

			sb.append(Grid);

			sb.append("|");

			sb.append(Position);

			sb.append("|");

			if (PositionText == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionText);
			}

			sb.append("|");

			if (PositionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionOrder);
			}

			sb.append("|");

			if (Points == null) {
				sb.append("<null>");
			} else {
				sb.append(Points);
			}

			sb.append("|");

			if (Laps == null) {
				sb.append("<null>");
			} else {
				sb.append(Laps);
			}

			sb.append("|");

			if (Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Time);
			}

			sb.append("|");

			if (Milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(Milliseconds);
			}

			sb.append("|");

			if (FastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLap);
			}

			sb.append("|");

			if (Rank == null) {
				sb.append("<null>");
			} else {
				sb.append(Rank);
			}

			sb.append("|");

			if (FastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapTime);
			}

			sb.append("|");

			if (FastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapSpeed);
			}

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (RaceName == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceName);
			}

			sb.append("|");

			sb.append(RaceYear);

			sb.append("|");

			sb.append(Round);

			sb.append("|");

			if (RaceDate == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceDate);
			}

			sb.append("|");

			if (RaceTime == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceTime);
			}

			sb.append("|");

			if (CircuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitRef);
			}

			sb.append("|");

			if (CircuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitName);
			}

			sb.append("|");

			if (CircuitLocation == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitLocation);
			}

			sb.append("|");

			if (CircuitCountry == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitCountry);
			}

			sb.append("|");

			if (Lat == null) {
				sb.append("<null>");
			} else {
				sb.append(Lat);
			}

			sb.append("|");

			if (Lng == null) {
				sb.append("<null>");
			} else {
				sb.append(Lng);
			}

			sb.append("|");

			if (Alt == null) {
				sb.append("<null>");
			} else {
				sb.append(Alt);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(copyOfout4_0Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row13Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row11Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class OnRowsEndStructtSortRow_1
			implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(OnRowsEndStructtSortRow_1 other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class out4Struct implements routines.system.IPersistableRow<out4Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int Id_Result;

		public int getId_Result() {
			return this.Id_Result;
		}

		public int Id_Driver;

		public int getId_Driver() {
			return this.Id_Driver;
		}

		public int Id_Constructor;

		public int getId_Constructor() {
			return this.Id_Constructor;
		}

		public int Id_Race;

		public int getId_Race() {
			return this.Id_Race;
		}

		public int Id_circuit;

		public int getId_circuit() {
			return this.Id_circuit;
		}

		public int Id_Status;

		public int getId_Status() {
			return this.Id_Status;
		}

		public String DriverRef;

		public String getDriverRef() {
			return this.DriverRef;
		}

		public String DriverNumber;

		public String getDriverNumber() {
			return this.DriverNumber;
		}

		public String Code;

		public String getCode() {
			return this.Code;
		}

		public String Forename;

		public String getForename() {
			return this.Forename;
		}

		public String Surname;

		public String getSurname() {
			return this.Surname;
		}

		public String Dob;

		public String getDob() {
			return this.Dob;
		}

		public String Nationality;

		public String getNationality() {
			return this.Nationality;
		}

		public int Number;

		public int getNumber() {
			return this.Number;
		}

		public int Grid;

		public int getGrid() {
			return this.Grid;
		}

		public int Position;

		public int getPosition() {
			return this.Position;
		}

		public String PositionText;

		public String getPositionText() {
			return this.PositionText;
		}

		public String PositionOrder;

		public String getPositionOrder() {
			return this.PositionOrder;
		}

		public String Points;

		public String getPoints() {
			return this.Points;
		}

		public String Laps;

		public String getLaps() {
			return this.Laps;
		}

		public String Time;

		public String getTime() {
			return this.Time;
		}

		public String Milliseconds;

		public String getMilliseconds() {
			return this.Milliseconds;
		}

		public String FastestLap;

		public String getFastestLap() {
			return this.FastestLap;
		}

		public String Rank;

		public String getRank() {
			return this.Rank;
		}

		public String FastestLapTime;

		public String getFastestLapTime() {
			return this.FastestLapTime;
		}

		public String FastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.FastestLapSpeed;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String RaceName;

		public String getRaceName() {
			return this.RaceName;
		}

		public int RaceYear;

		public int getRaceYear() {
			return this.RaceYear;
		}

		public int Round;

		public int getRound() {
			return this.Round;
		}

		public String RaceDate;

		public String getRaceDate() {
			return this.RaceDate;
		}

		public String RaceTime;

		public String getRaceTime() {
			return this.RaceTime;
		}

		public String CircuitRef;

		public String getCircuitRef() {
			return this.CircuitRef;
		}

		public String CircuitName;

		public String getCircuitName() {
			return this.CircuitName;
		}

		public String CircuitLocation;

		public String getCircuitLocation() {
			return this.CircuitLocation;
		}

		public String CircuitCountry;

		public String getCircuitCountry() {
			return this.CircuitCountry;
		}

		public String Lat;

		public String getLat() {
			return this.Lat;
		}

		public String Lng;

		public String getLng() {
			return this.Lng;
		}

		public String Alt;

		public String getAlt() {
			return this.Alt;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.Id_Result = dis.readInt();

					this.Id_Driver = dis.readInt();

					this.Id_Constructor = dis.readInt();

					this.Id_Race = dis.readInt();

					this.Id_circuit = dis.readInt();

					this.Id_Status = dis.readInt();

					this.DriverRef = readString(dis);

					this.DriverNumber = readString(dis);

					this.Code = readString(dis);

					this.Forename = readString(dis);

					this.Surname = readString(dis);

					this.Dob = readString(dis);

					this.Nationality = readString(dis);

					this.Number = dis.readInt();

					this.Grid = dis.readInt();

					this.Position = dis.readInt();

					this.PositionText = readString(dis);

					this.PositionOrder = readString(dis);

					this.Points = readString(dis);

					this.Laps = readString(dis);

					this.Time = readString(dis);

					this.Milliseconds = readString(dis);

					this.FastestLap = readString(dis);

					this.Rank = readString(dis);

					this.FastestLapTime = readString(dis);

					this.FastestLapSpeed = readString(dis);

					this.FastLapandTime = readString(dis);

					this.RaceName = readString(dis);

					this.RaceYear = dis.readInt();

					this.Round = dis.readInt();

					this.RaceDate = readString(dis);

					this.RaceTime = readString(dis);

					this.CircuitRef = readString(dis);

					this.CircuitName = readString(dis);

					this.CircuitLocation = readString(dis);

					this.CircuitCountry = readString(dis);

					this.Lat = readString(dis);

					this.Lng = readString(dis);

					this.Alt = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.Id_Result);

				// int

				dos.writeInt(this.Id_Driver);

				// int

				dos.writeInt(this.Id_Constructor);

				// int

				dos.writeInt(this.Id_Race);

				// int

				dos.writeInt(this.Id_circuit);

				// int

				dos.writeInt(this.Id_Status);

				// String

				writeString(this.DriverRef, dos);

				// String

				writeString(this.DriverNumber, dos);

				// String

				writeString(this.Code, dos);

				// String

				writeString(this.Forename, dos);

				// String

				writeString(this.Surname, dos);

				// String

				writeString(this.Dob, dos);

				// String

				writeString(this.Nationality, dos);

				// int

				dos.writeInt(this.Number);

				// int

				dos.writeInt(this.Grid);

				// int

				dos.writeInt(this.Position);

				// String

				writeString(this.PositionText, dos);

				// String

				writeString(this.PositionOrder, dos);

				// String

				writeString(this.Points, dos);

				// String

				writeString(this.Laps, dos);

				// String

				writeString(this.Time, dos);

				// String

				writeString(this.Milliseconds, dos);

				// String

				writeString(this.FastestLap, dos);

				// String

				writeString(this.Rank, dos);

				// String

				writeString(this.FastestLapTime, dos);

				// String

				writeString(this.FastestLapSpeed, dos);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.RaceName, dos);

				// int

				dos.writeInt(this.RaceYear);

				// int

				dos.writeInt(this.Round);

				// String

				writeString(this.RaceDate, dos);

				// String

				writeString(this.RaceTime, dos);

				// String

				writeString(this.CircuitRef, dos);

				// String

				writeString(this.CircuitName, dos);

				// String

				writeString(this.CircuitLocation, dos);

				// String

				writeString(this.CircuitCountry, dos);

				// String

				writeString(this.Lat, dos);

				// String

				writeString(this.Lng, dos);

				// String

				writeString(this.Alt, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("Id_Result=" + String.valueOf(Id_Result));
			sb.append(",Id_Driver=" + String.valueOf(Id_Driver));
			sb.append(",Id_Constructor=" + String.valueOf(Id_Constructor));
			sb.append(",Id_Race=" + String.valueOf(Id_Race));
			sb.append(",Id_circuit=" + String.valueOf(Id_circuit));
			sb.append(",Id_Status=" + String.valueOf(Id_Status));
			sb.append(",DriverRef=" + DriverRef);
			sb.append(",DriverNumber=" + DriverNumber);
			sb.append(",Code=" + Code);
			sb.append(",Forename=" + Forename);
			sb.append(",Surname=" + Surname);
			sb.append(",Dob=" + Dob);
			sb.append(",Nationality=" + Nationality);
			sb.append(",Number=" + String.valueOf(Number));
			sb.append(",Grid=" + String.valueOf(Grid));
			sb.append(",Position=" + String.valueOf(Position));
			sb.append(",PositionText=" + PositionText);
			sb.append(",PositionOrder=" + PositionOrder);
			sb.append(",Points=" + Points);
			sb.append(",Laps=" + Laps);
			sb.append(",Time=" + Time);
			sb.append(",Milliseconds=" + Milliseconds);
			sb.append(",FastestLap=" + FastestLap);
			sb.append(",Rank=" + Rank);
			sb.append(",FastestLapTime=" + FastestLapTime);
			sb.append(",FastestLapSpeed=" + FastestLapSpeed);
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",RaceName=" + RaceName);
			sb.append(",RaceYear=" + String.valueOf(RaceYear));
			sb.append(",Round=" + String.valueOf(Round));
			sb.append(",RaceDate=" + RaceDate);
			sb.append(",RaceTime=" + RaceTime);
			sb.append(",CircuitRef=" + CircuitRef);
			sb.append(",CircuitName=" + CircuitName);
			sb.append(",CircuitLocation=" + CircuitLocation);
			sb.append(",CircuitCountry=" + CircuitCountry);
			sb.append(",Lat=" + Lat);
			sb.append(",Lng=" + Lng);
			sb.append(",Alt=" + Alt);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(Id_Result);

			sb.append("|");

			sb.append(Id_Driver);

			sb.append("|");

			sb.append(Id_Constructor);

			sb.append("|");

			sb.append(Id_Race);

			sb.append("|");

			sb.append(Id_circuit);

			sb.append("|");

			sb.append(Id_Status);

			sb.append("|");

			if (DriverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverRef);
			}

			sb.append("|");

			if (DriverNumber == null) {
				sb.append("<null>");
			} else {
				sb.append(DriverNumber);
			}

			sb.append("|");

			if (Code == null) {
				sb.append("<null>");
			} else {
				sb.append(Code);
			}

			sb.append("|");

			if (Forename == null) {
				sb.append("<null>");
			} else {
				sb.append(Forename);
			}

			sb.append("|");

			if (Surname == null) {
				sb.append("<null>");
			} else {
				sb.append(Surname);
			}

			sb.append("|");

			if (Dob == null) {
				sb.append("<null>");
			} else {
				sb.append(Dob);
			}

			sb.append("|");

			if (Nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(Nationality);
			}

			sb.append("|");

			sb.append(Number);

			sb.append("|");

			sb.append(Grid);

			sb.append("|");

			sb.append(Position);

			sb.append("|");

			if (PositionText == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionText);
			}

			sb.append("|");

			if (PositionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(PositionOrder);
			}

			sb.append("|");

			if (Points == null) {
				sb.append("<null>");
			} else {
				sb.append(Points);
			}

			sb.append("|");

			if (Laps == null) {
				sb.append("<null>");
			} else {
				sb.append(Laps);
			}

			sb.append("|");

			if (Time == null) {
				sb.append("<null>");
			} else {
				sb.append(Time);
			}

			sb.append("|");

			if (Milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(Milliseconds);
			}

			sb.append("|");

			if (FastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLap);
			}

			sb.append("|");

			if (Rank == null) {
				sb.append("<null>");
			} else {
				sb.append(Rank);
			}

			sb.append("|");

			if (FastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapTime);
			}

			sb.append("|");

			if (FastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(FastestLapSpeed);
			}

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (RaceName == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceName);
			}

			sb.append("|");

			sb.append(RaceYear);

			sb.append("|");

			sb.append(Round);

			sb.append("|");

			if (RaceDate == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceDate);
			}

			sb.append("|");

			if (RaceTime == null) {
				sb.append("<null>");
			} else {
				sb.append(RaceTime);
			}

			sb.append("|");

			if (CircuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitRef);
			}

			sb.append("|");

			if (CircuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitName);
			}

			sb.append("|");

			if (CircuitLocation == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitLocation);
			}

			sb.append("|");

			if (CircuitCountry == null) {
				sb.append("<null>");
			} else {
				sb.append(CircuitCountry);
			}

			sb.append("|");

			if (Lat == null) {
				sb.append("<null>");
			} else {
				sb.append(Lat);
			}

			sb.append("|");

			if (Lng == null) {
				sb.append("<null>");
			} else {
				sb.append(Lng);
			}

			sb.append("|");

			if (Alt == null) {
				sb.append("<null>");
			} else {
				sb.append(Alt);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row2Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row3Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		public String GID;

		public String getGID() {
			return this.GID;
		}

		public Integer GRP_SIZE;

		public Integer getGRP_SIZE() {
			return this.GRP_SIZE;
		}

		public Boolean MASTER;

		public Boolean getMASTER() {
			return this.MASTER;
		}

		public Double SCORE;

		public Double getSCORE() {
			return this.SCORE;
		}

		public Double GRP_QUALITY;

		public Double getGRP_QUALITY() {
			return this.GRP_QUALITY;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

					this.GID = readString(dis);

					this.GRP_SIZE = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.MASTER = null;
					} else {
						this.MASTER = dis.readBoolean();
					}

					length = dis.readByte();
					if (length == -1) {
						this.SCORE = null;
					} else {
						this.SCORE = dis.readDouble();
					}

					length = dis.readByte();
					if (length == -1) {
						this.GRP_QUALITY = null;
					} else {
						this.GRP_QUALITY = dis.readDouble();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

				// String

				writeString(this.GID, dos);

				// Integer

				writeInteger(this.GRP_SIZE, dos);

				// Boolean

				if (this.MASTER == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeBoolean(this.MASTER);
				}

				// Double

				if (this.SCORE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.SCORE);
				}

				// Double

				if (this.GRP_QUALITY == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeDouble(this.GRP_QUALITY);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append(",GID=" + GID);
			sb.append(",GRP_SIZE=" + String.valueOf(GRP_SIZE));
			sb.append(",MASTER=" + String.valueOf(MASTER));
			sb.append(",SCORE=" + String.valueOf(SCORE));
			sb.append(",GRP_QUALITY=" + String.valueOf(GRP_QUALITY));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			if (GID == null) {
				sb.append("<null>");
			} else {
				sb.append(GID);
			}

			sb.append("|");

			if (GRP_SIZE == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_SIZE);
			}

			sb.append("|");

			if (MASTER == null) {
				sb.append("<null>");
			} else {
				sb.append(MASTER);
			}

			sb.append("|");

			if (SCORE == null) {
				sb.append("<null>");
			} else {
				sb.append(SCORE);
			}

			sb.append("|");

			if (GRP_QUALITY == null) {
				sb.append("<null>");
			} else {
				sb.append(GRP_QUALITY);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row4Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
		static byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];

		public int resultId;

		public int getResultId() {
			return this.resultId;
		}

		public int raceId;

		public int getRaceId() {
			return this.raceId;
		}

		public int driverId;

		public int getDriverId() {
			return this.driverId;
		}

		public int constructorId;

		public int getConstructorId() {
			return this.constructorId;
		}

		public int number;

		public int getNumber() {
			return this.number;
		}

		public int grid;

		public int getGrid() {
			return this.grid;
		}

		public int position;

		public int getPosition() {
			return this.position;
		}

		public String positionText;

		public String getPositionText() {
			return this.positionText;
		}

		public String positionOrder;

		public String getPositionOrder() {
			return this.positionOrder;
		}

		public String points;

		public String getPoints() {
			return this.points;
		}

		public String laps;

		public String getLaps() {
			return this.laps;
		}

		public String time;

		public String getTime() {
			return this.time;
		}

		public String milliseconds;

		public String getMilliseconds() {
			return this.milliseconds;
		}

		public String fastestLap;

		public String getFastestLap() {
			return this.fastestLap;
		}

		public String rank;

		public String getRank() {
			return this.rank;
		}

		public String fastestLapTime;

		public String getFastestLapTime() {
			return this.fastestLapTime;
		}

		public String fastestLapSpeed;

		public String getFastestLapSpeed() {
			return this.fastestLapSpeed;
		}

		public int statusId;

		public int getStatusId() {
			return this.statusId;
		}

		public String FastLapandTime;

		public String getFastLapandTime() {
			return this.FastLapandTime;
		}

		public String raceName;

		public String getRaceName() {
			return this.raceName;
		}

		public int year;

		public int getYear() {
			return this.year;
		}

		public int round;

		public int getRound() {
			return this.round;
		}

		public String date;

		public String getDate() {
			return this.date;
		}

		public String time_race;

		public String getTime_race() {
			return this.time_race;
		}

		public String url_race;

		public String getUrl_race() {
			return this.url_race;
		}

		public int circuitId;

		public int getCircuitId() {
			return this.circuitId;
		}

		public String circuitRef;

		public String getCircuitRef() {
			return this.circuitRef;
		}

		public String circuitName;

		public String getCircuitName() {
			return this.circuitName;
		}

		public String location;

		public String getLocation() {
			return this.location;
		}

		public String country;

		public String getCountry() {
			return this.country;
		}

		public String lat;

		public String getLat() {
			return this.lat;
		}

		public String lng;

		public String getLng() {
			return this.lng;
		}

		public String alt;

		public String getAlt() {
			return this.alt;
		}

		public String url_circuit;

		public String getUrl_circuit() {
			return this.url_circuit;
		}

		public String driverRef;

		public String getDriverRef() {
			return this.driverRef;
		}

		public String number_driver;

		public String getNumber_driver() {
			return this.number_driver;
		}

		public String code;

		public String getCode() {
			return this.code;
		}

		public String forename;

		public String getForename() {
			return this.forename;
		}

		public String surname;

		public String getSurname() {
			return this.surname;
		}

		public String dob;

		public String getDob() {
			return this.dob;
		}

		public String nationality;

		public String getNationality() {
			return this.nationality;
		}

		public String url;

		public String getUrl() {
			return this.url;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
					if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
					} else {
						commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
				strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {

				try {

					int length = 0;

					this.resultId = dis.readInt();

					this.raceId = dis.readInt();

					this.driverId = dis.readInt();

					this.constructorId = dis.readInt();

					this.number = dis.readInt();

					this.grid = dis.readInt();

					this.position = dis.readInt();

					this.positionText = readString(dis);

					this.positionOrder = readString(dis);

					this.points = readString(dis);

					this.laps = readString(dis);

					this.time = readString(dis);

					this.milliseconds = readString(dis);

					this.fastestLap = readString(dis);

					this.rank = readString(dis);

					this.fastestLapTime = readString(dis);

					this.fastestLapSpeed = readString(dis);

					this.statusId = dis.readInt();

					this.FastLapandTime = readString(dis);

					this.raceName = readString(dis);

					this.year = dis.readInt();

					this.round = dis.readInt();

					this.date = readString(dis);

					this.time_race = readString(dis);

					this.url_race = readString(dis);

					this.circuitId = dis.readInt();

					this.circuitRef = readString(dis);

					this.circuitName = readString(dis);

					this.location = readString(dis);

					this.country = readString(dis);

					this.lat = readString(dis);

					this.lng = readString(dis);

					this.alt = readString(dis);

					this.url_circuit = readString(dis);

					this.driverRef = readString(dis);

					this.number_driver = readString(dis);

					this.code = readString(dis);

					this.forename = readString(dis);

					this.surname = readString(dis);

					this.dob = readString(dis);

					this.nationality = readString(dis);

					this.url = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.resultId);

				// int

				dos.writeInt(this.raceId);

				// int

				dos.writeInt(this.driverId);

				// int

				dos.writeInt(this.constructorId);

				// int

				dos.writeInt(this.number);

				// int

				dos.writeInt(this.grid);

				// int

				dos.writeInt(this.position);

				// String

				writeString(this.positionText, dos);

				// String

				writeString(this.positionOrder, dos);

				// String

				writeString(this.points, dos);

				// String

				writeString(this.laps, dos);

				// String

				writeString(this.time, dos);

				// String

				writeString(this.milliseconds, dos);

				// String

				writeString(this.fastestLap, dos);

				// String

				writeString(this.rank, dos);

				// String

				writeString(this.fastestLapTime, dos);

				// String

				writeString(this.fastestLapSpeed, dos);

				// int

				dos.writeInt(this.statusId);

				// String

				writeString(this.FastLapandTime, dos);

				// String

				writeString(this.raceName, dos);

				// int

				dos.writeInt(this.year);

				// int

				dos.writeInt(this.round);

				// String

				writeString(this.date, dos);

				// String

				writeString(this.time_race, dos);

				// String

				writeString(this.url_race, dos);

				// int

				dos.writeInt(this.circuitId);

				// String

				writeString(this.circuitRef, dos);

				// String

				writeString(this.circuitName, dos);

				// String

				writeString(this.location, dos);

				// String

				writeString(this.country, dos);

				// String

				writeString(this.lat, dos);

				// String

				writeString(this.lng, dos);

				// String

				writeString(this.alt, dos);

				// String

				writeString(this.url_circuit, dos);

				// String

				writeString(this.driverRef, dos);

				// String

				writeString(this.number_driver, dos);

				// String

				writeString(this.code, dos);

				// String

				writeString(this.forename, dos);

				// String

				writeString(this.surname, dos);

				// String

				writeString(this.dob, dos);

				// String

				writeString(this.nationality, dos);

				// String

				writeString(this.url, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("resultId=" + String.valueOf(resultId));
			sb.append(",raceId=" + String.valueOf(raceId));
			sb.append(",driverId=" + String.valueOf(driverId));
			sb.append(",constructorId=" + String.valueOf(constructorId));
			sb.append(",number=" + String.valueOf(number));
			sb.append(",grid=" + String.valueOf(grid));
			sb.append(",position=" + String.valueOf(position));
			sb.append(",positionText=" + positionText);
			sb.append(",positionOrder=" + positionOrder);
			sb.append(",points=" + points);
			sb.append(",laps=" + laps);
			sb.append(",time=" + time);
			sb.append(",milliseconds=" + milliseconds);
			sb.append(",fastestLap=" + fastestLap);
			sb.append(",rank=" + rank);
			sb.append(",fastestLapTime=" + fastestLapTime);
			sb.append(",fastestLapSpeed=" + fastestLapSpeed);
			sb.append(",statusId=" + String.valueOf(statusId));
			sb.append(",FastLapandTime=" + FastLapandTime);
			sb.append(",raceName=" + raceName);
			sb.append(",year=" + String.valueOf(year));
			sb.append(",round=" + String.valueOf(round));
			sb.append(",date=" + date);
			sb.append(",time_race=" + time_race);
			sb.append(",url_race=" + url_race);
			sb.append(",circuitId=" + String.valueOf(circuitId));
			sb.append(",circuitRef=" + circuitRef);
			sb.append(",circuitName=" + circuitName);
			sb.append(",location=" + location);
			sb.append(",country=" + country);
			sb.append(",lat=" + lat);
			sb.append(",lng=" + lng);
			sb.append(",alt=" + alt);
			sb.append(",url_circuit=" + url_circuit);
			sb.append(",driverRef=" + driverRef);
			sb.append(",number_driver=" + number_driver);
			sb.append(",code=" + code);
			sb.append(",forename=" + forename);
			sb.append(",surname=" + surname);
			sb.append(",dob=" + dob);
			sb.append(",nationality=" + nationality);
			sb.append(",url=" + url);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(resultId);

			sb.append("|");

			sb.append(raceId);

			sb.append("|");

			sb.append(driverId);

			sb.append("|");

			sb.append(constructorId);

			sb.append("|");

			sb.append(number);

			sb.append("|");

			sb.append(grid);

			sb.append("|");

			sb.append(position);

			sb.append("|");

			if (positionText == null) {
				sb.append("<null>");
			} else {
				sb.append(positionText);
			}

			sb.append("|");

			if (positionOrder == null) {
				sb.append("<null>");
			} else {
				sb.append(positionOrder);
			}

			sb.append("|");

			if (points == null) {
				sb.append("<null>");
			} else {
				sb.append(points);
			}

			sb.append("|");

			if (laps == null) {
				sb.append("<null>");
			} else {
				sb.append(laps);
			}

			sb.append("|");

			if (time == null) {
				sb.append("<null>");
			} else {
				sb.append(time);
			}

			sb.append("|");

			if (milliseconds == null) {
				sb.append("<null>");
			} else {
				sb.append(milliseconds);
			}

			sb.append("|");

			if (fastestLap == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLap);
			}

			sb.append("|");

			if (rank == null) {
				sb.append("<null>");
			} else {
				sb.append(rank);
			}

			sb.append("|");

			if (fastestLapTime == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapTime);
			}

			sb.append("|");

			if (fastestLapSpeed == null) {
				sb.append("<null>");
			} else {
				sb.append(fastestLapSpeed);
			}

			sb.append("|");

			sb.append(statusId);

			sb.append("|");

			if (FastLapandTime == null) {
				sb.append("<null>");
			} else {
				sb.append(FastLapandTime);
			}

			sb.append("|");

			if (raceName == null) {
				sb.append("<null>");
			} else {
				sb.append(raceName);
			}

			sb.append("|");

			sb.append(year);

			sb.append("|");

			sb.append(round);

			sb.append("|");

			if (date == null) {
				sb.append("<null>");
			} else {
				sb.append(date);
			}

			sb.append("|");

			if (time_race == null) {
				sb.append("<null>");
			} else {
				sb.append(time_race);
			}

			sb.append("|");

			if (url_race == null) {
				sb.append("<null>");
			} else {
				sb.append(url_race);
			}

			sb.append("|");

			sb.append(circuitId);

			sb.append("|");

			if (circuitRef == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitRef);
			}

			sb.append("|");

			if (circuitName == null) {
				sb.append("<null>");
			} else {
				sb.append(circuitName);
			}

			sb.append("|");

			if (location == null) {
				sb.append("<null>");
			} else {
				sb.append(location);
			}

			sb.append("|");

			if (country == null) {
				sb.append("<null>");
			} else {
				sb.append(country);
			}

			sb.append("|");

			if (lat == null) {
				sb.append("<null>");
			} else {
				sb.append(lat);
			}

			sb.append("|");

			if (lng == null) {
				sb.append("<null>");
			} else {
				sb.append(lng);
			}

			sb.append("|");

			if (alt == null) {
				sb.append("<null>");
			} else {
				sb.append(alt);
			}

			sb.append("|");

			if (url_circuit == null) {
				sb.append("<null>");
			} else {
				sb.append(url_circuit);
			}

			sb.append("|");

			if (driverRef == null) {
				sb.append("<null>");
			} else {
				sb.append(driverRef);
			}

			sb.append("|");

			if (number_driver == null) {
				sb.append("<null>");
			} else {
				sb.append(number_driver);
			}

			sb.append("|");

			if (code == null) {
				sb.append("<null>");
			} else {
				sb.append(code);
			}

			sb.append("|");

			if (forename == null) {
				sb.append("<null>");
			} else {
				sb.append(forename);
			}

			sb.append("|");

			if (surname == null) {
				sb.append("<null>");
			} else {
				sb.append(surname);
			}

			sb.append("|");

			if (dob == null) {
				sb.append("<null>");
			} else {
				sb.append(dob);
			}

			sb.append("|");

			if (nationality == null) {
				sb.append("<null>");
			} else {
				sb.append(nationality);
			}

			sb.append("|");

			if (url == null) {
				sb.append("<null>");
			} else {
				sb.append(url);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;
		String currentVirtualComponent = null;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				row1Struct row1 = new row1Struct();
				row2Struct row2 = new row2Struct();
				out4Struct out4 = new out4Struct();
				row3Struct row3 = new row3Struct();
				row4Struct row4 = new row4Struct();
				row11Struct row11 = new row11Struct();
				row11Struct row13 = row11;
				copyOfout1Struct copyOfout1 = new copyOfout1Struct();
				copyOfout1Struct row12_0 = copyOfout1;
				copyOfout4_0Struct copyOfout4_0 = new copyOfout4_0Struct();
				copyOfout4_0Struct row11_0 = copyOfout4_0;

				/**
				 * [tMatchGroup_1_GroupOut begin ] start
				 */

				ok_Hash.put("tMatchGroup_1_GroupOut", false);
				start_Hash.put("tMatchGroup_1_GroupOut", System.currentTimeMillis());

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupOut";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tMatchGroup_1_GroupOut = 0;

				if (log.isDebugEnabled())
					log.debug("tMatchGroup_1_GroupOut - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMatchGroup_1_GroupOut {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMatchGroup_1_GroupOut = new StringBuilder();
							log4jParamters_tMatchGroup_1_GroupOut.append("Parameters:");
							log4jParamters_tMatchGroup_1_GroupOut
									.append("MATCHING_ALGORITHM" + " = " + "Simple VSR Matcher");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("STORE_ON_DISK" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("SEPARATE_OUTPUT" + " = " + "true");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("CONFIDENCE_THRESHOLD" + " = " + "0.9");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("LINK_WITH_PREVIOUS" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("SORT_DATA" + " = " + "true");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut.append("OUTPUTDD" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							log4jParamters_tMatchGroup_1_GroupOut
									.append("DEACTIVATE_MATCHING_COMPUTATION" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupOut.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMatchGroup_1_GroupOut - " + (log4jParamters_tMatchGroup_1_GroupOut));
						}
					}
					new BytesLimit65535_tMatchGroup_1_GroupOut().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMatchGroup_1_GroupOut", "tMatchGroupOut");
					talendJobLogProcess(globalMap);
				}

				class tMatchGroup_1Struct implements routines.system.IPersistableRow<tMatchGroup_1Struct> {
					final byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
					byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
					public int resultId;

					public int getResultId() {
						return this.resultId;
					}

					public int raceId;

					public int getRaceId() {
						return this.raceId;
					}

					public int driverId;

					public int getDriverId() {
						return this.driverId;
					}

					public int constructorId;

					public int getConstructorId() {
						return this.constructorId;
					}

					public int number;

					public int getNumber() {
						return this.number;
					}

					public int grid;

					public int getGrid() {
						return this.grid;
					}

					public int position;

					public int getPosition() {
						return this.position;
					}

					public String positionText;

					public String getPositionText() {
						return this.positionText;
					}

					public String positionOrder;

					public String getPositionOrder() {
						return this.positionOrder;
					}

					public String points;

					public String getPoints() {
						return this.points;
					}

					public String laps;

					public String getLaps() {
						return this.laps;
					}

					public String time;

					public String getTime() {
						return this.time;
					}

					public String milliseconds;

					public String getMilliseconds() {
						return this.milliseconds;
					}

					public String fastestLap;

					public String getFastestLap() {
						return this.fastestLap;
					}

					public String rank;

					public String getRank() {
						return this.rank;
					}

					public String fastestLapTime;

					public String getFastestLapTime() {
						return this.fastestLapTime;
					}

					public String fastestLapSpeed;

					public String getFastestLapSpeed() {
						return this.fastestLapSpeed;
					}

					public int statusId;

					public int getStatusId() {
						return this.statusId;
					}

					public String FastLapandTime;

					public String getFastLapandTime() {
						return this.FastLapandTime;
					}

					public String raceName;

					public String getRaceName() {
						return this.raceName;
					}

					public int year;

					public int getYear() {
						return this.year;
					}

					public int round;

					public int getRound() {
						return this.round;
					}

					public String date;

					public String getDate() {
						return this.date;
					}

					public String time_race;

					public String getTime_race() {
						return this.time_race;
					}

					public String url_race;

					public String getUrl_race() {
						return this.url_race;
					}

					public int circuitId;

					public int getCircuitId() {
						return this.circuitId;
					}

					public String circuitRef;

					public String getCircuitRef() {
						return this.circuitRef;
					}

					public String circuitName;

					public String getCircuitName() {
						return this.circuitName;
					}

					public String location;

					public String getLocation() {
						return this.location;
					}

					public String country;

					public String getCountry() {
						return this.country;
					}

					public String lat;

					public String getLat() {
						return this.lat;
					}

					public String lng;

					public String getLng() {
						return this.lng;
					}

					public String alt;

					public String getAlt() {
						return this.alt;
					}

					public String url_circuit;

					public String getUrl_circuit() {
						return this.url_circuit;
					}

					public String driverRef;

					public String getDriverRef() {
						return this.driverRef;
					}

					public String number_driver;

					public String getNumber_driver() {
						return this.number_driver;
					}

					public String code;

					public String getCode() {
						return this.code;
					}

					public String forename;

					public String getForename() {
						return this.forename;
					}

					public String surname;

					public String getSurname() {
						return this.surname;
					}

					public String dob;

					public String getDob() {
						return this.dob;
					}

					public String nationality;

					public String getNationality() {
						return this.nationality;
					}

					public String url;

					public String getUrl() {
						return this.url;
					}

					public void copyDateToOut(row4Struct other) {
						other.resultId = this.resultId;
						other.raceId = this.raceId;
						other.driverId = this.driverId;
						other.constructorId = this.constructorId;
						other.number = this.number;
						other.grid = this.grid;
						other.position = this.position;
						other.positionText = this.positionText;
						other.positionOrder = this.positionOrder;
						other.points = this.points;
						other.laps = this.laps;
						other.time = this.time;
						other.milliseconds = this.milliseconds;
						other.fastestLap = this.fastestLap;
						other.rank = this.rank;
						other.fastestLapTime = this.fastestLapTime;
						other.fastestLapSpeed = this.fastestLapSpeed;
						other.statusId = this.statusId;
						other.FastLapandTime = this.FastLapandTime;
						other.raceName = this.raceName;
						other.year = this.year;
						other.round = this.round;
						other.date = this.date;
						other.time_race = this.time_race;
						other.url_race = this.url_race;
						other.circuitId = this.circuitId;
						other.circuitRef = this.circuitRef;
						other.circuitName = this.circuitName;
						other.location = this.location;
						other.country = this.country;
						other.lat = this.lat;
						other.lng = this.lng;
						other.alt = this.alt;
						other.url_circuit = this.url_circuit;
						other.driverRef = this.driverRef;
						other.number_driver = this.number_driver;
						other.code = this.code;
						other.forename = this.forename;
						other.surname = this.surname;
						other.dob = this.dob;
						other.nationality = this.nationality;
						other.url = this.url;
					}

					private String readString(ObjectInputStream dis) throws IOException {
						String strReturn = null;
						int length = 0;
						length = dis.readInt();

						if (length == -1) {
							strReturn = null;
						} else {
							if (length > commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length) {
								if (length < 1024 && commonByteArray_TALEND_DEMO_PROJECT_pruebas3.length == 0) {
									commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[1024];
								} else {
									commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[2 * length];
								}
							}
							dis.readFully(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length);
							strReturn = new String(commonByteArray_TALEND_DEMO_PROJECT_pruebas3, 0, length,
									utf8Charset);
						}
						return strReturn;
					}

					private void writeString(String str, ObjectOutputStream dos) throws IOException {
						if (str == null) {
							dos.writeInt(-1);
						} else {
							byte[] byteArray = str.getBytes(utf8Charset);
							dos.writeInt(byteArray.length);
							dos.write(byteArray);
						}
					}

					public void readData(ObjectInputStream dis) {
						synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {
							try {
								int length = 0;
								this.resultId = dis.readInt();
								this.raceId = dis.readInt();
								this.driverId = dis.readInt();
								this.constructorId = dis.readInt();
								this.number = dis.readInt();
								this.grid = dis.readInt();
								this.position = dis.readInt();
								this.positionText = readString(dis);
								this.positionOrder = readString(dis);
								this.points = readString(dis);
								this.laps = readString(dis);
								this.time = readString(dis);
								this.milliseconds = readString(dis);
								this.fastestLap = readString(dis);
								this.rank = readString(dis);
								this.fastestLapTime = readString(dis);
								this.fastestLapSpeed = readString(dis);
								this.statusId = dis.readInt();
								this.FastLapandTime = readString(dis);
								this.raceName = readString(dis);
								this.year = dis.readInt();
								this.round = dis.readInt();
								this.date = readString(dis);
								this.time_race = readString(dis);
								this.url_race = readString(dis);
								this.circuitId = dis.readInt();
								this.circuitRef = readString(dis);
								this.circuitName = readString(dis);
								this.location = readString(dis);
								this.country = readString(dis);
								this.lat = readString(dis);
								this.lng = readString(dis);
								this.alt = readString(dis);
								this.url_circuit = readString(dis);
								this.driverRef = readString(dis);
								this.number_driver = readString(dis);
								this.code = readString(dis);
								this.forename = readString(dis);
								this.surname = readString(dis);
								this.dob = readString(dis);
								this.nationality = readString(dis);
								this.url = readString(dis);
							} catch (IOException e) {
								throw new RuntimeException(e);
							}
						}
					}

					public void writeData(ObjectOutputStream dos) {
						try {
							// int
							dos.writeInt(this.resultId);
							// int
							dos.writeInt(this.raceId);
							// int
							dos.writeInt(this.driverId);
							// int
							dos.writeInt(this.constructorId);
							// int
							dos.writeInt(this.number);
							// int
							dos.writeInt(this.grid);
							// int
							dos.writeInt(this.position);
							// String
							writeString(this.positionText, dos);
							// String
							writeString(this.positionOrder, dos);
							// String
							writeString(this.points, dos);
							// String
							writeString(this.laps, dos);
							// String
							writeString(this.time, dos);
							// String
							writeString(this.milliseconds, dos);
							// String
							writeString(this.fastestLap, dos);
							// String
							writeString(this.rank, dos);
							// String
							writeString(this.fastestLapTime, dos);
							// String
							writeString(this.fastestLapSpeed, dos);
							// int
							dos.writeInt(this.statusId);
							// String
							writeString(this.FastLapandTime, dos);
							// String
							writeString(this.raceName, dos);
							// int
							dos.writeInt(this.year);
							// int
							dos.writeInt(this.round);
							// String
							writeString(this.date, dos);
							// String
							writeString(this.time_race, dos);
							// String
							writeString(this.url_race, dos);
							// int
							dos.writeInt(this.circuitId);
							// String
							writeString(this.circuitRef, dos);
							// String
							writeString(this.circuitName, dos);
							// String
							writeString(this.location, dos);
							// String
							writeString(this.country, dos);
							// String
							writeString(this.lat, dos);
							// String
							writeString(this.lng, dos);
							// String
							writeString(this.alt, dos);
							// String
							writeString(this.url_circuit, dos);
							// String
							writeString(this.driverRef, dos);
							// String
							writeString(this.number_driver, dos);
							// String
							writeString(this.code, dos);
							// String
							writeString(this.forename, dos);
							// String
							writeString(this.surname, dos);
							// String
							writeString(this.dob, dos);
							// String
							writeString(this.nationality, dos);
							// String
							writeString(this.url, dos);
						} catch (IOException e) {
							throw new RuntimeException(e);
						}
					}

					public String toString() {

						StringBuilder sb = new StringBuilder();
						sb.append(super.toString());
						sb.append("[");
						sb.append("," + "resultId=" + String.valueOf(resultId));
						sb.append("," + "raceId=" + String.valueOf(raceId));
						sb.append("," + "driverId=" + String.valueOf(driverId));
						sb.append("," + "constructorId=" + String.valueOf(constructorId));
						sb.append("," + "number=" + String.valueOf(number));
						sb.append("," + "grid=" + String.valueOf(grid));
						sb.append("," + "position=" + String.valueOf(position));
						sb.append("," + "positionText=" + positionText);
						sb.append("," + "positionOrder=" + positionOrder);
						sb.append("," + "points=" + points);
						sb.append("," + "laps=" + laps);
						sb.append("," + "time=" + time);
						sb.append("," + "milliseconds=" + milliseconds);
						sb.append("," + "fastestLap=" + fastestLap);
						sb.append("," + "rank=" + rank);
						sb.append("," + "fastestLapTime=" + fastestLapTime);
						sb.append("," + "fastestLapSpeed=" + fastestLapSpeed);
						sb.append("," + "statusId=" + String.valueOf(statusId));
						sb.append("," + "FastLapandTime=" + FastLapandTime);
						sb.append("," + "raceName=" + raceName);
						sb.append("," + "year=" + String.valueOf(year));
						sb.append("," + "round=" + String.valueOf(round));
						sb.append("," + "date=" + date);
						sb.append("," + "time_race=" + time_race);
						sb.append("," + "url_race=" + url_race);
						sb.append("," + "circuitId=" + String.valueOf(circuitId));
						sb.append("," + "circuitRef=" + circuitRef);
						sb.append("," + "circuitName=" + circuitName);
						sb.append("," + "location=" + location);
						sb.append("," + "country=" + country);
						sb.append("," + "lat=" + lat);
						sb.append("," + "lng=" + lng);
						sb.append("," + "alt=" + alt);
						sb.append("," + "url_circuit=" + url_circuit);
						sb.append("," + "driverRef=" + driverRef);
						sb.append("," + "number_driver=" + number_driver);
						sb.append("," + "code=" + code);
						sb.append("," + "forename=" + forename);
						sb.append("," + "surname=" + surname);
						sb.append("," + "dob=" + dob);
						sb.append("," + "nationality=" + nationality);
						sb.append("," + "url=" + url);
						sb.append("]");
						return sb.toString();
					}

					/**
					 * Compare keys
					 */
					public int compareTo(tMatchGroup_1Struct other) {
						int returnValue = -1;
						return returnValue;
					}

					private int checkNullsAndCompare(Object object1, Object object2) {
						int returnValue = 0;
						if (object1 instanceof Comparable && object2 instanceof Comparable) {
							returnValue = ((Comparable) object1).compareTo(object2);
						} else if (object1 != null && object2 != null) {
							returnValue = compareStrings(object1.toString(), object2.toString());
						} else if (object1 == null && object2 != null) {
							returnValue = 1;
						} else if (object1 != null && object2 == null) {
							returnValue = -1;
						} else {
							returnValue = 0;
						}
						return returnValue;
					}

					private int compareStrings(String string1, String string2) {
						return string1.compareTo(string2);
					}
				}

				class tMatchGroup_1_2Struct
						implements routines.system.IPersistableComparableLookupRow<tMatchGroup_1_2Struct>,
						org.talend.dataquality.indicators.mapdb.helper.IObjectConvertArray {
					final byte[] commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
					byte[] commonByteArray_TALEND_DEMO_PROJECT_pruebas3 = new byte[0];
					private final int DEFAULT_HASHCODE = 1;
					private final int PRIME = 31;
					private int hashCode = DEFAULT_HASHCODE;
					public boolean hashCodeDirty = true;

					public void copyDateToOut(tMatchGroup_1_2Struct other) {
					}

					@Override
					public int hashCode() {
						if (this.hashCodeDirty) {
							final int prime = PRIME;
							int result = DEFAULT_HASHCODE;

							this.hashCode = result;
							this.hashCodeDirty = false;
						}
						return this.hashCode;
					}

					@Override
					public boolean equals(Object obj) {
						if (this == obj)
							return true;
						if (obj == null)
							return false;
						if (getClass() != obj.getClass())
							return false;
						final tMatchGroup_1_2Struct other = (tMatchGroup_1_2Struct) obj;

						return true;
					}

					public void copyDataTo(tMatchGroup_1_2Struct other) {
					}

					public void copyKeysDataTo(tMatchGroup_1_2Struct other) {
					}

					public void readKeysData(ObjectInputStream dis) {
						synchronized (commonByteArrayLock_TALEND_DEMO_PROJECT_pruebas3) {
							try {
								int length = 0;
							} finally {
							}
						}
					}

					public void writeKeysData(ObjectOutputStream dos) {
						try {
						} finally {
						}
					}

					/**
					 * Fill Values data by reading ObjectInputStream.
					 */
					public void readValuesData(DataInputStream dis, ObjectInputStream ois) {

					}

					/**
					 * Return a byte array which represents Values data.
					 */
					public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {

					}

					public String toString() {

						StringBuilder sb = new StringBuilder();
						sb.append(super.toString());
						sb.append("[");
						sb.append("]");
						return sb.toString();
					}

					/**
					 * Compare keys
					 */
					public int compareTo(tMatchGroup_1_2Struct other) {
						int returnValue = -1;
						return returnValue;
					}

					private int checkNullsAndCompare(Object object1, Object object2) {
						int returnValue = 0;
						if (object1 instanceof Comparable && object2 instanceof Comparable) {
							returnValue = ((Comparable) object1).compareTo(object2);
						} else if (object1 != null && object2 != null) {
							returnValue = compareStrings(object1.toString(), object2.toString());
						} else if (object1 == null && object2 != null) {
							returnValue = 1;
						} else if (object1 != null && object2 == null) {
							returnValue = -1;
						} else {
							returnValue = 0;
						}
						return returnValue;
					}

					private int compareStrings(String string1, String string2) {
						return string1.compareTo(string2);
					}

					@Override
					public Object[] getArrays() {
						Object[] array = new Object[0];
						return array;
					}

					@Override
					public void restoreObjectByArrays(Object[] elements) {
					}
				}// end of _2struct

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_tMatchGroup_1 = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_ROWS;
				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<tMatchGroup_1Struct> tHash_Lookup_row1 = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<tMatchGroup_1Struct>getLookup(matchingModeEnum_tMatchGroup_1);
				globalMap.put("tHash_Lookup_row1", tHash_Lookup_row1);

				/* store all block rows */
				java.util.Map<tMatchGroup_1_2Struct, String> blockRows_row1 = new java.util.HashMap<tMatchGroup_1_2Struct, String>();

				/**
				 * [tMatchGroup_1_GroupOut begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("DB_VERSION" + " = " + "MYSQL_5");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("HOST" + " = " + "\"internal.stratebi.com\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("DBNAME" + " = " + "\"SampleData\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("USER" + " = " + "\"sample_user\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:3x3QO/ZPexi/AiunpX84sxYNI7vDvQcthyYapz7U10OCXlHALJyb3x4PrTM=")
									.substring(0, 4) + "...");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"F1_stg_Results\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT    `F1_stg_Results`.`resultId`,    `F1_stg_Results`.`raceId`,    `F1_stg_Results`.`driverId`,    `F1_stg_Results`.`constructorId`,    `F1_stg_Results`.`number`,    `F1_stg_Results`.`grid`,    `F1_stg_Results`.`position`,    `F1_stg_Results`.`positionText`,    `F1_stg_Results`.`positionOrder`,    `F1_stg_Results`.`points`,    `F1_stg_Results`.`laps`,    `F1_stg_Results`.`time`,    `F1_stg_Results`.`milliseconds`,    `F1_stg_Results`.`fastestLap`,    `F1_stg_Results`.`rank`,    `F1_stg_Results`.`fastestLapTime`,    `F1_stg_Results`.`fastestLapSpeed`,    `F1_stg_Results`.`statusId`,    `F1_stg_Results`.`fastLapandTime`,    `F1_stg_Results`.`raceName`,    `F1_stg_Results`.`year`,    `F1_stg_Results`.`round`,    `F1_stg_Results`.`date`,    `F1_stg_Results`.`time_race`,    `F1_stg_Results`.`url_race`,    `F1_stg_Results`.`circuitId`,    `F1_stg_Results`.`circuitRef`,    `F1_stg_Results`.`circuitName`,    `F1_stg_Results`.`location`,    `F1_stg_Results`.`country`,    `F1_stg_Results`.`lat`,    `F1_stg_Results`.`lng`,    `F1_stg_Results`.`alt`,    `F1_stg_Results`.`url_circuit`,    `F1_stg_Results`.`driverRef`,    `F1_stg_Results`.`number_driver`,    `F1_stg_Results`.`code`,    `F1_stg_Results`.`forename`,    `F1_stg_Results`.`surname`,    `F1_stg_Results`.`dob`,    `F1_stg_Results`.`nationality`,    `F1_stg_Results`.`url` FROM `F1_stg_Results`\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("ENABLE_STREAM" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("resultId") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("raceId") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("driverId")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("constructorId") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("number") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("grid") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("position") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("positionText")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("positionOrder") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("points") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("laps") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("time") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("milliseconds")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("fastestLap") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("rank") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("fastestLapTime") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("fastestLapSpeed") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("statusId") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("FastLapandTime") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("raceName")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("year") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("round") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("date") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("time_race")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("url_race") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("circuitId") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("circuitRef") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("circuitName") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("location")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("country") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("lat") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("lng") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("alt") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("url_circuit")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("driverRef") + "}, {TRIM="
									+ ("false") + ", SCHEMA_COLUMN=" + ("number_driver") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("code") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN="
									+ ("forename") + "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("surname")
									+ "}, {TRIM=" + ("false") + ", SCHEMA_COLUMN=" + ("dob") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("nationality") + "}, {TRIM=" + ("false")
									+ ", SCHEMA_COLUMN=" + ("url") + "}]");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				String driverClass_tDBInput_1 = "com.mysql.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBInput_1 = java.lang.Class.forName(driverClass_tDBInput_1);
				String dbUser_tDBInput_1 = "sample_user";

				final String decryptedPassword_tDBInput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:oz0iJIy9k90eCZhGV7uBinVo1ndOjYgcHn/aFULeCAehi+/Aho0m+eGAGns=");

				String dbPwd_tDBInput_1 = decryptedPassword_tDBInput_1;

				String url_tDBInput_1 = "jdbc:mysql://" + "internal.stratebi.com" + ":" + "3306" + "/" + "SampleData"
						+ "?" + "noDatetimeStringSync=true";

				log.debug("tDBInput_1 - Driver ClassName: " + driverClass_tDBInput_1 + ".");

				log.debug("tDBInput_1 - Connection attempt to '" + url_tDBInput_1 + "' with the username '"
						+ dbUser_tDBInput_1 + "'.");

				conn_tDBInput_1 = java.sql.DriverManager.getConnection(url_tDBInput_1, dbUser_tDBInput_1,
						dbPwd_tDBInput_1);
				log.debug("tDBInput_1 - Connection to '" + url_tDBInput_1 + "' has succeeded.");

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT \n  `F1_stg_Results`.`resultId`, \n  `F1_stg_Results`.`raceId`, \n  `F1_stg_Results`.`driverId`, \n  `F1_stg_Results"
						+ "`.`constructorId`, \n  `F1_stg_Results`.`number`, \n  `F1_stg_Results`.`grid`, \n  `F1_stg_Results`.`position`, \n  `F1_stg_"
						+ "Results`.`positionText`, \n  `F1_stg_Results`.`positionOrder`, \n  `F1_stg_Results`.`points`, \n  `F1_stg_Results`.`laps`, "
						+ "\n  `F1_stg_Results`.`time`, \n  `F1_stg_Results`.`milliseconds`, \n  `F1_stg_Results`.`fastestLap`, \n  `F1_stg_Results`.`r"
						+ "ank`, \n  `F1_stg_Results`.`fastestLapTime`, \n  `F1_stg_Results`.`fastestLapSpeed`, \n  `F1_stg_Results`.`statusId`, \n  `F"
						+ "1_stg_Results`.`fastLapandTime`, \n  `F1_stg_Results`.`raceName`, \n  `F1_stg_Results`.`year`, \n  `F1_stg_Results`.`round`"
						+ ", \n  `F1_stg_Results`.`date`, \n  `F1_stg_Results`.`time_race`, \n  `F1_stg_Results`.`url_race`, \n  `F1_stg_Results`.`circ"
						+ "uitId`, \n  `F1_stg_Results`.`circuitRef`, \n  `F1_stg_Results`.`circuitName`, \n  `F1_stg_Results`.`location`, \n  `F1_stg_"
						+ "Results`.`country`, \n  `F1_stg_Results`.`lat`, \n  `F1_stg_Results`.`lng`, \n  `F1_stg_Results`.`alt`, \n  `F1_stg_Results`"
						+ ".`url_circuit`, \n  `F1_stg_Results`.`driverRef`, \n  `F1_stg_Results`.`number_driver`, \n  `F1_stg_Results`.`code`, \n  `F1"
						+ "_stg_Results`.`forename`, \n  `F1_stg_Results`.`surname`, \n  `F1_stg_Results`.`dob`, \n  `F1_stg_Results`.`nationality`, \n"
						+ "  `F1_stg_Results`.`url`\nFROM `F1_stg_Results`";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);
				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							row1.resultId = 0;
						} else {

							row1.resultId = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							row1.raceId = 0;
						} else {

							row1.raceId = rs_tDBInput_1.getInt(2);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							row1.driverId = 0;
						} else {

							row1.driverId = rs_tDBInput_1.getInt(3);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							row1.constructorId = 0;
						} else {

							row1.constructorId = rs_tDBInput_1.getInt(4);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							row1.number = 0;
						} else {

							row1.number = rs_tDBInput_1.getInt(5);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							row1.grid = 0;
						} else {

							row1.grid = rs_tDBInput_1.getInt(6);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							row1.position = 0;
						} else {

							row1.position = rs_tDBInput_1.getInt(7);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							row1.positionText = null;
						} else {

							row1.positionText = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, false);
						}
						if (colQtyInRs_tDBInput_1 < 9) {
							row1.positionOrder = null;
						} else {

							row1.positionOrder = routines.system.JDBCUtil.getString(rs_tDBInput_1, 9, false);
						}
						if (colQtyInRs_tDBInput_1 < 10) {
							row1.points = null;
						} else {

							row1.points = routines.system.JDBCUtil.getString(rs_tDBInput_1, 10, false);
						}
						if (colQtyInRs_tDBInput_1 < 11) {
							row1.laps = null;
						} else {

							row1.laps = routines.system.JDBCUtil.getString(rs_tDBInput_1, 11, false);
						}
						if (colQtyInRs_tDBInput_1 < 12) {
							row1.time = null;
						} else {

							row1.time = routines.system.JDBCUtil.getString(rs_tDBInput_1, 12, false);
						}
						if (colQtyInRs_tDBInput_1 < 13) {
							row1.milliseconds = null;
						} else {

							row1.milliseconds = routines.system.JDBCUtil.getString(rs_tDBInput_1, 13, false);
						}
						if (colQtyInRs_tDBInput_1 < 14) {
							row1.fastestLap = null;
						} else {

							row1.fastestLap = routines.system.JDBCUtil.getString(rs_tDBInput_1, 14, false);
						}
						if (colQtyInRs_tDBInput_1 < 15) {
							row1.rank = null;
						} else {

							row1.rank = routines.system.JDBCUtil.getString(rs_tDBInput_1, 15, false);
						}
						if (colQtyInRs_tDBInput_1 < 16) {
							row1.fastestLapTime = null;
						} else {

							row1.fastestLapTime = routines.system.JDBCUtil.getString(rs_tDBInput_1, 16, false);
						}
						if (colQtyInRs_tDBInput_1 < 17) {
							row1.fastestLapSpeed = null;
						} else {

							row1.fastestLapSpeed = routines.system.JDBCUtil.getString(rs_tDBInput_1, 17, false);
						}
						if (colQtyInRs_tDBInput_1 < 18) {
							row1.statusId = 0;
						} else {

							row1.statusId = rs_tDBInput_1.getInt(18);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 19) {
							row1.FastLapandTime = null;
						} else {

							row1.FastLapandTime = routines.system.JDBCUtil.getString(rs_tDBInput_1, 19, false);
						}
						if (colQtyInRs_tDBInput_1 < 20) {
							row1.raceName = null;
						} else {

							row1.raceName = routines.system.JDBCUtil.getString(rs_tDBInput_1, 20, false);
						}
						if (colQtyInRs_tDBInput_1 < 21) {
							row1.year = 0;
						} else {

							row1.year = rs_tDBInput_1.getInt(21);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 22) {
							row1.round = 0;
						} else {

							row1.round = rs_tDBInput_1.getInt(22);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 23) {
							row1.date = null;
						} else {

							row1.date = routines.system.JDBCUtil.getString(rs_tDBInput_1, 23, false);
						}
						if (colQtyInRs_tDBInput_1 < 24) {
							row1.time_race = null;
						} else {

							row1.time_race = routines.system.JDBCUtil.getString(rs_tDBInput_1, 24, false);
						}
						if (colQtyInRs_tDBInput_1 < 25) {
							row1.url_race = null;
						} else {

							row1.url_race = routines.system.JDBCUtil.getString(rs_tDBInput_1, 25, false);
						}
						if (colQtyInRs_tDBInput_1 < 26) {
							row1.circuitId = 0;
						} else {

							row1.circuitId = rs_tDBInput_1.getInt(26);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 27) {
							row1.circuitRef = null;
						} else {

							row1.circuitRef = routines.system.JDBCUtil.getString(rs_tDBInput_1, 27, false);
						}
						if (colQtyInRs_tDBInput_1 < 28) {
							row1.circuitName = null;
						} else {

							row1.circuitName = routines.system.JDBCUtil.getString(rs_tDBInput_1, 28, false);
						}
						if (colQtyInRs_tDBInput_1 < 29) {
							row1.location = null;
						} else {

							row1.location = routines.system.JDBCUtil.getString(rs_tDBInput_1, 29, false);
						}
						if (colQtyInRs_tDBInput_1 < 30) {
							row1.country = null;
						} else {

							row1.country = routines.system.JDBCUtil.getString(rs_tDBInput_1, 30, false);
						}
						if (colQtyInRs_tDBInput_1 < 31) {
							row1.lat = null;
						} else {

							row1.lat = routines.system.JDBCUtil.getString(rs_tDBInput_1, 31, false);
						}
						if (colQtyInRs_tDBInput_1 < 32) {
							row1.lng = null;
						} else {

							row1.lng = routines.system.JDBCUtil.getString(rs_tDBInput_1, 32, false);
						}
						if (colQtyInRs_tDBInput_1 < 33) {
							row1.alt = null;
						} else {

							row1.alt = routines.system.JDBCUtil.getString(rs_tDBInput_1, 33, false);
						}
						if (colQtyInRs_tDBInput_1 < 34) {
							row1.url_circuit = null;
						} else {

							row1.url_circuit = routines.system.JDBCUtil.getString(rs_tDBInput_1, 34, false);
						}
						if (colQtyInRs_tDBInput_1 < 35) {
							row1.driverRef = null;
						} else {

							row1.driverRef = routines.system.JDBCUtil.getString(rs_tDBInput_1, 35, false);
						}
						if (colQtyInRs_tDBInput_1 < 36) {
							row1.number_driver = null;
						} else {

							row1.number_driver = routines.system.JDBCUtil.getString(rs_tDBInput_1, 36, false);
						}
						if (colQtyInRs_tDBInput_1 < 37) {
							row1.code = null;
						} else {

							row1.code = routines.system.JDBCUtil.getString(rs_tDBInput_1, 37, false);
						}
						if (colQtyInRs_tDBInput_1 < 38) {
							row1.forename = null;
						} else {

							row1.forename = routines.system.JDBCUtil.getString(rs_tDBInput_1, 38, false);
						}
						if (colQtyInRs_tDBInput_1 < 39) {
							row1.surname = null;
						} else {

							row1.surname = routines.system.JDBCUtil.getString(rs_tDBInput_1, 39, false);
						}
						if (colQtyInRs_tDBInput_1 < 40) {
							row1.dob = null;
						} else {

							row1.dob = routines.system.JDBCUtil.getString(rs_tDBInput_1, 40, false);
						}
						if (colQtyInRs_tDBInput_1 < 41) {
							row1.nationality = null;
						} else {

							row1.nationality = routines.system.JDBCUtil.getString(rs_tDBInput_1, 41, false);
						}
						if (colQtyInRs_tDBInput_1 < 42) {
							row1.url = null;
						} else {

							row1.url = routines.system.JDBCUtil.getString(rs_tDBInput_1, 42, false);
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tMatchGroup_1_GroupOut main ] start
						 */

						currentVirtualComponent = "tMatchGroup_1";

						currentComponent = "tMatchGroup_1_GroupOut";

						runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row1");

						if (log.isTraceEnabled()) {
							log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
						}

						tMatchGroup_1Struct row1_HashRow = new tMatchGroup_1Struct();

						row1_HashRow.resultId = row1.resultId;

						row1_HashRow.raceId = row1.raceId;

						row1_HashRow.driverId = row1.driverId;

						row1_HashRow.constructorId = row1.constructorId;

						row1_HashRow.number = row1.number;

						row1_HashRow.grid = row1.grid;

						row1_HashRow.position = row1.position;

						row1_HashRow.positionText = row1.positionText;

						row1_HashRow.positionOrder = row1.positionOrder;

						row1_HashRow.points = row1.points;

						row1_HashRow.laps = row1.laps;

						row1_HashRow.time = row1.time;

						row1_HashRow.milliseconds = row1.milliseconds;

						row1_HashRow.fastestLap = row1.fastestLap;

						row1_HashRow.rank = row1.rank;

						row1_HashRow.fastestLapTime = row1.fastestLapTime;

						row1_HashRow.fastestLapSpeed = row1.fastestLapSpeed;

						row1_HashRow.statusId = row1.statusId;

						row1_HashRow.FastLapandTime = row1.FastLapandTime;

						row1_HashRow.raceName = row1.raceName;

						row1_HashRow.year = row1.year;

						row1_HashRow.round = row1.round;

						row1_HashRow.date = row1.date;

						row1_HashRow.time_race = row1.time_race;

						row1_HashRow.url_race = row1.url_race;

						row1_HashRow.circuitId = row1.circuitId;

						row1_HashRow.circuitRef = row1.circuitRef;

						row1_HashRow.circuitName = row1.circuitName;

						row1_HashRow.location = row1.location;

						row1_HashRow.country = row1.country;

						row1_HashRow.lat = row1.lat;

						row1_HashRow.lng = row1.lng;

						row1_HashRow.alt = row1.alt;

						row1_HashRow.url_circuit = row1.url_circuit;

						row1_HashRow.driverRef = row1.driverRef;

						row1_HashRow.number_driver = row1.number_driver;

						row1_HashRow.code = row1.code;

						row1_HashRow.forename = row1.forename;

						row1_HashRow.surname = row1.surname;

						row1_HashRow.dob = row1.dob;

						row1_HashRow.nationality = row1.nationality;

						row1_HashRow.url = row1.url;
						tHash_Lookup_row1.put(row1_HashRow);

						tos_count_tMatchGroup_1_GroupOut++;

						/**
						 * [tMatchGroup_1_GroupOut main ] stop
						 */

						/**
						 * [tMatchGroup_1_GroupOut process_data_begin ] start
						 */

						currentVirtualComponent = "tMatchGroup_1";

						currentComponent = "tMatchGroup_1_GroupOut";

						/**
						 * [tMatchGroup_1_GroupOut process_data_begin ] stop
						 */

						/**
						 * [tMatchGroup_1_GroupOut process_data_end ] start
						 */

						currentVirtualComponent = "tMatchGroup_1";

						currentComponent = "tMatchGroup_1_GroupOut";

						/**
						 * [tMatchGroup_1_GroupOut process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
					if (conn_tDBInput_1 != null && !conn_tDBInput_1.isClosed()) {

						log.debug("tDBInput_1 - Closing the connection to the database.");

						conn_tDBInput_1.close();

						if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_"))
								&& routines.system.BundleUtils.inOSGi()) {
							Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread")
									.getMethod("checkedShutdown").invoke(null, (Object[]) null);
						}

						log.debug("tDBInput_1 - Connection to the database closed.");

					}

				}

				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);

				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupOut end ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupOut";

				tHash_Lookup_row1.endPut();
				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						talendJobLog, "tDBInput_1", "tMysqlInput", "tMatchGroup_1_GroupOut", "tMatchGroupOut",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMatchGroup_1_GroupOut - " + ("Done."));

				ok_Hash.put("tMatchGroup_1_GroupOut", true);
				end_Hash.put("tMatchGroup_1_GroupOut", System.currentTimeMillis());

				/**
				 * [tMatchGroup_1_GroupOut end ] stop
				 */

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "out4");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("DB_VERSION" + " = " + "MYSQL_5");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("HOST" + " = " + "\"internal.stratebi.com\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DBNAME" + " = " + "\"SampleData\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USER" + " = " + "\"sample_user\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:FpN+CrHWwp9gYwgxa44bB2kbEMV7Dnj+iv1Jl3MQ1bikv1kiETeyEkYbGMA=")
									.substring(0, 4) + "...");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"F1\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "CREATE_IF_NOT_EXISTS");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("EXTENDINSERT" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("NB_ROWS_PER_INSERT" + " = " + "100");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("COMMIT_EVERY" + " = " + "10000");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ON_DUPLICATE_KEY_UPDATE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;

				int rejectedCount_tDBOutput_1 = 0;

				String tableName_tDBOutput_1 = "F1";
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				long date_tDBOutput_1;

				java.sql.Connection conn_tDBOutput_1 = null;
				String dbProperties_tDBOutput_1 = "noDatetimeStringSync=true";
				String url_tDBOutput_1 = null;
				if (dbProperties_tDBOutput_1 == null || dbProperties_tDBOutput_1.trim().length() == 0) {
					url_tDBOutput_1 = "jdbc:mysql://" + "internal.stratebi.com" + ":" + "3306" + "/" + "SampleData"
							+ "?" + "rewriteBatchedStatements=true";
				} else {
					String properties_tDBOutput_1 = "noDatetimeStringSync=true";
					if (!properties_tDBOutput_1.contains("rewriteBatchedStatements")) {
						properties_tDBOutput_1 += "&rewriteBatchedStatements=true";
					}

					url_tDBOutput_1 = "jdbc:mysql://" + "internal.stratebi.com" + ":" + "3306" + "/" + "SampleData"
							+ "?" + properties_tDBOutput_1;
				}
				String driverClass_tDBOutput_1 = "com.mysql.jdbc.Driver";

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Driver ClassName: ") + (driverClass_tDBOutput_1) + ("."));
				String dbUser_tDBOutput_1 = "sample_user";

				final String decryptedPassword_tDBOutput_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:CSRkjuxyIcrQIDDhPjTAwpPJmdghCeQbuZJK743dmHa0wTYMXJRnHe52oNY=");

				String dbPwd_tDBOutput_1 = decryptedPassword_tDBOutput_1;
				java.lang.Class.forName(driverClass_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection attempts to '") + (url_tDBOutput_1)
							+ ("' with the username '") + (dbUser_tDBOutput_1) + ("'."));
				conn_tDBOutput_1 = java.sql.DriverManager.getConnection(url_tDBOutput_1, dbUser_tDBOutput_1,
						dbPwd_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to '") + (url_tDBOutput_1) + ("' has succeeded."));

				resourceMap.put("conn_tDBOutput_1", conn_tDBOutput_1);
				conn_tDBOutput_1.setAutoCommit(false);
				int commitEvery_tDBOutput_1 = 10000;
				int commitCounter_tDBOutput_1 = 0;
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));

				int count_tDBOutput_1 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
				boolean whetherExist_tDBOutput_1 = false;
				try (java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables("SampleData", null, null,
						new String[] { "TABLE" })) {
					while (rsTable_tDBOutput_1.next()) {
						String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
						if (table_tDBOutput_1.equalsIgnoreCase("F1")) {
							whetherExist_tDBOutput_1 = true;
							break;
						}
					}
				}
				if (!whetherExist_tDBOutput_1) {
					try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_1 - " + ("Creating") + (" table '") + (tableName_tDBOutput_1) + ("'."));
						stmtCreate_tDBOutput_1.execute("CREATE TABLE `" + tableName_tDBOutput_1
								+ "`(`Id_Result` INT(25)   not null ,`Id_Driver` INT(25)   not null ,`Id_Constructor` INT(25)   not null ,`Id_Race` INT(25)   not null ,`Id_circuit` INT(20)   not null ,`Id_Status` INT(25)   not null ,`DriverRef` VARCHAR(200)   not null ,`DriverNumber` VARCHAR(200)   not null ,`Code` VARCHAR(200)   not null ,`Forename` VARCHAR(200)   not null ,`Surname` VARCHAR(200)   not null ,`Dob` VARCHAR(200)   not null ,`Nationality` VARCHAR(200)   not null ,`Number` INT(200)   not null ,`Grid` INT(200)   not null ,`Position` INT(200)   not null ,`PositionText` VARCHAR(5000)   not null ,`PositionOrder` VARCHAR(200)   not null ,`Points` VARCHAR(200)   not null ,`Laps` VARCHAR(200)   not null ,`Time` VARCHAR(200)   not null ,`Milliseconds` VARCHAR(200)   not null ,`FastestLap` VARCHAR(200)   not null ,`Rank` VARCHAR(200)   not null ,`FastestLapTime` VARCHAR(200)   not null ,`FastestLapSpeed` VARCHAR(200)   not null ,`fastLapandTime` VARCHAR(200)   not null ,`RaceName` VARCHAR(200)   not null ,`RaceYear` INT(20)   not null ,`Round` INT(20)   not null ,`RaceDate` VARCHAR(200)   not null ,`RaceTime` VARCHAR(200)   not null ,`CircuitRef` VARCHAR(200)   not null ,`CircuitName` VARCHAR(200)   not null ,`CircuitLocation` VARCHAR(200)   not null ,`CircuitCountry` VARCHAR(200)   not null ,`Lat` VARCHAR(200)   not null ,`Lng` VARCHAR(200)   not null ,`Alt` VARCHAR(200)   not null )");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Create") + (" table '") + (tableName_tDBOutput_1)
									+ ("' has succeeded."));
					}
				}

				String insert_tDBOutput_1 = "INSERT INTO `" + "F1"
						+ "` (`Id_Result`,`Id_Driver`,`Id_Constructor`,`Id_Race`,`Id_circuit`,`Id_Status`,`DriverRef`,`DriverNumber`,`Code`,`Forename`,`Surname`,`Dob`,`Nationality`,`Number`,`Grid`,`Position`,`PositionText`,`PositionOrder`,`Points`,`Laps`,`Time`,`Milliseconds`,`FastestLap`,`Rank`,`FastestLapTime`,`FastestLapSpeed`,`fastLapandTime`,`RaceName`,`RaceYear`,`Round`,`RaceDate`,`RaceTime`,`CircuitRef`,`CircuitName`,`CircuitLocation`,`CircuitCountry`,`Lat`,`Lng`,`Alt`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				int batchSize_tDBOutput_1 = 100;
				int batchSizeCounter_tDBOutput_1 = 0;

				java.sql.PreparedStatement pstmt_tDBOutput_1 = conn_tDBOutput_1.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmt_tDBOutput_1", pstmt_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row2");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row2_tMap_1 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out4_tMap_1 = 0;

				out4Struct out4_tmp = new out4Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row3");

				int tos_count_tLogRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
							log4jParamters_tLogRow_1.append("Parameters:");
							log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_1 - " + (log4jParamters_tLogRow_1));
						}
					}
					new BytesLimit65535_tLogRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_1", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_1 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[47];

					public void addRow(String[] row) {

						for (int i = 0; i < 47; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 46 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 46 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|%11$-");
							sbformat.append(colLengths[10]);
							sbformat.append("s");

							sbformat.append("|%12$-");
							sbformat.append(colLengths[11]);
							sbformat.append("s");

							sbformat.append("|%13$-");
							sbformat.append(colLengths[12]);
							sbformat.append("s");

							sbformat.append("|%14$-");
							sbformat.append(colLengths[13]);
							sbformat.append("s");

							sbformat.append("|%15$-");
							sbformat.append(colLengths[14]);
							sbformat.append("s");

							sbformat.append("|%16$-");
							sbformat.append(colLengths[15]);
							sbformat.append("s");

							sbformat.append("|%17$-");
							sbformat.append(colLengths[16]);
							sbformat.append("s");

							sbformat.append("|%18$-");
							sbformat.append(colLengths[17]);
							sbformat.append("s");

							sbformat.append("|%19$-");
							sbformat.append(colLengths[18]);
							sbformat.append("s");

							sbformat.append("|%20$-");
							sbformat.append(colLengths[19]);
							sbformat.append("s");

							sbformat.append("|%21$-");
							sbformat.append(colLengths[20]);
							sbformat.append("s");

							sbformat.append("|%22$-");
							sbformat.append(colLengths[21]);
							sbformat.append("s");

							sbformat.append("|%23$-");
							sbformat.append(colLengths[22]);
							sbformat.append("s");

							sbformat.append("|%24$-");
							sbformat.append(colLengths[23]);
							sbformat.append("s");

							sbformat.append("|%25$-");
							sbformat.append(colLengths[24]);
							sbformat.append("s");

							sbformat.append("|%26$-");
							sbformat.append(colLengths[25]);
							sbformat.append("s");

							sbformat.append("|%27$-");
							sbformat.append(colLengths[26]);
							sbformat.append("s");

							sbformat.append("|%28$-");
							sbformat.append(colLengths[27]);
							sbformat.append("s");

							sbformat.append("|%29$-");
							sbformat.append(colLengths[28]);
							sbformat.append("s");

							sbformat.append("|%30$-");
							sbformat.append(colLengths[29]);
							sbformat.append("s");

							sbformat.append("|%31$-");
							sbformat.append(colLengths[30]);
							sbformat.append("s");

							sbformat.append("|%32$-");
							sbformat.append(colLengths[31]);
							sbformat.append("s");

							sbformat.append("|%33$-");
							sbformat.append(colLengths[32]);
							sbformat.append("s");

							sbformat.append("|%34$-");
							sbformat.append(colLengths[33]);
							sbformat.append("s");

							sbformat.append("|%35$-");
							sbformat.append(colLengths[34]);
							sbformat.append("s");

							sbformat.append("|%36$-");
							sbformat.append(colLengths[35]);
							sbformat.append("s");

							sbformat.append("|%37$-");
							sbformat.append(colLengths[36]);
							sbformat.append("s");

							sbformat.append("|%38$-");
							sbformat.append(colLengths[37]);
							sbformat.append("s");

							sbformat.append("|%39$-");
							sbformat.append(colLengths[38]);
							sbformat.append("s");

							sbformat.append("|%40$-");
							sbformat.append(colLengths[39]);
							sbformat.append("s");

							sbformat.append("|%41$-");
							sbformat.append(colLengths[40]);
							sbformat.append("s");

							sbformat.append("|%42$-");
							sbformat.append(colLengths[41]);
							sbformat.append("s");

							sbformat.append("|%43$-");
							sbformat.append(colLengths[42]);
							sbformat.append("s");

							sbformat.append("|%44$-");
							sbformat.append(colLengths[43]);
							sbformat.append("s");

							sbformat.append("|%45$-");
							sbformat.append(colLengths[44]);
							sbformat.append("s");

							sbformat.append("|%46$-");
							sbformat.append(colLengths[45]);
							sbformat.append("s");

							sbformat.append("|%47$-");
							sbformat.append(colLengths[46]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[27] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[28] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[29] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[30] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[31] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[32] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[33] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[34] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[35] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[36] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[37] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[38] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[39] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[40] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[41] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[42] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[43] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[44] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[45] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[46] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
				util_tLogRow_1.setTableName("tLogRow_1");
				util_tLogRow_1.addRow(new String[] { "resultId", "raceId", "driverId", "constructorId", "number",
						"grid", "position", "positionText", "positionOrder", "points", "laps", "time", "milliseconds",
						"fastestLap", "rank", "fastestLapTime", "fastestLapSpeed", "statusId", "FastLapandTime",
						"raceName", "year", "round", "date", "time_race", "url_race", "circuitId", "circuitRef",
						"circuitName", "location", "country", "lat", "lng", "alt", "url_circuit", "driverRef",
						"number_driver", "code", "forename", "surname", "dob", "nationality", "url", "GID", "GRP_SIZE",
						"MASTER", "SCORE", "GRP_QUALITY", });
				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortOut begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortOut", false);
				start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row4");

				int tos_count_tSortRow_1_SortOut = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortOut - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_1_SortOut {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_1_SortOut = new StringBuilder();
							log4jParamters_tSortRow_1_SortOut.append("Parameters:");
							log4jParamters_tSortRow_1_SortOut.append("DESTINATION" + " = " + "tSortRow_1");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							log4jParamters_tSortRow_1_SortOut.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							log4jParamters_tSortRow_1_SortOut.append("CRITERIA" + " = " + "[{ORDER=" + ("asc")
									+ ", COLNAME=" + ("driverId") + ", SORT=" + ("num") + "}]");
							log4jParamters_tSortRow_1_SortOut.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_1_SortOut - " + (log4jParamters_tSortRow_1_SortOut));
						}
					}
					new BytesLimit65535_tSortRow_1_SortOut().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_1_SortOut", "tSortOut");
					talendJobLogProcess(globalMap);
				}

				class Comparablerow4Struct extends row4Struct implements Comparable<Comparablerow4Struct> {

					public int compareTo(Comparablerow4Struct other) {

						if (this.driverId != other.driverId) {

							return this.driverId > other.driverId ? 1 : -1;

						}
						return 0;
					}
				}

				java.util.List<Comparablerow4Struct> list_tSortRow_1_SortOut = new java.util.ArrayList<Comparablerow4Struct>();

				/**
				 * [tSortRow_1_SortOut begin ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupIn begin ] start
				 */

				ok_Hash.put("tMatchGroup_1_GroupIn", false);
				start_Hash.put("tMatchGroup_1_GroupIn", System.currentTimeMillis());

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupIn";

				int tos_count_tMatchGroup_1_GroupIn = 0;

				if (log.isDebugEnabled())
					log.debug("tMatchGroup_1_GroupIn - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMatchGroup_1_GroupIn {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMatchGroup_1_GroupIn = new StringBuilder();
							log4jParamters_tMatchGroup_1_GroupIn.append("Parameters:");
							log4jParamters_tMatchGroup_1_GroupIn
									.append("MATCHING_ALGORITHM" + " = " + "Simple VSR Matcher");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("STORE_ON_DISK" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("SEPARATE_OUTPUT" + " = " + "true");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("CONFIDENCE_THRESHOLD" + " = " + "0.9");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("LINK_WITH_PREVIOUS" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("SORT_DATA" + " = " + "true");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn.append("OUTPUTDD" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							log4jParamters_tMatchGroup_1_GroupIn
									.append("DEACTIVATE_MATCHING_COMPUTATION" + " = " + "false");
							log4jParamters_tMatchGroup_1_GroupIn.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMatchGroup_1_GroupIn - " + (log4jParamters_tMatchGroup_1_GroupIn));
						}
					}
					new BytesLimit65535_tMatchGroup_1_GroupIn().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMatchGroup_1_GroupIn", "tMatchGroupIn");
					talendJobLogProcess(globalMap);
				}

				/**
				 * [tMatchGroup_1_GroupIn begin ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupIn main ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupIn";

				java.util.List<java.util.List<java.util.Map<String, String>>> matchingRulesAll_tMatchGroup_1 = new java.util.ArrayList<java.util.List<java.util.Map<String, String>>>();
				java.util.List<java.util.Map<String, String>> matcherList_tMatchGroup_1 = null;
				java.util.Map<String, String> tmpMap_tMatchGroup_1 = null;
				java.util.Map<String, String> paramMapTmp_tMatchGroup_1 = null;
				java.util.List<java.util.Map<String, String>> defaultSurvivorshipRules_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
				java.util.List<java.util.Map<String, String>> particularSurvivorshipRules_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
				matcherList_tMatchGroup_1 = new java.util.ArrayList<java.util.Map<String, String>>();
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "Jaro");
				tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD", 0.85 + "");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "raceName");
				tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION", "Concatenate");
				tmpMap_tMatchGroup_1.put("HANDLE_NULL", "nullMatchNone");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD", 1.0 + "");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "19");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 1 + "");
				tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM", "Simple VSR Matcher");
				tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE", "No");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "Jaro");
				tmpMap_tMatchGroup_1.put("RECORD_MATCH_THRESHOLD", 0.85 + "");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "surname");
				tmpMap_tMatchGroup_1.put("SURVIVORSHIP_FUNCTION", "Concatenate");
				tmpMap_tMatchGroup_1.put("HANDLE_NULL", "nullMatchNone");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_THRESHOLD", 1.0 + "");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "38");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 1 + "");
				tmpMap_tMatchGroup_1.put("MATCHING_ALGORITHM", "Simple VSR Matcher");
				tmpMap_tMatchGroup_1.put("TOKENIZATION_TYPE", "No");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "0");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "resultId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "resultId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "0");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "1");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "raceId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "raceId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "1");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "2");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "driverId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "driverId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "2");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "3");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "constructorId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "constructorId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "3");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "4");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "number");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "number");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "4");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "5");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "grid");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "grid");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "5");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "6");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "position");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "position");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "6");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "7");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "positionText");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "positionText");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "7");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "8");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "positionOrder");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "positionOrder");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "8");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "9");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "points");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "points");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "9");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "10");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "laps");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "laps");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "10");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "11");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "time");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "time");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "11");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "12");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "milliseconds");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "milliseconds");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "12");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "13");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "fastestLap");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "fastestLap");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "13");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "14");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "rank");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "rank");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "14");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "15");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "fastestLapTime");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "fastestLapTime");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "15");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "16");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "fastestLapSpeed");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "fastestLapSpeed");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "16");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "17");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "statusId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "statusId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "17");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "18");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "FastLapandTime");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "FastLapandTime");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "18");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "20");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "year");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "year");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "20");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "21");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "round");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "round");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "21");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "22");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "date");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "date");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "22");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "23");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "time_race");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "time_race");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "23");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "24");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "url_race");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "url_race");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "24");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "25");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "circuitId");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "circuitId");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "25");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "26");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "circuitRef");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "circuitRef");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "26");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "27");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "circuitName");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "circuitName");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "27");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "28");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "location");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "location");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "28");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "29");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "country");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "country");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "29");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "30");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "lat");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "lat");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "30");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "31");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "lng");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "lng");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "31");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "32");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "alt");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "alt");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "32");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "33");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "url_circuit");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "url_circuit");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "33");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "34");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "driverRef");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "driverRef");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "34");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "35");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "number_driver");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "number_driver");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "35");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "36");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "code");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "code");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "36");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "37");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "forename");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "forename");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "37");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "39");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "dob");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "dob");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "39");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "40");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "nationality");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "nationality");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "40");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				tmpMap_tMatchGroup_1 = new java.util.HashMap<String, String>();
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN_IDX", "41");
				tmpMap_tMatchGroup_1.put("REFERENCE_COLUMN", "url");
				tmpMap_tMatchGroup_1.put("MATCHING_TYPE", "dummy");
				tmpMap_tMatchGroup_1.put("ATTRIBUTE_NAME", "url");
				tmpMap_tMatchGroup_1.put("COLUMN_IDX", "41");
				tmpMap_tMatchGroup_1.put("CONFIDENCE_WEIGHT", 0 + "");
				matcherList_tMatchGroup_1.add(tmpMap_tMatchGroup_1);
				java.util.Collections.sort(matcherList_tMatchGroup_1, new Comparator<java.util.Map<String, String>>() {

					@Override
					public int compare(java.util.Map<String, String> map1, java.util.Map<String, String> map2) {

						return Integer.valueOf(map1.get("COLUMN_IDX"))
								.compareTo(Integer.valueOf(map2.get("COLUMN_IDX")));
					}

				});
				matchingRulesAll_tMatchGroup_1.add(matcherList_tMatchGroup_1);
				java.util.Map<String, String> realSurShipMap_tMatchGroup_1 = null;
				realSurShipMap_tMatchGroup_1 = null;
				if (matchingRulesAll_tMatchGroup_1.size() == 0) {
					// If no matching rules in external data, try to get to rule from JOIN_KEY table
					// (which will be compatible to old version less than 5.3)
				}

				row4Struct mainOutput_tMatchGroup_1 = null; // main output is used even in "separate output" mode
				row4Struct masterRow_tMatchGroup_1 = null; // a master-row in a group
				row4Struct subRow_tMatchGroup_1 = null; // a sub-row in a group.
// key row
				tMatchGroup_1Struct hashKey_row1 = new tMatchGroup_1Struct();
// rows respond to key row 
				tMatchGroup_1Struct hashValue_row1 = new tMatchGroup_1Struct();
				java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap_tMatchGroup_1 = (java.util.concurrent.ConcurrentHashMap) globalMap
						.get("concurrentHashMap");
				concurrentHashMap_tMatchGroup_1.putIfAbsent("gid_tMatchGroup_1",
						new java.util.concurrent.atomic.AtomicLong(0L));
				java.util.concurrent.atomic.AtomicLong gid_tMatchGroup_1 = (java.util.concurrent.atomic.AtomicLong) concurrentHashMap_tMatchGroup_1
						.get("gid_tMatchGroup_1");
// master rows in a group
				final java.util.List<row4Struct> masterRows_tMatchGroup_1 = new java.util.ArrayList<row4Struct>();
// all rows in a group 
				final java.util.List<row4Struct> groupRows_tMatchGroup_1 = new java.util.ArrayList<row4Struct>();
// this Map key is MASTER GID,value is this MASTER index of all MASTERS.it will be used to get DUPLICATE GRP_QUALITY from MASTER and only in case of separate output.
				final java.util.Map<String, Double> gID2GQMap_tMatchGroup_1 = new java.util.HashMap<String, Double>();
				final double CONFIDENCE_THRESHOLD_tMatchGroup_1 = Double.valueOf(0.9);

//Long gid_tMatchGroup_1 = 0L;
				boolean forceLoop_tMatchGroup_1 = (blockRows_row1.isEmpty());
				java.util.Iterator<tMatchGroup_1_2Struct> iter_tMatchGroup_1 = blockRows_row1.keySet().iterator();

//TDQ-9172 reuse JAVA API at here.

				org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object> recordGroupImp_tMatchGroup_1;
				recordGroupImp_tMatchGroup_1 = new org.talend.dataquality.record.linkage.grouping.AbstractRecordGrouping<Object>() {
					@Override
					protected void outputRow(Object[] row) {
						row4Struct outStuct_tMatchGroup_1 = new row4Struct();
						boolean isMaster = false;

						if (0 < row.length) {
							outStuct_tMatchGroup_1.resultId = row[0] == null ? null : (Integer) row[0];
						}

						if (1 < row.length) {
							outStuct_tMatchGroup_1.raceId = row[1] == null ? null : (Integer) row[1];
						}

						if (2 < row.length) {
							outStuct_tMatchGroup_1.driverId = row[2] == null ? null : (Integer) row[2];
						}

						if (3 < row.length) {
							outStuct_tMatchGroup_1.constructorId = row[3] == null ? null : (Integer) row[3];
						}

						if (4 < row.length) {
							outStuct_tMatchGroup_1.number = row[4] == null ? null : (Integer) row[4];
						}

						if (5 < row.length) {
							outStuct_tMatchGroup_1.grid = row[5] == null ? null : (Integer) row[5];
						}

						if (6 < row.length) {
							outStuct_tMatchGroup_1.position = row[6] == null ? null : (Integer) row[6];
						}

						if (7 < row.length) {
							outStuct_tMatchGroup_1.positionText = row[7] == null ? null : (String) row[7];
						}

						if (8 < row.length) {
							outStuct_tMatchGroup_1.positionOrder = row[8] == null ? null : (String) row[8];
						}

						if (9 < row.length) {
							outStuct_tMatchGroup_1.points = row[9] == null ? null : (String) row[9];
						}

						if (10 < row.length) {
							outStuct_tMatchGroup_1.laps = row[10] == null ? null : (String) row[10];
						}

						if (11 < row.length) {
							outStuct_tMatchGroup_1.time = row[11] == null ? null : (String) row[11];
						}

						if (12 < row.length) {
							outStuct_tMatchGroup_1.milliseconds = row[12] == null ? null : (String) row[12];
						}

						if (13 < row.length) {
							outStuct_tMatchGroup_1.fastestLap = row[13] == null ? null : (String) row[13];
						}

						if (14 < row.length) {
							outStuct_tMatchGroup_1.rank = row[14] == null ? null : (String) row[14];
						}

						if (15 < row.length) {
							outStuct_tMatchGroup_1.fastestLapTime = row[15] == null ? null : (String) row[15];
						}

						if (16 < row.length) {
							outStuct_tMatchGroup_1.fastestLapSpeed = row[16] == null ? null : (String) row[16];
						}

						if (17 < row.length) {
							outStuct_tMatchGroup_1.statusId = row[17] == null ? null : (Integer) row[17];
						}

						if (18 < row.length) {
							outStuct_tMatchGroup_1.FastLapandTime = row[18] == null ? null : (String) row[18];
						}

						if (19 < row.length) {
							outStuct_tMatchGroup_1.raceName = row[19] == null ? null : (String) row[19];
						}

						if (20 < row.length) {
							outStuct_tMatchGroup_1.year = row[20] == null ? null : (Integer) row[20];
						}

						if (21 < row.length) {
							outStuct_tMatchGroup_1.round = row[21] == null ? null : (Integer) row[21];
						}

						if (22 < row.length) {
							outStuct_tMatchGroup_1.date = row[22] == null ? null : (String) row[22];
						}

						if (23 < row.length) {
							outStuct_tMatchGroup_1.time_race = row[23] == null ? null : (String) row[23];
						}

						if (24 < row.length) {
							outStuct_tMatchGroup_1.url_race = row[24] == null ? null : (String) row[24];
						}

						if (25 < row.length) {
							outStuct_tMatchGroup_1.circuitId = row[25] == null ? null : (Integer) row[25];
						}

						if (26 < row.length) {
							outStuct_tMatchGroup_1.circuitRef = row[26] == null ? null : (String) row[26];
						}

						if (27 < row.length) {
							outStuct_tMatchGroup_1.circuitName = row[27] == null ? null : (String) row[27];
						}

						if (28 < row.length) {
							outStuct_tMatchGroup_1.location = row[28] == null ? null : (String) row[28];
						}

						if (29 < row.length) {
							outStuct_tMatchGroup_1.country = row[29] == null ? null : (String) row[29];
						}

						if (30 < row.length) {
							outStuct_tMatchGroup_1.lat = row[30] == null ? null : (String) row[30];
						}

						if (31 < row.length) {
							outStuct_tMatchGroup_1.lng = row[31] == null ? null : (String) row[31];
						}

						if (32 < row.length) {
							outStuct_tMatchGroup_1.alt = row[32] == null ? null : (String) row[32];
						}

						if (33 < row.length) {
							outStuct_tMatchGroup_1.url_circuit = row[33] == null ? null : (String) row[33];
						}

						if (34 < row.length) {
							outStuct_tMatchGroup_1.driverRef = row[34] == null ? null : (String) row[34];
						}

						if (35 < row.length) {
							outStuct_tMatchGroup_1.number_driver = row[35] == null ? null : (String) row[35];
						}

						if (36 < row.length) {
							outStuct_tMatchGroup_1.code = row[36] == null ? null : (String) row[36];
						}

						if (37 < row.length) {
							outStuct_tMatchGroup_1.forename = row[37] == null ? null : (String) row[37];
						}

						if (38 < row.length) {
							outStuct_tMatchGroup_1.surname = row[38] == null ? null : (String) row[38];
						}

						if (39 < row.length) {
							outStuct_tMatchGroup_1.dob = row[39] == null ? null : (String) row[39];
						}

						if (40 < row.length) {
							outStuct_tMatchGroup_1.nationality = row[40] == null ? null : (String) row[40];
						}

						if (41 < row.length) {
							outStuct_tMatchGroup_1.url = row[41] == null ? null : (String) row[41];
						}

						if (42 < row.length) {
							outStuct_tMatchGroup_1.GID = row[42] == null ? null : (String) row[42];
						}

						if (43 < row.length) {
							outStuct_tMatchGroup_1.GRP_SIZE = row[43] == null ? null : (Integer) row[43];
						}

						if (44 < row.length) {
							outStuct_tMatchGroup_1.MASTER = row[44] == null ? null : (Boolean) row[44];
						}

						if (45 < row.length) {
							outStuct_tMatchGroup_1.SCORE = row[45] == null ? null : (Double) row[45];
						}

						if (46 < row.length) {
							outStuct_tMatchGroup_1.GRP_QUALITY = row[46] == null ? null : (Double) row[46];
						}

						if (outStuct_tMatchGroup_1.MASTER == true) {
							masterRows_tMatchGroup_1.add(outStuct_tMatchGroup_1);
							gID2GQMap_tMatchGroup_1.put(String.valueOf(outStuct_tMatchGroup_1.GID),
									outStuct_tMatchGroup_1.GRP_QUALITY);
						} else {
							groupRows_tMatchGroup_1.add(outStuct_tMatchGroup_1);
						}
					}

					@Override
					protected boolean isMaster(Object col) {
						return String.valueOf(col).equals("true");
					}

					@Override
					protected Object incrementGroupSize(Object oldGroupSize) {
						return Integer.parseInt(String.valueOf(oldGroupSize)) + 1;
					}

					@Override
					protected Object[] createTYPEArray(int size) {
						return new Object[size];
					}

					@Override
					protected Object castAsType(Object objectValue) {
						return objectValue;
					}

					@Override
					protected void outputRow(org.talend.dataquality.record.linkage.grouping.swoosh.RichRecord row) {
						// No implementation temporarily.

					}
				};
				recordGroupImp_tMatchGroup_1.setOrginalInputColumnSize(42);

				recordGroupImp_tMatchGroup_1.setColumnDelimiter(";");
				recordGroupImp_tMatchGroup_1.setIsOutputDistDetails(false);

				recordGroupImp_tMatchGroup_1.setAcceptableThreshold(Float.valueOf(0.85 + ""));
				recordGroupImp_tMatchGroup_1.setIsLinkToPrevious(false && true);
				recordGroupImp_tMatchGroup_1.setIsDisplayAttLabels(false);
				recordGroupImp_tMatchGroup_1.setIsGIDStringType("true".equals("true") ? true : false);
				recordGroupImp_tMatchGroup_1.setIsPassOriginalValue(false && false);
				recordGroupImp_tMatchGroup_1.setIsStoreOndisk(false);
				gID2GQMap_tMatchGroup_1.clear();

				while (iter_tMatchGroup_1.hasNext() || forceLoop_tMatchGroup_1) { // C_01

					if (forceLoop_tMatchGroup_1) {
						forceLoop_tMatchGroup_1 = false;
					} else {
						// block existing

					}
					tHash_Lookup_row1.lookup(hashKey_row1);
					masterRows_tMatchGroup_1.clear();
					groupRows_tMatchGroup_1.clear();

					// add mutch rules
					for (java.util.List<java.util.Map<String, String>> matcherList : matchingRulesAll_tMatchGroup_1) {
						recordGroupImp_tMatchGroup_1.addMatchRule(matcherList);
					}
					recordGroupImp_tMatchGroup_1.initialize();

					while (tHash_Lookup_row1.hasNext()) { // loop on each data in one block
						hashValue_row1 = tHash_Lookup_row1.next();
						// set the a loop data into inputTexts one column by one column.
						java.util.List<Object> inputTexts = new java.util.ArrayList<Object>();
						inputTexts.add(hashValue_row1.resultId);

						inputTexts.add(hashValue_row1.raceId);

						inputTexts.add(hashValue_row1.driverId);

						inputTexts.add(hashValue_row1.constructorId);

						inputTexts.add(hashValue_row1.number);

						inputTexts.add(hashValue_row1.grid);

						inputTexts.add(hashValue_row1.position);

						inputTexts.add(hashValue_row1.positionText);

						inputTexts.add(hashValue_row1.positionOrder);

						inputTexts.add(hashValue_row1.points);

						inputTexts.add(hashValue_row1.laps);

						inputTexts.add(hashValue_row1.time);

						inputTexts.add(hashValue_row1.milliseconds);

						inputTexts.add(hashValue_row1.fastestLap);

						inputTexts.add(hashValue_row1.rank);

						inputTexts.add(hashValue_row1.fastestLapTime);

						inputTexts.add(hashValue_row1.fastestLapSpeed);

						inputTexts.add(hashValue_row1.statusId);

						inputTexts.add(hashValue_row1.FastLapandTime);

						inputTexts.add(hashValue_row1.raceName);

						inputTexts.add(hashValue_row1.year);

						inputTexts.add(hashValue_row1.round);

						inputTexts.add(hashValue_row1.date);

						inputTexts.add(hashValue_row1.time_race);

						inputTexts.add(hashValue_row1.url_race);

						inputTexts.add(hashValue_row1.circuitId);

						inputTexts.add(hashValue_row1.circuitRef);

						inputTexts.add(hashValue_row1.circuitName);

						inputTexts.add(hashValue_row1.location);

						inputTexts.add(hashValue_row1.country);

						inputTexts.add(hashValue_row1.lat);

						inputTexts.add(hashValue_row1.lng);

						inputTexts.add(hashValue_row1.alt);

						inputTexts.add(hashValue_row1.url_circuit);

						inputTexts.add(hashValue_row1.driverRef);

						inputTexts.add(hashValue_row1.number_driver);

						inputTexts.add(hashValue_row1.code);

						inputTexts.add(hashValue_row1.forename);

						inputTexts.add(hashValue_row1.surname);

						inputTexts.add(hashValue_row1.dob);

						inputTexts.add(hashValue_row1.nationality);

						inputTexts.add(hashValue_row1.url);

						recordGroupImp_tMatchGroup_1
								.doGroup((Object[]) inputTexts.toArray(new Object[inputTexts.size()]));

					} // while

					recordGroupImp_tMatchGroup_1.end();
					groupRows_tMatchGroup_1.addAll(masterRows_tMatchGroup_1);

					java.util.Collections.sort(groupRows_tMatchGroup_1, new Comparator<row4Struct>() {
						public int compare(row4Struct row1, row4Struct row2) {
							if (!(row1.GID).equals(row2.GID)) {
								return (row1.GID).compareTo(row2.GID);
							} else {
								// false < true
								return (row2.MASTER).compareTo(row1.MASTER);
							}
						}
					});

					// output data
					for (row4Struct out_tMatchGroup_1 : groupRows_tMatchGroup_1) { // C_02

						if (out_tMatchGroup_1 != null) { // C_03
							if (out_tMatchGroup_1.GRP_SIZE == 1) { // unique rows
								row2 = new row2Struct();
								row2.resultId = out_tMatchGroup_1.resultId;
								row2.raceId = out_tMatchGroup_1.raceId;
								row2.driverId = out_tMatchGroup_1.driverId;
								row2.constructorId = out_tMatchGroup_1.constructorId;
								row2.number = out_tMatchGroup_1.number;
								row2.grid = out_tMatchGroup_1.grid;
								row2.position = out_tMatchGroup_1.position;
								row2.positionText = out_tMatchGroup_1.positionText;
								row2.positionOrder = out_tMatchGroup_1.positionOrder;
								row2.points = out_tMatchGroup_1.points;
								row2.laps = out_tMatchGroup_1.laps;
								row2.time = out_tMatchGroup_1.time;
								row2.milliseconds = out_tMatchGroup_1.milliseconds;
								row2.fastestLap = out_tMatchGroup_1.fastestLap;
								row2.rank = out_tMatchGroup_1.rank;
								row2.fastestLapTime = out_tMatchGroup_1.fastestLapTime;
								row2.fastestLapSpeed = out_tMatchGroup_1.fastestLapSpeed;
								row2.statusId = out_tMatchGroup_1.statusId;
								row2.FastLapandTime = out_tMatchGroup_1.FastLapandTime;
								row2.raceName = out_tMatchGroup_1.raceName;
								row2.year = out_tMatchGroup_1.year;
								row2.round = out_tMatchGroup_1.round;
								row2.date = out_tMatchGroup_1.date;
								row2.time_race = out_tMatchGroup_1.time_race;
								row2.url_race = out_tMatchGroup_1.url_race;
								row2.circuitId = out_tMatchGroup_1.circuitId;
								row2.circuitRef = out_tMatchGroup_1.circuitRef;
								row2.circuitName = out_tMatchGroup_1.circuitName;
								row2.location = out_tMatchGroup_1.location;
								row2.country = out_tMatchGroup_1.country;
								row2.lat = out_tMatchGroup_1.lat;
								row2.lng = out_tMatchGroup_1.lng;
								row2.alt = out_tMatchGroup_1.alt;
								row2.url_circuit = out_tMatchGroup_1.url_circuit;
								row2.driverRef = out_tMatchGroup_1.driverRef;
								row2.number_driver = out_tMatchGroup_1.number_driver;
								row2.code = out_tMatchGroup_1.code;
								row2.forename = out_tMatchGroup_1.forename;
								row2.surname = out_tMatchGroup_1.surname;
								row2.dob = out_tMatchGroup_1.dob;
								row2.nationality = out_tMatchGroup_1.nationality;
								row2.url = out_tMatchGroup_1.url;
								row2.GID = out_tMatchGroup_1.GID;
								row2.GRP_SIZE = out_tMatchGroup_1.GRP_SIZE;
								row2.MASTER = out_tMatchGroup_1.MASTER;
								row2.SCORE = out_tMatchGroup_1.SCORE;
								row2.GRP_QUALITY = out_tMatchGroup_1.GRP_QUALITY;
								row3 = null;
								row4 = null;
							} else {
								double groupQuality;
								if (out_tMatchGroup_1.MASTER == true) { // master rows case we get group quality
																		// directly
									groupQuality = out_tMatchGroup_1.GRP_QUALITY;
								} else { // sub rows case we get group quality from gID2GQMap
									groupQuality = gID2GQMap_tMatchGroup_1.get(String.valueOf(out_tMatchGroup_1.GID));
								}
								if (groupQuality >= CONFIDENCE_THRESHOLD_tMatchGroup_1) {
									row2 = null;
									row3 = new row3Struct();
									row3.resultId = out_tMatchGroup_1.resultId;
									row3.raceId = out_tMatchGroup_1.raceId;
									row3.driverId = out_tMatchGroup_1.driverId;
									row3.constructorId = out_tMatchGroup_1.constructorId;
									row3.number = out_tMatchGroup_1.number;
									row3.grid = out_tMatchGroup_1.grid;
									row3.position = out_tMatchGroup_1.position;
									row3.positionText = out_tMatchGroup_1.positionText;
									row3.positionOrder = out_tMatchGroup_1.positionOrder;
									row3.points = out_tMatchGroup_1.points;
									row3.laps = out_tMatchGroup_1.laps;
									row3.time = out_tMatchGroup_1.time;
									row3.milliseconds = out_tMatchGroup_1.milliseconds;
									row3.fastestLap = out_tMatchGroup_1.fastestLap;
									row3.rank = out_tMatchGroup_1.rank;
									row3.fastestLapTime = out_tMatchGroup_1.fastestLapTime;
									row3.fastestLapSpeed = out_tMatchGroup_1.fastestLapSpeed;
									row3.statusId = out_tMatchGroup_1.statusId;
									row3.FastLapandTime = out_tMatchGroup_1.FastLapandTime;
									row3.raceName = out_tMatchGroup_1.raceName;
									row3.year = out_tMatchGroup_1.year;
									row3.round = out_tMatchGroup_1.round;
									row3.date = out_tMatchGroup_1.date;
									row3.time_race = out_tMatchGroup_1.time_race;
									row3.url_race = out_tMatchGroup_1.url_race;
									row3.circuitId = out_tMatchGroup_1.circuitId;
									row3.circuitRef = out_tMatchGroup_1.circuitRef;
									row3.circuitName = out_tMatchGroup_1.circuitName;
									row3.location = out_tMatchGroup_1.location;
									row3.country = out_tMatchGroup_1.country;
									row3.lat = out_tMatchGroup_1.lat;
									row3.lng = out_tMatchGroup_1.lng;
									row3.alt = out_tMatchGroup_1.alt;
									row3.url_circuit = out_tMatchGroup_1.url_circuit;
									row3.driverRef = out_tMatchGroup_1.driverRef;
									row3.number_driver = out_tMatchGroup_1.number_driver;
									row3.code = out_tMatchGroup_1.code;
									row3.forename = out_tMatchGroup_1.forename;
									row3.surname = out_tMatchGroup_1.surname;
									row3.dob = out_tMatchGroup_1.dob;
									row3.nationality = out_tMatchGroup_1.nationality;
									row3.url = out_tMatchGroup_1.url;
									row3.GID = out_tMatchGroup_1.GID;
									row3.GRP_SIZE = out_tMatchGroup_1.GRP_SIZE;
									row3.MASTER = out_tMatchGroup_1.MASTER;
									row3.SCORE = out_tMatchGroup_1.SCORE;
									row3.GRP_QUALITY = out_tMatchGroup_1.GRP_QUALITY;
									row4 = null;
								} else {
									row2 = null;
									row3 = null;
									row4 = new row4Struct();
									row4.resultId = out_tMatchGroup_1.resultId;
									row4.raceId = out_tMatchGroup_1.raceId;
									row4.driverId = out_tMatchGroup_1.driverId;
									row4.constructorId = out_tMatchGroup_1.constructorId;
									row4.number = out_tMatchGroup_1.number;
									row4.grid = out_tMatchGroup_1.grid;
									row4.position = out_tMatchGroup_1.position;
									row4.positionText = out_tMatchGroup_1.positionText;
									row4.positionOrder = out_tMatchGroup_1.positionOrder;
									row4.points = out_tMatchGroup_1.points;
									row4.laps = out_tMatchGroup_1.laps;
									row4.time = out_tMatchGroup_1.time;
									row4.milliseconds = out_tMatchGroup_1.milliseconds;
									row4.fastestLap = out_tMatchGroup_1.fastestLap;
									row4.rank = out_tMatchGroup_1.rank;
									row4.fastestLapTime = out_tMatchGroup_1.fastestLapTime;
									row4.fastestLapSpeed = out_tMatchGroup_1.fastestLapSpeed;
									row4.statusId = out_tMatchGroup_1.statusId;
									row4.FastLapandTime = out_tMatchGroup_1.FastLapandTime;
									row4.raceName = out_tMatchGroup_1.raceName;
									row4.year = out_tMatchGroup_1.year;
									row4.round = out_tMatchGroup_1.round;
									row4.date = out_tMatchGroup_1.date;
									row4.time_race = out_tMatchGroup_1.time_race;
									row4.url_race = out_tMatchGroup_1.url_race;
									row4.circuitId = out_tMatchGroup_1.circuitId;
									row4.circuitRef = out_tMatchGroup_1.circuitRef;
									row4.circuitName = out_tMatchGroup_1.circuitName;
									row4.location = out_tMatchGroup_1.location;
									row4.country = out_tMatchGroup_1.country;
									row4.lat = out_tMatchGroup_1.lat;
									row4.lng = out_tMatchGroup_1.lng;
									row4.alt = out_tMatchGroup_1.alt;
									row4.url_circuit = out_tMatchGroup_1.url_circuit;
									row4.driverRef = out_tMatchGroup_1.driverRef;
									row4.number_driver = out_tMatchGroup_1.number_driver;
									row4.code = out_tMatchGroup_1.code;
									row4.forename = out_tMatchGroup_1.forename;
									row4.surname = out_tMatchGroup_1.surname;
									row4.dob = out_tMatchGroup_1.dob;
									row4.nationality = out_tMatchGroup_1.nationality;
									row4.url = out_tMatchGroup_1.url;
									row4.GID = out_tMatchGroup_1.GID;
									row4.GRP_SIZE = out_tMatchGroup_1.GRP_SIZE;
									row4.MASTER = out_tMatchGroup_1.MASTER;
									row4.SCORE = out_tMatchGroup_1.SCORE;
									row4.GRP_QUALITY = out_tMatchGroup_1.GRP_QUALITY;
								}
							}

							// all output
							mainOutput_tMatchGroup_1 = new row4Struct();
							mainOutput_tMatchGroup_1.resultId = out_tMatchGroup_1.resultId;
							mainOutput_tMatchGroup_1.raceId = out_tMatchGroup_1.raceId;
							mainOutput_tMatchGroup_1.driverId = out_tMatchGroup_1.driverId;
							mainOutput_tMatchGroup_1.constructorId = out_tMatchGroup_1.constructorId;
							mainOutput_tMatchGroup_1.number = out_tMatchGroup_1.number;
							mainOutput_tMatchGroup_1.grid = out_tMatchGroup_1.grid;
							mainOutput_tMatchGroup_1.position = out_tMatchGroup_1.position;
							mainOutput_tMatchGroup_1.positionText = out_tMatchGroup_1.positionText;
							mainOutput_tMatchGroup_1.positionOrder = out_tMatchGroup_1.positionOrder;
							mainOutput_tMatchGroup_1.points = out_tMatchGroup_1.points;
							mainOutput_tMatchGroup_1.laps = out_tMatchGroup_1.laps;
							mainOutput_tMatchGroup_1.time = out_tMatchGroup_1.time;
							mainOutput_tMatchGroup_1.milliseconds = out_tMatchGroup_1.milliseconds;
							mainOutput_tMatchGroup_1.fastestLap = out_tMatchGroup_1.fastestLap;
							mainOutput_tMatchGroup_1.rank = out_tMatchGroup_1.rank;
							mainOutput_tMatchGroup_1.fastestLapTime = out_tMatchGroup_1.fastestLapTime;
							mainOutput_tMatchGroup_1.fastestLapSpeed = out_tMatchGroup_1.fastestLapSpeed;
							mainOutput_tMatchGroup_1.statusId = out_tMatchGroup_1.statusId;
							mainOutput_tMatchGroup_1.FastLapandTime = out_tMatchGroup_1.FastLapandTime;
							mainOutput_tMatchGroup_1.raceName = out_tMatchGroup_1.raceName;
							mainOutput_tMatchGroup_1.year = out_tMatchGroup_1.year;
							mainOutput_tMatchGroup_1.round = out_tMatchGroup_1.round;
							mainOutput_tMatchGroup_1.date = out_tMatchGroup_1.date;
							mainOutput_tMatchGroup_1.time_race = out_tMatchGroup_1.time_race;
							mainOutput_tMatchGroup_1.url_race = out_tMatchGroup_1.url_race;
							mainOutput_tMatchGroup_1.circuitId = out_tMatchGroup_1.circuitId;
							mainOutput_tMatchGroup_1.circuitRef = out_tMatchGroup_1.circuitRef;
							mainOutput_tMatchGroup_1.circuitName = out_tMatchGroup_1.circuitName;
							mainOutput_tMatchGroup_1.location = out_tMatchGroup_1.location;
							mainOutput_tMatchGroup_1.country = out_tMatchGroup_1.country;
							mainOutput_tMatchGroup_1.lat = out_tMatchGroup_1.lat;
							mainOutput_tMatchGroup_1.lng = out_tMatchGroup_1.lng;
							mainOutput_tMatchGroup_1.alt = out_tMatchGroup_1.alt;
							mainOutput_tMatchGroup_1.url_circuit = out_tMatchGroup_1.url_circuit;
							mainOutput_tMatchGroup_1.driverRef = out_tMatchGroup_1.driverRef;
							mainOutput_tMatchGroup_1.number_driver = out_tMatchGroup_1.number_driver;
							mainOutput_tMatchGroup_1.code = out_tMatchGroup_1.code;
							mainOutput_tMatchGroup_1.forename = out_tMatchGroup_1.forename;
							mainOutput_tMatchGroup_1.surname = out_tMatchGroup_1.surname;
							mainOutput_tMatchGroup_1.dob = out_tMatchGroup_1.dob;
							mainOutput_tMatchGroup_1.nationality = out_tMatchGroup_1.nationality;
							mainOutput_tMatchGroup_1.url = out_tMatchGroup_1.url;
							mainOutput_tMatchGroup_1.GID = out_tMatchGroup_1.GID;
							mainOutput_tMatchGroup_1.GRP_SIZE = out_tMatchGroup_1.GRP_SIZE;
							mainOutput_tMatchGroup_1.MASTER = out_tMatchGroup_1.MASTER;
							mainOutput_tMatchGroup_1.SCORE = out_tMatchGroup_1.SCORE;
							mainOutput_tMatchGroup_1.GRP_QUALITY = out_tMatchGroup_1.GRP_QUALITY;

							tos_count_tMatchGroup_1_GroupIn++;

							/**
							 * [tMatchGroup_1_GroupIn main ] stop
							 */

							/**
							 * [tMatchGroup_1_GroupIn process_data_begin ] start
							 */

							currentVirtualComponent = "tMatchGroup_1";

							currentComponent = "tMatchGroup_1_GroupIn";

							/**
							 * [tMatchGroup_1_GroupIn process_data_begin ] stop
							 */
// Start of branch "row2"
							if (row2 != null) {

								/**
								 * [tMap_1 main ] start
								 */

								currentComponent = "tMap_1";

								runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row2");

								if (log.isTraceEnabled()) {
									log.trace("row2 - " + (row2 == null ? "" : row2.toLogString()));
								}

								boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

								// ###############################
								// # Input tables (lookups)
								boolean rejectedInnerJoin_tMap_1 = false;
								boolean mainRowRejected_tMap_1 = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
									// ###############################
									// # Output tables

									out4 = null;

// # Output table : 'out4'
									count_out4_tMap_1++;

									out4_tmp.Id_Result = row2.resultId;
									out4_tmp.Id_Driver = row2.driverId;
									out4_tmp.Id_Constructor = row2.constructorId;
									out4_tmp.Id_Race = row2.raceId;
									out4_tmp.Id_circuit = row2.circuitId;
									out4_tmp.Id_Status = row2.statusId;
									out4_tmp.DriverRef = row2.driverRef;
									out4_tmp.DriverNumber = row2.number_driver;
									out4_tmp.Code = row2.code;
									out4_tmp.Forename = row2.forename;
									out4_tmp.Surname = row2.surname;
									out4_tmp.Dob = row2.dob;
									out4_tmp.Nationality = row2.nationality;
									out4_tmp.Number = row2.number;
									out4_tmp.Grid = row2.grid;
									out4_tmp.Position = row2.position;
									out4_tmp.PositionText = row2.positionText;
									out4_tmp.PositionOrder = row2.positionOrder;
									out4_tmp.Points = row2.points;
									out4_tmp.Laps = row2.laps;
									out4_tmp.Time = row2.time;
									out4_tmp.Milliseconds = row2.milliseconds;
									out4_tmp.FastestLap = row2.fastestLap;
									out4_tmp.Rank = row2.rank;
									out4_tmp.FastestLapTime = row2.fastestLapTime;
									out4_tmp.FastestLapSpeed = row2.fastestLapSpeed;
									out4_tmp.FastLapandTime = row2.FastLapandTime;
									out4_tmp.RaceName = row2.raceName;
									out4_tmp.RaceYear = row2.year;
									out4_tmp.Round = row2.round;
									out4_tmp.RaceDate = row2.date;
									out4_tmp.RaceTime = row2.time_race;
									out4_tmp.CircuitRef = row2.circuitRef;
									out4_tmp.CircuitName = row2.circuitName;
									out4_tmp.CircuitLocation = row2.location;
									out4_tmp.CircuitCountry = row2.country;
									out4_tmp.Lat = row2.lat;
									out4_tmp.Lng = row2.lng;
									out4_tmp.Alt = row2.alt;
									out4 = out4_tmp;
									log.debug("tMap_1 - Outputting the record " + count_out4_tMap_1
											+ " of the output table 'out4'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_1 = false;

								tos_count_tMap_1++;

								/**
								 * [tMap_1 main ] stop
								 */

								/**
								 * [tMap_1 process_data_begin ] start
								 */

								currentComponent = "tMap_1";

								/**
								 * [tMap_1 process_data_begin ] stop
								 */
// Start of branch "out4"
								if (out4 != null) {

									/**
									 * [tDBOutput_1 main ] start
									 */

									currentComponent = "tDBOutput_1";

									runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "out4");

									if (log.isTraceEnabled()) {
										log.trace("out4 - " + (out4 == null ? "" : out4.toLogString()));
									}

									whetherReject_tDBOutput_1 = false;
									pstmt_tDBOutput_1.setInt(1, out4.Id_Result);

									pstmt_tDBOutput_1.setInt(2, out4.Id_Driver);

									pstmt_tDBOutput_1.setInt(3, out4.Id_Constructor);

									pstmt_tDBOutput_1.setInt(4, out4.Id_Race);

									pstmt_tDBOutput_1.setInt(5, out4.Id_circuit);

									pstmt_tDBOutput_1.setInt(6, out4.Id_Status);

									if (out4.DriverRef == null) {
										pstmt_tDBOutput_1.setNull(7, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(7, out4.DriverRef);
									}

									if (out4.DriverNumber == null) {
										pstmt_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(8, out4.DriverNumber);
									}

									if (out4.Code == null) {
										pstmt_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(9, out4.Code);
									}

									if (out4.Forename == null) {
										pstmt_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(10, out4.Forename);
									}

									if (out4.Surname == null) {
										pstmt_tDBOutput_1.setNull(11, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(11, out4.Surname);
									}

									if (out4.Dob == null) {
										pstmt_tDBOutput_1.setNull(12, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(12, out4.Dob);
									}

									if (out4.Nationality == null) {
										pstmt_tDBOutput_1.setNull(13, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(13, out4.Nationality);
									}

									pstmt_tDBOutput_1.setInt(14, out4.Number);

									pstmt_tDBOutput_1.setInt(15, out4.Grid);

									pstmt_tDBOutput_1.setInt(16, out4.Position);

									if (out4.PositionText == null) {
										pstmt_tDBOutput_1.setNull(17, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(17, out4.PositionText);
									}

									if (out4.PositionOrder == null) {
										pstmt_tDBOutput_1.setNull(18, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(18, out4.PositionOrder);
									}

									if (out4.Points == null) {
										pstmt_tDBOutput_1.setNull(19, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(19, out4.Points);
									}

									if (out4.Laps == null) {
										pstmt_tDBOutput_1.setNull(20, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(20, out4.Laps);
									}

									if (out4.Time == null) {
										pstmt_tDBOutput_1.setNull(21, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(21, out4.Time);
									}

									if (out4.Milliseconds == null) {
										pstmt_tDBOutput_1.setNull(22, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(22, out4.Milliseconds);
									}

									if (out4.FastestLap == null) {
										pstmt_tDBOutput_1.setNull(23, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(23, out4.FastestLap);
									}

									if (out4.Rank == null) {
										pstmt_tDBOutput_1.setNull(24, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(24, out4.Rank);
									}

									if (out4.FastestLapTime == null) {
										pstmt_tDBOutput_1.setNull(25, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(25, out4.FastestLapTime);
									}

									if (out4.FastestLapSpeed == null) {
										pstmt_tDBOutput_1.setNull(26, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(26, out4.FastestLapSpeed);
									}

									if (out4.FastLapandTime == null) {
										pstmt_tDBOutput_1.setNull(27, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(27, out4.FastLapandTime);
									}

									if (out4.RaceName == null) {
										pstmt_tDBOutput_1.setNull(28, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(28, out4.RaceName);
									}

									pstmt_tDBOutput_1.setInt(29, out4.RaceYear);

									pstmt_tDBOutput_1.setInt(30, out4.Round);

									if (out4.RaceDate == null) {
										pstmt_tDBOutput_1.setNull(31, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(31, out4.RaceDate);
									}

									if (out4.RaceTime == null) {
										pstmt_tDBOutput_1.setNull(32, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(32, out4.RaceTime);
									}

									if (out4.CircuitRef == null) {
										pstmt_tDBOutput_1.setNull(33, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(33, out4.CircuitRef);
									}

									if (out4.CircuitName == null) {
										pstmt_tDBOutput_1.setNull(34, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(34, out4.CircuitName);
									}

									if (out4.CircuitLocation == null) {
										pstmt_tDBOutput_1.setNull(35, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(35, out4.CircuitLocation);
									}

									if (out4.CircuitCountry == null) {
										pstmt_tDBOutput_1.setNull(36, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(36, out4.CircuitCountry);
									}

									if (out4.Lat == null) {
										pstmt_tDBOutput_1.setNull(37, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(37, out4.Lat);
									}

									if (out4.Lng == null) {
										pstmt_tDBOutput_1.setNull(38, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(38, out4.Lng);
									}

									if (out4.Alt == null) {
										pstmt_tDBOutput_1.setNull(39, java.sql.Types.VARCHAR);
									} else {
										pstmt_tDBOutput_1.setString(39, out4.Alt);
									}

									pstmt_tDBOutput_1.addBatch();
									nb_line_tDBOutput_1++;

									if (log.isDebugEnabled())
										log.debug("tDBOutput_1 - " + ("Adding the record ") + (nb_line_tDBOutput_1)
												+ (" to the ") + ("INSERT") + (" batch."));
									batchSizeCounter_tDBOutput_1++;
									if (batchSize_tDBOutput_1 <= batchSizeCounter_tDBOutput_1) {
										try {
											int countSum_tDBOutput_1 = 0;
											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED
														? 0
														: 1);
											}
											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
										} catch (java.sql.BatchUpdateException e) {
											int countSum_tDBOutput_1 = 0;
											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
														: countEach_tDBOutput_1);
											}
											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
											System.err.println(e.getMessage());
											log.error("tDBOutput_1 - " + (e.getMessage()));
										}

										batchSizeCounter_tDBOutput_1 = 0;
									}
									commitCounter_tDBOutput_1++;

									if (commitEvery_tDBOutput_1 <= commitCounter_tDBOutput_1) {

										try {
											int countSum_tDBOutput_1 = 0;
											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT")
														+ (" batch."));
											for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : 1);
											}
											if (log.isDebugEnabled())
												log.debug("tDBOutput_1 - " + ("The ") + ("INSERT")
														+ (" batch execution has succeeded."));
											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
										} catch (java.sql.BatchUpdateException e) {
											int countSum_tDBOutput_1 = 0;
											for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
												countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0
														: countEach_tDBOutput_1);
											}
											insertedCount_tDBOutput_1 += countSum_tDBOutput_1;
											System.err.println(e.getMessage());
											log.error("tDBOutput_1 - " + (e.getMessage()));

										}
										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection starting to commit ")
													+ (commitCounter_tDBOutput_1) + (" record(s)."));
										conn_tDBOutput_1.commit();
										if (log.isDebugEnabled())
											log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
										commitCounter_tDBOutput_1 = 0;

									}

									tos_count_tDBOutput_1++;

									/**
									 * [tDBOutput_1 main ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_begin ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_begin ] stop
									 */

									/**
									 * [tDBOutput_1 process_data_end ] start
									 */

									currentComponent = "tDBOutput_1";

									/**
									 * [tDBOutput_1 process_data_end ] stop
									 */

								} // End of branch "out4"

								/**
								 * [tMap_1 process_data_end ] start
								 */

								currentComponent = "tMap_1";

								/**
								 * [tMap_1 process_data_end ] stop
								 */

							} // End of branch "row2"

// Start of branch "row3"
							if (row3 != null) {

								/**
								 * [tLogRow_1 main ] start
								 */

								currentComponent = "tLogRow_1";

								runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row3");

								if (log.isTraceEnabled()) {
									log.trace("row3 - " + (row3 == null ? "" : row3.toLogString()));
								}

///////////////////////		

								String[] row_tLogRow_1 = new String[47];

								row_tLogRow_1[0] = String.valueOf(row3.resultId);

								row_tLogRow_1[1] = String.valueOf(row3.raceId);

								row_tLogRow_1[2] = String.valueOf(row3.driverId);

								row_tLogRow_1[3] = String.valueOf(row3.constructorId);

								row_tLogRow_1[4] = String.valueOf(row3.number);

								row_tLogRow_1[5] = String.valueOf(row3.grid);

								row_tLogRow_1[6] = String.valueOf(row3.position);

								if (row3.positionText != null) { //
									row_tLogRow_1[7] = String.valueOf(row3.positionText);

								} //

								if (row3.positionOrder != null) { //
									row_tLogRow_1[8] = String.valueOf(row3.positionOrder);

								} //

								if (row3.points != null) { //
									row_tLogRow_1[9] = String.valueOf(row3.points);

								} //

								if (row3.laps != null) { //
									row_tLogRow_1[10] = String.valueOf(row3.laps);

								} //

								if (row3.time != null) { //
									row_tLogRow_1[11] = String.valueOf(row3.time);

								} //

								if (row3.milliseconds != null) { //
									row_tLogRow_1[12] = String.valueOf(row3.milliseconds);

								} //

								if (row3.fastestLap != null) { //
									row_tLogRow_1[13] = String.valueOf(row3.fastestLap);

								} //

								if (row3.rank != null) { //
									row_tLogRow_1[14] = String.valueOf(row3.rank);

								} //

								if (row3.fastestLapTime != null) { //
									row_tLogRow_1[15] = String.valueOf(row3.fastestLapTime);

								} //

								if (row3.fastestLapSpeed != null) { //
									row_tLogRow_1[16] = String.valueOf(row3.fastestLapSpeed);

								} //

								row_tLogRow_1[17] = String.valueOf(row3.statusId);

								if (row3.FastLapandTime != null) { //
									row_tLogRow_1[18] = String.valueOf(row3.FastLapandTime);

								} //

								if (row3.raceName != null) { //
									row_tLogRow_1[19] = String.valueOf(row3.raceName);

								} //

								row_tLogRow_1[20] = String.valueOf(row3.year);

								row_tLogRow_1[21] = String.valueOf(row3.round);

								if (row3.date != null) { //
									row_tLogRow_1[22] = String.valueOf(row3.date);

								} //

								if (row3.time_race != null) { //
									row_tLogRow_1[23] = String.valueOf(row3.time_race);

								} //

								if (row3.url_race != null) { //
									row_tLogRow_1[24] = String.valueOf(row3.url_race);

								} //

								row_tLogRow_1[25] = String.valueOf(row3.circuitId);

								if (row3.circuitRef != null) { //
									row_tLogRow_1[26] = String.valueOf(row3.circuitRef);

								} //

								if (row3.circuitName != null) { //
									row_tLogRow_1[27] = String.valueOf(row3.circuitName);

								} //

								if (row3.location != null) { //
									row_tLogRow_1[28] = String.valueOf(row3.location);

								} //

								if (row3.country != null) { //
									row_tLogRow_1[29] = String.valueOf(row3.country);

								} //

								if (row3.lat != null) { //
									row_tLogRow_1[30] = String.valueOf(row3.lat);

								} //

								if (row3.lng != null) { //
									row_tLogRow_1[31] = String.valueOf(row3.lng);

								} //

								if (row3.alt != null) { //
									row_tLogRow_1[32] = String.valueOf(row3.alt);

								} //

								if (row3.url_circuit != null) { //
									row_tLogRow_1[33] = String.valueOf(row3.url_circuit);

								} //

								if (row3.driverRef != null) { //
									row_tLogRow_1[34] = String.valueOf(row3.driverRef);

								} //

								if (row3.number_driver != null) { //
									row_tLogRow_1[35] = String.valueOf(row3.number_driver);

								} //

								if (row3.code != null) { //
									row_tLogRow_1[36] = String.valueOf(row3.code);

								} //

								if (row3.forename != null) { //
									row_tLogRow_1[37] = String.valueOf(row3.forename);

								} //

								if (row3.surname != null) { //
									row_tLogRow_1[38] = String.valueOf(row3.surname);

								} //

								if (row3.dob != null) { //
									row_tLogRow_1[39] = String.valueOf(row3.dob);

								} //

								if (row3.nationality != null) { //
									row_tLogRow_1[40] = String.valueOf(row3.nationality);

								} //

								if (row3.url != null) { //
									row_tLogRow_1[41] = String.valueOf(row3.url);

								} //

								if (row3.GID != null) { //
									row_tLogRow_1[42] = String.valueOf(row3.GID);

								} //

								if (row3.GRP_SIZE != null) { //
									row_tLogRow_1[43] = String.valueOf(row3.GRP_SIZE);

								} //

								if (row3.MASTER != null) { //
									row_tLogRow_1[44] = String.valueOf(row3.MASTER);

								} //

								if (row3.SCORE != null) { //
									row_tLogRow_1[45] = FormatterUtils.formatUnwithE(row3.SCORE);

								} //

								if (row3.GRP_QUALITY != null) { //
									row_tLogRow_1[46] = FormatterUtils.formatUnwithE(row3.GRP_QUALITY);

								} //

								util_tLogRow_1.addRow(row_tLogRow_1);
								nb_line_tLogRow_1++;
								log.info("tLogRow_1 - Content of row " + nb_line_tLogRow_1 + ": "
										+ TalendString.unionString("|", row_tLogRow_1));
//////

//////                    

///////////////////////    			

								tos_count_tLogRow_1++;

								/**
								 * [tLogRow_1 main ] stop
								 */

								/**
								 * [tLogRow_1 process_data_begin ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_begin ] stop
								 */

								/**
								 * [tLogRow_1 process_data_end ] start
								 */

								currentComponent = "tLogRow_1";

								/**
								 * [tLogRow_1 process_data_end ] stop
								 */

							} // End of branch "row3"

// Start of branch "row4"
							if (row4 != null) {

								/**
								 * [tSortRow_1_SortOut main ] start
								 */

								currentVirtualComponent = "tSortRow_1";

								currentComponent = "tSortRow_1_SortOut";

								runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row4");

								if (log.isTraceEnabled()) {
									log.trace("row4 - " + (row4 == null ? "" : row4.toLogString()));
								}

								Comparablerow4Struct arrayRowtSortRow_1_SortOut = new Comparablerow4Struct();

								arrayRowtSortRow_1_SortOut.resultId = row4.resultId;
								arrayRowtSortRow_1_SortOut.raceId = row4.raceId;
								arrayRowtSortRow_1_SortOut.driverId = row4.driverId;
								arrayRowtSortRow_1_SortOut.constructorId = row4.constructorId;
								arrayRowtSortRow_1_SortOut.number = row4.number;
								arrayRowtSortRow_1_SortOut.grid = row4.grid;
								arrayRowtSortRow_1_SortOut.position = row4.position;
								arrayRowtSortRow_1_SortOut.positionText = row4.positionText;
								arrayRowtSortRow_1_SortOut.positionOrder = row4.positionOrder;
								arrayRowtSortRow_1_SortOut.points = row4.points;
								arrayRowtSortRow_1_SortOut.laps = row4.laps;
								arrayRowtSortRow_1_SortOut.time = row4.time;
								arrayRowtSortRow_1_SortOut.milliseconds = row4.milliseconds;
								arrayRowtSortRow_1_SortOut.fastestLap = row4.fastestLap;
								arrayRowtSortRow_1_SortOut.rank = row4.rank;
								arrayRowtSortRow_1_SortOut.fastestLapTime = row4.fastestLapTime;
								arrayRowtSortRow_1_SortOut.fastestLapSpeed = row4.fastestLapSpeed;
								arrayRowtSortRow_1_SortOut.statusId = row4.statusId;
								arrayRowtSortRow_1_SortOut.FastLapandTime = row4.FastLapandTime;
								arrayRowtSortRow_1_SortOut.raceName = row4.raceName;
								arrayRowtSortRow_1_SortOut.year = row4.year;
								arrayRowtSortRow_1_SortOut.round = row4.round;
								arrayRowtSortRow_1_SortOut.date = row4.date;
								arrayRowtSortRow_1_SortOut.time_race = row4.time_race;
								arrayRowtSortRow_1_SortOut.url_race = row4.url_race;
								arrayRowtSortRow_1_SortOut.circuitId = row4.circuitId;
								arrayRowtSortRow_1_SortOut.circuitRef = row4.circuitRef;
								arrayRowtSortRow_1_SortOut.circuitName = row4.circuitName;
								arrayRowtSortRow_1_SortOut.location = row4.location;
								arrayRowtSortRow_1_SortOut.country = row4.country;
								arrayRowtSortRow_1_SortOut.lat = row4.lat;
								arrayRowtSortRow_1_SortOut.lng = row4.lng;
								arrayRowtSortRow_1_SortOut.alt = row4.alt;
								arrayRowtSortRow_1_SortOut.url_circuit = row4.url_circuit;
								arrayRowtSortRow_1_SortOut.driverRef = row4.driverRef;
								arrayRowtSortRow_1_SortOut.number_driver = row4.number_driver;
								arrayRowtSortRow_1_SortOut.code = row4.code;
								arrayRowtSortRow_1_SortOut.forename = row4.forename;
								arrayRowtSortRow_1_SortOut.surname = row4.surname;
								arrayRowtSortRow_1_SortOut.dob = row4.dob;
								arrayRowtSortRow_1_SortOut.nationality = row4.nationality;
								arrayRowtSortRow_1_SortOut.url = row4.url;
								arrayRowtSortRow_1_SortOut.GID = row4.GID;
								arrayRowtSortRow_1_SortOut.GRP_SIZE = row4.GRP_SIZE;
								arrayRowtSortRow_1_SortOut.MASTER = row4.MASTER;
								arrayRowtSortRow_1_SortOut.SCORE = row4.SCORE;
								arrayRowtSortRow_1_SortOut.GRP_QUALITY = row4.GRP_QUALITY;
								list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

								tos_count_tSortRow_1_SortOut++;

								/**
								 * [tSortRow_1_SortOut main ] stop
								 */

								/**
								 * [tSortRow_1_SortOut process_data_begin ] start
								 */

								currentVirtualComponent = "tSortRow_1";

								currentComponent = "tSortRow_1_SortOut";

								/**
								 * [tSortRow_1_SortOut process_data_begin ] stop
								 */

								/**
								 * [tSortRow_1_SortOut process_data_end ] start
								 */

								currentVirtualComponent = "tSortRow_1";

								currentComponent = "tSortRow_1_SortOut";

								/**
								 * [tSortRow_1_SortOut process_data_end ] stop
								 */

							} // End of branch "row4"

						} // C_03

					} // C_02

				} // C_01

				/**
				 * [tMatchGroup_1_GroupIn process_data_end ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupIn";

				/**
				 * [tMatchGroup_1_GroupIn process_data_end ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupIn end ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupIn";

				blockRows_row1.clear();
				blockRows_row1 = null;
				masterRows_tMatchGroup_1.clear();
				groupRows_tMatchGroup_1.clear();

				if (tHash_Lookup_row1 != null) {
					tHash_Lookup_row1.endGet();
				}
				globalMap.remove("tHash_Lookup_row1");

				if (log.isDebugEnabled())
					log.debug("tMatchGroup_1_GroupIn - " + ("Done."));

				ok_Hash.put("tMatchGroup_1_GroupIn", true);
				end_Hash.put("tMatchGroup_1_GroupIn", System.currentTimeMillis());

				/**
				 * [tMatchGroup_1_GroupIn end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out4': " + count_out4_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row2", 2, 0,
						talendJobLog, "tMatchGroup_1_GroupIn", "tMatchGroupIn", "tMap_1", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (batchSizeCounter_tDBOutput_1 != 0) {
						int countSum_tDBOutput_1 = 0;

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Executing the ") + ("INSERT") + (" batch."));
						for (int countEach_tDBOutput_1 : pstmt_tDBOutput_1.executeBatch()) {
							countSum_tDBOutput_1 += (countEach_tDBOutput_1 == java.sql.Statement.EXECUTE_FAILED ? 0
									: 1);
						}

						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("The ") + ("INSERT") + (" batch execution has succeeded."));

						insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					}

				} catch (java.sql.BatchUpdateException e) {

					int countSum_tDBOutput_1 = 0;
					for (int countEach_tDBOutput_1 : e.getUpdateCounts()) {
						countSum_tDBOutput_1 += (countEach_tDBOutput_1 < 0 ? 0 : countEach_tDBOutput_1);
					}

					insertedCount_tDBOutput_1 += countSum_tDBOutput_1;

					log.error("tDBOutput_1 - " + (e.getMessage()));
					globalMap.put(currentComponent + "_ERROR_MESSAGE", e.getMessage());
					System.err.println(e.getMessage());

				}
				batchSizeCounter_tDBOutput_1 = 0;

				if (pstmt_tDBOutput_1 != null) {

					pstmt_tDBOutput_1.close();
					resourceMap.remove("pstmt_tDBOutput_1");

				}
				resourceMap.put("statementClosed_tDBOutput_1", true);
				if (commitCounter_tDBOutput_1 > 0) {

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection starting to commit ") + (commitCounter_tDBOutput_1)
								+ (" record(s)."));
					conn_tDBOutput_1.commit();

					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Connection commit has succeeded."));
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
				conn_tDBOutput_1.close();

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
				resourceMap.put("finish_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "out4", 2, 0,
						talendJobLog, "tMap_1", "tMap", "tDBOutput_1", "tMysqlOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

//////

				java.io.PrintStream consoleOut_tLogRow_1 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
				}

				consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
				consoleOut_tLogRow_1.flush();
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);
				if (log.isInfoEnabled())
					log.info("tLogRow_1 - " + ("Printed row count: ") + (nb_line_tLogRow_1) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row3", 2, 0,
						talendJobLog, "tMatchGroup_1_GroupIn", "tMatchGroupIn", "tLogRow_1", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Done."));

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

				/**
				 * [tSortRow_1_SortOut end ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				row4Struct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut.toArray(new Comparablerow4Struct[0]);

				java.util.Arrays.sort(array_tSortRow_1_SortOut);

				globalMap.put("tSortRow_1", array_tSortRow_1_SortOut);

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row4", 2, 0,
						talendJobLog, "tMatchGroup_1_GroupIn", "tMatchGroupIn", "tSortRow_1_SortOut", "tSortOut",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortOut - " + ("Done."));

				ok_Hash.put("tSortRow_1_SortOut", true);
				end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortOut end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row12_0");

				int tos_count_tFileOutputDelimited_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileOutputDelimited_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileOutputDelimited_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileOutputDelimited_1 = new StringBuilder();
							log4jParamters_tFileOutputDelimited_1.append("Parameters:");
							log4jParamters_tFileOutputDelimited_1.append("USESTREAM" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("FILENAME" + " = "
									+ "\"C:/Users/Stratebi/Documents/Talend Demo/out_results_uncertain.csv\"");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("APPEND" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("INCLUDEHEADER" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("COMPRESS" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("CREATE" + " = " + "true");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("SPLIT" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("FLUSHONROW" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("ROW_MODE" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("DELETE_EMPTYFILE" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							log4jParamters_tFileOutputDelimited_1.append("FILE_EXIST_EXCEPTION" + " = " + "false");
							log4jParamters_tFileOutputDelimited_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileOutputDelimited_1 - " + (log4jParamters_tFileOutputDelimited_1));
						}
					}
					new BytesLimit65535_tFileOutputDelimited_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileOutputDelimited_1", "tFileOutputDelimited");
					talendJobLogProcess(globalMap);
				}

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						"C:/Users/Stratebi/Documents/Talend Demo/out_results_uncertain.csv")).getAbsolutePath()
								.replace("\\", "/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
							fileName_tFileOutputDelimited_1.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */
						";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
																		 * Start field
																		 * tFileOutputDelimited_1:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						log.info("tFileOutputDelimited_1 - Creating directory '"
								+ dir_tFileOutputDelimited_1.getCanonicalPath() + "'.");
						dir_tFileOutputDelimited_1.mkdirs();
						log.info("tFileOutputDelimited_1 - The directory '"
								+ dir_tFileOutputDelimited_1.getCanonicalPath() + "' has been created successfully.");
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				if (fileToDelete_tFileOutputDelimited_1.exists()) {
					fileToDelete_tFileOutputDelimited_1.delete();
				}
				outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false), "ISO-8859-15"));

				resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tLogRow_4 begin ] start
				 */

				ok_Hash.put("tLogRow_4", false);
				start_Hash.put("tLogRow_4", System.currentTimeMillis());

				currentComponent = "tLogRow_4";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "copyOfout1");

				int tos_count_tLogRow_4 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_4 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_4 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_4 = new StringBuilder();
							log4jParamters_tLogRow_4.append("Parameters:");
							log4jParamters_tLogRow_4.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_4.append(" | ");
							log4jParamters_tLogRow_4.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_4.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_4 - " + (log4jParamters_tLogRow_4));
						}
					}
					new BytesLimit65535_tLogRow_4().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_4", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_4 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[39];

					public void addRow(String[] row) {

						for (int i = 0; i < 39; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 38 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 38 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|%11$-");
							sbformat.append(colLengths[10]);
							sbformat.append("s");

							sbformat.append("|%12$-");
							sbformat.append(colLengths[11]);
							sbformat.append("s");

							sbformat.append("|%13$-");
							sbformat.append(colLengths[12]);
							sbformat.append("s");

							sbformat.append("|%14$-");
							sbformat.append(colLengths[13]);
							sbformat.append("s");

							sbformat.append("|%15$-");
							sbformat.append(colLengths[14]);
							sbformat.append("s");

							sbformat.append("|%16$-");
							sbformat.append(colLengths[15]);
							sbformat.append("s");

							sbformat.append("|%17$-");
							sbformat.append(colLengths[16]);
							sbformat.append("s");

							sbformat.append("|%18$-");
							sbformat.append(colLengths[17]);
							sbformat.append("s");

							sbformat.append("|%19$-");
							sbformat.append(colLengths[18]);
							sbformat.append("s");

							sbformat.append("|%20$-");
							sbformat.append(colLengths[19]);
							sbformat.append("s");

							sbformat.append("|%21$-");
							sbformat.append(colLengths[20]);
							sbformat.append("s");

							sbformat.append("|%22$-");
							sbformat.append(colLengths[21]);
							sbformat.append("s");

							sbformat.append("|%23$-");
							sbformat.append(colLengths[22]);
							sbformat.append("s");

							sbformat.append("|%24$-");
							sbformat.append(colLengths[23]);
							sbformat.append("s");

							sbformat.append("|%25$-");
							sbformat.append(colLengths[24]);
							sbformat.append("s");

							sbformat.append("|%26$-");
							sbformat.append(colLengths[25]);
							sbformat.append("s");

							sbformat.append("|%27$-");
							sbformat.append(colLengths[26]);
							sbformat.append("s");

							sbformat.append("|%28$-");
							sbformat.append(colLengths[27]);
							sbformat.append("s");

							sbformat.append("|%29$-");
							sbformat.append(colLengths[28]);
							sbformat.append("s");

							sbformat.append("|%30$-");
							sbformat.append(colLengths[29]);
							sbformat.append("s");

							sbformat.append("|%31$-");
							sbformat.append(colLengths[30]);
							sbformat.append("s");

							sbformat.append("|%32$-");
							sbformat.append(colLengths[31]);
							sbformat.append("s");

							sbformat.append("|%33$-");
							sbformat.append(colLengths[32]);
							sbformat.append("s");

							sbformat.append("|%34$-");
							sbformat.append(colLengths[33]);
							sbformat.append("s");

							sbformat.append("|%35$-");
							sbformat.append(colLengths[34]);
							sbformat.append("s");

							sbformat.append("|%36$-");
							sbformat.append(colLengths[35]);
							sbformat.append("s");

							sbformat.append("|%37$-");
							sbformat.append(colLengths[36]);
							sbformat.append("s");

							sbformat.append("|%38$-");
							sbformat.append(colLengths[37]);
							sbformat.append("s");

							sbformat.append("|%39$-");
							sbformat.append(colLengths[38]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[27] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[28] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[29] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[30] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[31] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[32] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[33] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[34] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[35] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[36] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[37] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[38] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_4 util_tLogRow_4 = new Util_tLogRow_4();
				util_tLogRow_4.setTableName("tLogRow_4");
				util_tLogRow_4.addRow(new String[] { "Id_Result", "Id_Driver", "Id_Constructor", "Id_Race",
						"Id_circuit", "Id_Status", "DriverRef", "DriverNumber", "Code", "Forename", "Surname", "Dob",
						"Nationality", "Number", "Grid", "Position", "PositionText", "PositionOrder", "Points", "Laps",
						"Time", "Milliseconds", "FastestLap", "Rank", "FastestLapTime", "FastestLapSpeed",
						"FastLapandTime", "RaceName", "RaceYear", "Round", "RaceDate", "RaceTime", "CircuitRef",
						"CircuitName", "CircuitLocation", "CircuitCountry", "Lat", "Lng", "Alt", });
				StringBuilder strBuffer_tLogRow_4 = null;
				int nb_line_tLogRow_4 = 0;
///////////////////////    			

				/**
				 * [tLogRow_4 begin ] stop
				 */

				/**
				 * [tDataStewardshipTaskOutput_1 begin ] start
				 */

				ok_Hash.put("tDataStewardshipTaskOutput_1", false);
				start_Hash.put("tDataStewardshipTaskOutput_1", System.currentTimeMillis());

				currentComponent = "tDataStewardshipTaskOutput_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11_0");

				int tos_count_tDataStewardshipTaskOutput_1 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tDataStewardshipTaskOutput_1", "tDataStewardshipTaskOutput");
					talendJobLogProcess(globalMap);
				}

				org.talend.components.api.component.ComponentDefinition def_tDataStewardshipTaskOutput_1 = new org.talend.components.datastewardship.tdatastewardshiptaskoutput.TDataStewardshipTaskOutputDefinition();

				org.talend.components.datastewardship.tdatastewardshiptaskoutput.TDataStewardshipTaskOutputProperties props_tDataStewardshipTaskOutput_1 = (org.talend.components.datastewardship.tdatastewardshiptaskoutput.TDataStewardshipTaskOutputProperties) def_tDataStewardshipTaskOutput_1
						.createRuntimeProperties();
				props_tDataStewardshipTaskOutput_1.setValue("batchSize", 50);

				props_tDataStewardshipTaskOutput_1.setValue("campaignName", "cf4c3b6b1c152efd8b503c4baee0bf784");

				props_tDataStewardshipTaskOutput_1.setValue("campaignLabel", "F1_demo_campaign_4");

				props_tDataStewardshipTaskOutput_1.setValue("campaignType",
						org.talend.components.datastewardship.common.CampaignType.RESOLUTION);

				props_tDataStewardshipTaskOutput_1.setValue("laxSchema", true);

				props_tDataStewardshipTaskOutput_1.setValue("taskPriority", "NO_PRIORITY");

				props_tDataStewardshipTaskOutput_1.setValue("taskTags", "");

				props_tDataStewardshipTaskOutput_1.setValue("taskState", "New");

				props_tDataStewardshipTaskOutput_1.setValue("taskAssignee", "No Assignee");

				java.util.List<Object> tDataStewardshipTaskOutput_1_taskCommentsTable_fieldName = new java.util.ArrayList<Object>();

				tDataStewardshipTaskOutput_1_taskCommentsTable_fieldName.add("RaceName");

				tDataStewardshipTaskOutput_1_taskCommentsTable_fieldName.add("Nationality");

				((org.talend.daikon.properties.Properties) props_tDataStewardshipTaskOutput_1.taskCommentsTable)
						.setValue("fieldName", tDataStewardshipTaskOutput_1_taskCommentsTable_fieldName);

				java.util.List<Object> tDataStewardshipTaskOutput_1_taskCommentsTable_fieldComment = new java.util.ArrayList<Object>();

				tDataStewardshipTaskOutput_1_taskCommentsTable_fieldComment.add("");

				tDataStewardshipTaskOutput_1_taskCommentsTable_fieldComment.add("");

				((org.talend.daikon.properties.Properties) props_tDataStewardshipTaskOutput_1.taskCommentsTable)
						.setValue("fieldComment", tDataStewardshipTaskOutput_1_taskCommentsTable_fieldComment);

				class SchemaSettingTool_tDataStewardshipTaskOutput_1_1_fisrt {

					String getSchemaValue() {

						StringBuilder s = new StringBuilder();

						a("{\"type\":\"record\",", s);

						a("\"name\":\"main\",\"fields\":[{", s);

						a("\"name\":\"RaceName\",\"type\":\"string\",\"di.table.comment\":\"text\",\"talend.isLocked\":\"true\",\"talend.field.generated\":\"true\",\"di.column.isNullable\":\"true\",\"talend.field.dbColumnName\":\"RaceName\"},{",
								s);

						a("\"name\":\"Nationality\",\"type\":\"string\",\"di.table.comment\":\"text\",\"talend.isLocked\":\"true\",\"talend.field.generated\":\"true\",\"talend.field.dbColumnName\":\"Nationality\"},{",
								s);

						a("\"name\":\"TDS_DUE_DATE\",\"type\":\"long\",\"talend.isLocked\":\"true\",\"talend.field.generated\":\"true\",\"di.column.isNullable\":\"true\",\"talend.field.dbColumnName\":\"TDS_DUE_DATE\"},{",
								s);

						a("\"name\":\"TDS_EXTERNAL_ID\",\"type\":\"string\",\"talend.isLocked\":\"true\",\"talend.field.generated\":\"true\",\"di.column.isNullable\":\"true\",\"talend.field.dbColumnName\":\"TDS_EXTERNAL_ID\"}]}",
								s);

						return s.toString();

					}

					void a(String part, StringBuilder strB) {
						strB.append(part);
					}

				}

				SchemaSettingTool_tDataStewardshipTaskOutput_1_1_fisrt sst_tDataStewardshipTaskOutput_1_1_fisrt = new SchemaSettingTool_tDataStewardshipTaskOutput_1_1_fisrt();

				props_tDataStewardshipTaskOutput_1.schema.setValue("schema", new org.apache.avro.Schema.Parser()
						.parse(sst_tDataStewardshipTaskOutput_1_1_fisrt.getSchemaValue()));

				props_tDataStewardshipTaskOutput_1.connection.setValue("url",
						"https://tds.eu.cloud.talend.com/data-stewardship");

				props_tDataStewardshipTaskOutput_1.connection.setValue("username", "sistemas@nfr.stratebi.com");

				props_tDataStewardshipTaskOutput_1.connection.setValue("password",
						routines.system.PasswordEncryptUtil.decryptPassword(
								"enc:routine.encryption.key.v1:ppNZosWsmLzuFx8LwIT9Wu+AvfmsZDsVT1455iiSeAKlfJAjEX5RJFByo+E0ktHbkOaTXw=="));

				props_tDataStewardshipTaskOutput_1.connection.refConnection.setValue("referenceDefinitionName",
						"datastewardship");

				if (org.talend.components.api.properties.ComponentReferenceProperties.ReferenceType.COMPONENT_INSTANCE == props_tDataStewardshipTaskOutput_1.connection.refConnection.referenceType
						.getValue()) {
					final String referencedComponentInstanceId_tDataStewardshipTaskOutput_1 = props_tDataStewardshipTaskOutput_1.connection.refConnection.componentInstanceId
							.getStringValue();
					if (referencedComponentInstanceId_tDataStewardshipTaskOutput_1 != null) {
						org.talend.daikon.properties.Properties referencedComponentProperties_tDataStewardshipTaskOutput_1 = (org.talend.daikon.properties.Properties) globalMap
								.get(referencedComponentInstanceId_tDataStewardshipTaskOutput_1
										+ "_COMPONENT_RUNTIME_PROPERTIES");
						props_tDataStewardshipTaskOutput_1.connection.refConnection
								.setReference(referencedComponentProperties_tDataStewardshipTaskOutput_1);
					}
				}
				globalMap.put("tDataStewardshipTaskOutput_1_COMPONENT_RUNTIME_PROPERTIES",
						props_tDataStewardshipTaskOutput_1);
				globalMap.putIfAbsent("TALEND_PRODUCT_VERSION", "7.3");
				globalMap.put("TALEND_COMPONENTS_VERSION", "0.28.2");
				java.net.URL mappings_url_tDataStewardshipTaskOutput_1 = this.getClass().getResource("/xmlMappings");
				globalMap.put("tDataStewardshipTaskOutput_1_MAPPINGS_URL", mappings_url_tDataStewardshipTaskOutput_1);

				org.talend.components.api.container.RuntimeContainer container_tDataStewardshipTaskOutput_1 = new org.talend.components.api.container.RuntimeContainer() {
					public Object getComponentData(String componentId, String key) {
						return globalMap.get(componentId + "_" + key);
					}

					public void setComponentData(String componentId, String key, Object data) {
						globalMap.put(componentId + "_" + key, data);
					}

					public String getCurrentComponentId() {
						return "tDataStewardshipTaskOutput_1";
					}

					public Object getGlobalData(String key) {
						return globalMap.get(key);
					}
				};

				int nb_line_tDataStewardshipTaskOutput_1 = 0;

				org.talend.components.api.component.ConnectorTopology topology_tDataStewardshipTaskOutput_1 = null;
				topology_tDataStewardshipTaskOutput_1 = org.talend.components.api.component.ConnectorTopology.INCOMING;

				org.talend.daikon.runtime.RuntimeInfo runtime_info_tDataStewardshipTaskOutput_1 = def_tDataStewardshipTaskOutput_1
						.getRuntimeInfo(org.talend.components.api.component.runtime.ExecutionEngine.DI,
								props_tDataStewardshipTaskOutput_1, topology_tDataStewardshipTaskOutput_1);
				java.util.Set<org.talend.components.api.component.ConnectorTopology> supported_connector_topologies_tDataStewardshipTaskOutput_1 = def_tDataStewardshipTaskOutput_1
						.getSupportedConnectorTopologies();

				org.talend.components.api.component.runtime.RuntimableRuntime componentRuntime_tDataStewardshipTaskOutput_1 = (org.talend.components.api.component.runtime.RuntimableRuntime) (Class
						.forName(runtime_info_tDataStewardshipTaskOutput_1.getRuntimeClassName()).newInstance());
				org.talend.daikon.properties.ValidationResult initVr_tDataStewardshipTaskOutput_1 = componentRuntime_tDataStewardshipTaskOutput_1
						.initialize(container_tDataStewardshipTaskOutput_1, props_tDataStewardshipTaskOutput_1);

				if (initVr_tDataStewardshipTaskOutput_1
						.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR) {
					throw new RuntimeException(initVr_tDataStewardshipTaskOutput_1.getMessage());
				}

				if (componentRuntime_tDataStewardshipTaskOutput_1 instanceof org.talend.components.api.component.runtime.ComponentDriverInitialization) {
					org.talend.components.api.component.runtime.ComponentDriverInitialization compDriverInitialization_tDataStewardshipTaskOutput_1 = (org.talend.components.api.component.runtime.ComponentDriverInitialization) componentRuntime_tDataStewardshipTaskOutput_1;
					compDriverInitialization_tDataStewardshipTaskOutput_1
							.runAtDriver(container_tDataStewardshipTaskOutput_1);
				}

				org.talend.components.api.component.runtime.SourceOrSink sourceOrSink_tDataStewardshipTaskOutput_1 = null;
				if (componentRuntime_tDataStewardshipTaskOutput_1 instanceof org.talend.components.api.component.runtime.SourceOrSink) {
					sourceOrSink_tDataStewardshipTaskOutput_1 = (org.talend.components.api.component.runtime.SourceOrSink) componentRuntime_tDataStewardshipTaskOutput_1;
					org.talend.daikon.properties.ValidationResult vr_tDataStewardshipTaskOutput_1 = sourceOrSink_tDataStewardshipTaskOutput_1
							.validate(container_tDataStewardshipTaskOutput_1);
					if (vr_tDataStewardshipTaskOutput_1
							.getStatus() == org.talend.daikon.properties.ValidationResult.Result.ERROR) {
						throw new RuntimeException(vr_tDataStewardshipTaskOutput_1.getMessage());
					}
				}

				org.talend.components.api.component.runtime.Sink sink_tDataStewardshipTaskOutput_1 = (org.talend.components.api.component.runtime.Sink) sourceOrSink_tDataStewardshipTaskOutput_1;
				org.talend.components.api.component.runtime.WriteOperation writeOperation_tDataStewardshipTaskOutput_1 = sink_tDataStewardshipTaskOutput_1
						.createWriteOperation();
				writeOperation_tDataStewardshipTaskOutput_1.initialize(container_tDataStewardshipTaskOutput_1);
				org.talend.components.api.component.runtime.Writer writer_tDataStewardshipTaskOutput_1 = writeOperation_tDataStewardshipTaskOutput_1
						.createWriter(container_tDataStewardshipTaskOutput_1);
				writer_tDataStewardshipTaskOutput_1.open("tDataStewardshipTaskOutput_1");

				resourceMap.put("writer_tDataStewardshipTaskOutput_1", writer_tDataStewardshipTaskOutput_1);

				org.talend.components.api.component.Connector c_tDataStewardshipTaskOutput_1 = null;
				for (org.talend.components.api.component.Connector currentConnector : props_tDataStewardshipTaskOutput_1
						.getAvailableConnectors(null, false)) {
					if (currentConnector.getName().equals("MAIN")) {
						c_tDataStewardshipTaskOutput_1 = currentConnector;
						break;
					}
				}
				org.apache.avro.Schema designSchema_tDataStewardshipTaskOutput_1 = props_tDataStewardshipTaskOutput_1
						.getSchema(c_tDataStewardshipTaskOutput_1, false);
				org.talend.codegen.enforcer.IncomingSchemaEnforcer incomingEnforcer_tDataStewardshipTaskOutput_1 = new org.talend.codegen.enforcer.IncomingSchemaEnforcer(
						designSchema_tDataStewardshipTaskOutput_1);
				java.lang.Iterable<?> outgoingMainRecordsList_tDataStewardshipTaskOutput_1 = new java.util.ArrayList<Object>();
				java.util.Iterator outgoingMainRecordsIt_tDataStewardshipTaskOutput_1 = null;

				/**
				 * [tDataStewardshipTaskOutput_1 begin ] stop
				 */

				/**
				 * [tLogRow_3 begin ] start
				 */

				ok_Hash.put("tLogRow_3", false);
				start_Hash.put("tLogRow_3", System.currentTimeMillis());

				currentComponent = "tLogRow_3";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "copyOfout4_0");

				int tos_count_tLogRow_3 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_3 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_3 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_3 = new StringBuilder();
							log4jParamters_tLogRow_3.append("Parameters:");
							log4jParamters_tLogRow_3.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_3.append(" | ");
							log4jParamters_tLogRow_3.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_3.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_3 - " + (log4jParamters_tLogRow_3));
						}
					}
					new BytesLimit65535_tLogRow_3().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_3", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_3 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[39];

					public void addRow(String[] row) {

						for (int i = 0; i < 39; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 38 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 38 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|%11$-");
							sbformat.append(colLengths[10]);
							sbformat.append("s");

							sbformat.append("|%12$-");
							sbformat.append(colLengths[11]);
							sbformat.append("s");

							sbformat.append("|%13$-");
							sbformat.append(colLengths[12]);
							sbformat.append("s");

							sbformat.append("|%14$-");
							sbformat.append(colLengths[13]);
							sbformat.append("s");

							sbformat.append("|%15$-");
							sbformat.append(colLengths[14]);
							sbformat.append("s");

							sbformat.append("|%16$-");
							sbformat.append(colLengths[15]);
							sbformat.append("s");

							sbformat.append("|%17$-");
							sbformat.append(colLengths[16]);
							sbformat.append("s");

							sbformat.append("|%18$-");
							sbformat.append(colLengths[17]);
							sbformat.append("s");

							sbformat.append("|%19$-");
							sbformat.append(colLengths[18]);
							sbformat.append("s");

							sbformat.append("|%20$-");
							sbformat.append(colLengths[19]);
							sbformat.append("s");

							sbformat.append("|%21$-");
							sbformat.append(colLengths[20]);
							sbformat.append("s");

							sbformat.append("|%22$-");
							sbformat.append(colLengths[21]);
							sbformat.append("s");

							sbformat.append("|%23$-");
							sbformat.append(colLengths[22]);
							sbformat.append("s");

							sbformat.append("|%24$-");
							sbformat.append(colLengths[23]);
							sbformat.append("s");

							sbformat.append("|%25$-");
							sbformat.append(colLengths[24]);
							sbformat.append("s");

							sbformat.append("|%26$-");
							sbformat.append(colLengths[25]);
							sbformat.append("s");

							sbformat.append("|%27$-");
							sbformat.append(colLengths[26]);
							sbformat.append("s");

							sbformat.append("|%28$-");
							sbformat.append(colLengths[27]);
							sbformat.append("s");

							sbformat.append("|%29$-");
							sbformat.append(colLengths[28]);
							sbformat.append("s");

							sbformat.append("|%30$-");
							sbformat.append(colLengths[29]);
							sbformat.append("s");

							sbformat.append("|%31$-");
							sbformat.append(colLengths[30]);
							sbformat.append("s");

							sbformat.append("|%32$-");
							sbformat.append(colLengths[31]);
							sbformat.append("s");

							sbformat.append("|%33$-");
							sbformat.append(colLengths[32]);
							sbformat.append("s");

							sbformat.append("|%34$-");
							sbformat.append(colLengths[33]);
							sbformat.append("s");

							sbformat.append("|%35$-");
							sbformat.append(colLengths[34]);
							sbformat.append("s");

							sbformat.append("|%36$-");
							sbformat.append(colLengths[35]);
							sbformat.append("s");

							sbformat.append("|%37$-");
							sbformat.append(colLengths[36]);
							sbformat.append("s");

							sbformat.append("|%38$-");
							sbformat.append(colLengths[37]);
							sbformat.append("s");

							sbformat.append("|%39$-");
							sbformat.append(colLengths[38]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[27] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[28] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[29] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[30] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[31] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[32] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[33] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[34] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[35] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[36] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[37] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[38] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_3 util_tLogRow_3 = new Util_tLogRow_3();
				util_tLogRow_3.setTableName("tLogRow_3");
				util_tLogRow_3.addRow(new String[] { "Id_Result", "Id_Driver", "Id_Constructor", "Id_Race",
						"Id_circuit", "Id_Status", "DriverRef", "DriverNumber", "Code", "Forename", "Surname", "Dob",
						"Nationality", "Number", "Grid", "Position", "PositionText", "PositionOrder", "Points", "Laps",
						"Time", "Milliseconds", "FastestLap", "Rank", "FastestLapTime", "FastestLapSpeed",
						"FastLapandTime", "RaceName", "RaceYear", "Round", "RaceDate", "RaceTime", "CircuitRef",
						"CircuitName", "CircuitLocation", "CircuitCountry", "Lat", "Lng", "Alt", });
				StringBuilder strBuffer_tLogRow_3 = null;
				int nb_line_tLogRow_3 = 0;
///////////////////////    			

				/**
				 * [tLogRow_3 begin ] stop
				 */

				/**
				 * [tMap_2 begin ] start
				 */

				ok_Hash.put("tMap_2", false);
				start_Hash.put("tMap_2", System.currentTimeMillis());

				currentComponent = "tMap_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row13");

				int tos_count_tMap_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_2 = new StringBuilder();
							log4jParamters_tMap_2.append("Parameters:");
							log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_2.append(" | ");
							log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_2 - " + (log4jParamters_tMap_2));
						}
					}
					new BytesLimit65535_tMap_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_2", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_row13_tMap_2 = 0;

// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_2__Struct {
				}
				Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfout1_tMap_2 = 0;

				copyOfout1Struct copyOfout1_tmp = new copyOfout1Struct();
				int count_copyOfout4_0_tMap_2 = 0;

				copyOfout4_0Struct copyOfout4_0_tmp = new copyOfout4_0Struct();
// ###############################

				/**
				 * [tMap_2 begin ] stop
				 */

				/**
				 * [tLogRow_2 begin ] start
				 */

				ok_Hash.put("tLogRow_2", false);
				start_Hash.put("tLogRow_2", System.currentTimeMillis());

				currentComponent = "tLogRow_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row11");

				int tos_count_tLogRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
							log4jParamters_tLogRow_2.append("Parameters:");
							log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_2 - " + (log4jParamters_tLogRow_2));
						}
					}
					new BytesLimit65535_tLogRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_2", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_2 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[47];

					public void addRow(String[] row) {

						for (int i = 0; i < 47; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 46 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 46 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|%11$-");
							sbformat.append(colLengths[10]);
							sbformat.append("s");

							sbformat.append("|%12$-");
							sbformat.append(colLengths[11]);
							sbformat.append("s");

							sbformat.append("|%13$-");
							sbformat.append(colLengths[12]);
							sbformat.append("s");

							sbformat.append("|%14$-");
							sbformat.append(colLengths[13]);
							sbformat.append("s");

							sbformat.append("|%15$-");
							sbformat.append(colLengths[14]);
							sbformat.append("s");

							sbformat.append("|%16$-");
							sbformat.append(colLengths[15]);
							sbformat.append("s");

							sbformat.append("|%17$-");
							sbformat.append(colLengths[16]);
							sbformat.append("s");

							sbformat.append("|%18$-");
							sbformat.append(colLengths[17]);
							sbformat.append("s");

							sbformat.append("|%19$-");
							sbformat.append(colLengths[18]);
							sbformat.append("s");

							sbformat.append("|%20$-");
							sbformat.append(colLengths[19]);
							sbformat.append("s");

							sbformat.append("|%21$-");
							sbformat.append(colLengths[20]);
							sbformat.append("s");

							sbformat.append("|%22$-");
							sbformat.append(colLengths[21]);
							sbformat.append("s");

							sbformat.append("|%23$-");
							sbformat.append(colLengths[22]);
							sbformat.append("s");

							sbformat.append("|%24$-");
							sbformat.append(colLengths[23]);
							sbformat.append("s");

							sbformat.append("|%25$-");
							sbformat.append(colLengths[24]);
							sbformat.append("s");

							sbformat.append("|%26$-");
							sbformat.append(colLengths[25]);
							sbformat.append("s");

							sbformat.append("|%27$-");
							sbformat.append(colLengths[26]);
							sbformat.append("s");

							sbformat.append("|%28$-");
							sbformat.append(colLengths[27]);
							sbformat.append("s");

							sbformat.append("|%29$-");
							sbformat.append(colLengths[28]);
							sbformat.append("s");

							sbformat.append("|%30$-");
							sbformat.append(colLengths[29]);
							sbformat.append("s");

							sbformat.append("|%31$-");
							sbformat.append(colLengths[30]);
							sbformat.append("s");

							sbformat.append("|%32$-");
							sbformat.append(colLengths[31]);
							sbformat.append("s");

							sbformat.append("|%33$-");
							sbformat.append(colLengths[32]);
							sbformat.append("s");

							sbformat.append("|%34$-");
							sbformat.append(colLengths[33]);
							sbformat.append("s");

							sbformat.append("|%35$-");
							sbformat.append(colLengths[34]);
							sbformat.append("s");

							sbformat.append("|%36$-");
							sbformat.append(colLengths[35]);
							sbformat.append("s");

							sbformat.append("|%37$-");
							sbformat.append(colLengths[36]);
							sbformat.append("s");

							sbformat.append("|%38$-");
							sbformat.append(colLengths[37]);
							sbformat.append("s");

							sbformat.append("|%39$-");
							sbformat.append(colLengths[38]);
							sbformat.append("s");

							sbformat.append("|%40$-");
							sbformat.append(colLengths[39]);
							sbformat.append("s");

							sbformat.append("|%41$-");
							sbformat.append(colLengths[40]);
							sbformat.append("s");

							sbformat.append("|%42$-");
							sbformat.append(colLengths[41]);
							sbformat.append("s");

							sbformat.append("|%43$-");
							sbformat.append(colLengths[42]);
							sbformat.append("s");

							sbformat.append("|%44$-");
							sbformat.append(colLengths[43]);
							sbformat.append("s");

							sbformat.append("|%45$-");
							sbformat.append(colLengths[44]);
							sbformat.append("s");

							sbformat.append("|%46$-");
							sbformat.append(colLengths[45]);
							sbformat.append("s");

							sbformat.append("|%47$-");
							sbformat.append(colLengths[46]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[11] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[12] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[13] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[14] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[15] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[16] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[17] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[18] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[19] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[20] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[21] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[22] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[23] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[24] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[25] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[26] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[27] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[28] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[29] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[30] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[31] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[32] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[33] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[34] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[35] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[36] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[37] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[38] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[39] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[40] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[41] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[42] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[43] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[44] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[45] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[46] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
				util_tLogRow_2.setTableName("tLogRow_2");
				util_tLogRow_2.addRow(new String[] { "resultId", "raceId", "driverId", "constructorId", "number",
						"grid", "position", "positionText", "positionOrder", "points", "laps", "time", "milliseconds",
						"fastestLap", "rank", "fastestLapTime", "fastestLapSpeed", "statusId", "FastLapandTime",
						"raceName", "year", "round", "date", "time_race", "url_race", "circuitId", "circuitRef",
						"circuitName", "location", "country", "lat", "lng", "alt", "url_circuit", "driverRef",
						"number_driver", "code", "forename", "surname", "dob", "nationality", "url", "GID", "GRP_SIZE",
						"MASTER", "SCORE", "GRP_QUALITY", });
				StringBuilder strBuffer_tLogRow_2 = null;
				int nb_line_tLogRow_2 = 0;
///////////////////////    			

				/**
				 * [tLogRow_2 begin ] stop
				 */

				/**
				 * [tSortRow_1_SortIn begin ] start
				 */

				ok_Hash.put("tSortRow_1_SortIn", false);
				start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				int tos_count_tSortRow_1_SortIn = 0;

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortIn - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tSortRow_1_SortIn {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tSortRow_1_SortIn = new StringBuilder();
							log4jParamters_tSortRow_1_SortIn.append("Parameters:");
							log4jParamters_tSortRow_1_SortIn.append("ORIGIN" + " = " + "tSortRow_1");
							log4jParamters_tSortRow_1_SortIn.append(" | ");
							log4jParamters_tSortRow_1_SortIn.append("EXTERNAL" + " = " + "false");
							log4jParamters_tSortRow_1_SortIn.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tSortRow_1_SortIn - " + (log4jParamters_tSortRow_1_SortIn));
						}
					}
					new BytesLimit65535_tSortRow_1_SortIn().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tSortRow_1_SortIn", "tSortIn");
					talendJobLogProcess(globalMap);
				}

				row4Struct[] array_tSortRow_1_SortIn = (row4Struct[]) globalMap.remove("tSortRow_1");

				int nb_line_tSortRow_1_SortIn = 0;

				row4Struct current_tSortRow_1_SortIn = null;

				for (int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++) {
					current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
					row11.resultId = current_tSortRow_1_SortIn.resultId;
					row11.raceId = current_tSortRow_1_SortIn.raceId;
					row11.driverId = current_tSortRow_1_SortIn.driverId;
					row11.constructorId = current_tSortRow_1_SortIn.constructorId;
					row11.number = current_tSortRow_1_SortIn.number;
					row11.grid = current_tSortRow_1_SortIn.grid;
					row11.position = current_tSortRow_1_SortIn.position;
					row11.positionText = current_tSortRow_1_SortIn.positionText;
					row11.positionOrder = current_tSortRow_1_SortIn.positionOrder;
					row11.points = current_tSortRow_1_SortIn.points;
					row11.laps = current_tSortRow_1_SortIn.laps;
					row11.time = current_tSortRow_1_SortIn.time;
					row11.milliseconds = current_tSortRow_1_SortIn.milliseconds;
					row11.fastestLap = current_tSortRow_1_SortIn.fastestLap;
					row11.rank = current_tSortRow_1_SortIn.rank;
					row11.fastestLapTime = current_tSortRow_1_SortIn.fastestLapTime;
					row11.fastestLapSpeed = current_tSortRow_1_SortIn.fastestLapSpeed;
					row11.statusId = current_tSortRow_1_SortIn.statusId;
					row11.FastLapandTime = current_tSortRow_1_SortIn.FastLapandTime;
					row11.raceName = current_tSortRow_1_SortIn.raceName;
					row11.year = current_tSortRow_1_SortIn.year;
					row11.round = current_tSortRow_1_SortIn.round;
					row11.date = current_tSortRow_1_SortIn.date;
					row11.time_race = current_tSortRow_1_SortIn.time_race;
					row11.url_race = current_tSortRow_1_SortIn.url_race;
					row11.circuitId = current_tSortRow_1_SortIn.circuitId;
					row11.circuitRef = current_tSortRow_1_SortIn.circuitRef;
					row11.circuitName = current_tSortRow_1_SortIn.circuitName;
					row11.location = current_tSortRow_1_SortIn.location;
					row11.country = current_tSortRow_1_SortIn.country;
					row11.lat = current_tSortRow_1_SortIn.lat;
					row11.lng = current_tSortRow_1_SortIn.lng;
					row11.alt = current_tSortRow_1_SortIn.alt;
					row11.url_circuit = current_tSortRow_1_SortIn.url_circuit;
					row11.driverRef = current_tSortRow_1_SortIn.driverRef;
					row11.number_driver = current_tSortRow_1_SortIn.number_driver;
					row11.code = current_tSortRow_1_SortIn.code;
					row11.forename = current_tSortRow_1_SortIn.forename;
					row11.surname = current_tSortRow_1_SortIn.surname;
					row11.dob = current_tSortRow_1_SortIn.dob;
					row11.nationality = current_tSortRow_1_SortIn.nationality;
					row11.url = current_tSortRow_1_SortIn.url;
					row11.GID = current_tSortRow_1_SortIn.GID;
					row11.GRP_SIZE = current_tSortRow_1_SortIn.GRP_SIZE;
					row11.MASTER = current_tSortRow_1_SortIn.MASTER;
					row11.SCORE = current_tSortRow_1_SortIn.SCORE;
					row11.GRP_QUALITY = current_tSortRow_1_SortIn.GRP_QUALITY;
					// increase number of line sorted
					nb_line_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn begin ] stop
					 */

					/**
					 * [tSortRow_1_SortIn main ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					tos_count_tSortRow_1_SortIn++;

					/**
					 * [tSortRow_1_SortIn main ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_begin ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_begin ] stop
					 */

					/**
					 * [tLogRow_2 main ] start
					 */

					currentComponent = "tLogRow_2";

					runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row11");

					if (log.isTraceEnabled()) {
						log.trace("row11 - " + (row11 == null ? "" : row11.toLogString()));
					}

///////////////////////		

					String[] row_tLogRow_2 = new String[47];

					row_tLogRow_2[0] = String.valueOf(row11.resultId);

					row_tLogRow_2[1] = String.valueOf(row11.raceId);

					row_tLogRow_2[2] = String.valueOf(row11.driverId);

					row_tLogRow_2[3] = String.valueOf(row11.constructorId);

					row_tLogRow_2[4] = String.valueOf(row11.number);

					row_tLogRow_2[5] = String.valueOf(row11.grid);

					row_tLogRow_2[6] = String.valueOf(row11.position);

					if (row11.positionText != null) { //
						row_tLogRow_2[7] = String.valueOf(row11.positionText);

					} //

					if (row11.positionOrder != null) { //
						row_tLogRow_2[8] = String.valueOf(row11.positionOrder);

					} //

					if (row11.points != null) { //
						row_tLogRow_2[9] = String.valueOf(row11.points);

					} //

					if (row11.laps != null) { //
						row_tLogRow_2[10] = String.valueOf(row11.laps);

					} //

					if (row11.time != null) { //
						row_tLogRow_2[11] = String.valueOf(row11.time);

					} //

					if (row11.milliseconds != null) { //
						row_tLogRow_2[12] = String.valueOf(row11.milliseconds);

					} //

					if (row11.fastestLap != null) { //
						row_tLogRow_2[13] = String.valueOf(row11.fastestLap);

					} //

					if (row11.rank != null) { //
						row_tLogRow_2[14] = String.valueOf(row11.rank);

					} //

					if (row11.fastestLapTime != null) { //
						row_tLogRow_2[15] = String.valueOf(row11.fastestLapTime);

					} //

					if (row11.fastestLapSpeed != null) { //
						row_tLogRow_2[16] = String.valueOf(row11.fastestLapSpeed);

					} //

					row_tLogRow_2[17] = String.valueOf(row11.statusId);

					if (row11.FastLapandTime != null) { //
						row_tLogRow_2[18] = String.valueOf(row11.FastLapandTime);

					} //

					if (row11.raceName != null) { //
						row_tLogRow_2[19] = String.valueOf(row11.raceName);

					} //

					row_tLogRow_2[20] = String.valueOf(row11.year);

					row_tLogRow_2[21] = String.valueOf(row11.round);

					if (row11.date != null) { //
						row_tLogRow_2[22] = String.valueOf(row11.date);

					} //

					if (row11.time_race != null) { //
						row_tLogRow_2[23] = String.valueOf(row11.time_race);

					} //

					if (row11.url_race != null) { //
						row_tLogRow_2[24] = String.valueOf(row11.url_race);

					} //

					row_tLogRow_2[25] = String.valueOf(row11.circuitId);

					if (row11.circuitRef != null) { //
						row_tLogRow_2[26] = String.valueOf(row11.circuitRef);

					} //

					if (row11.circuitName != null) { //
						row_tLogRow_2[27] = String.valueOf(row11.circuitName);

					} //

					if (row11.location != null) { //
						row_tLogRow_2[28] = String.valueOf(row11.location);

					} //

					if (row11.country != null) { //
						row_tLogRow_2[29] = String.valueOf(row11.country);

					} //

					if (row11.lat != null) { //
						row_tLogRow_2[30] = String.valueOf(row11.lat);

					} //

					if (row11.lng != null) { //
						row_tLogRow_2[31] = String.valueOf(row11.lng);

					} //

					if (row11.alt != null) { //
						row_tLogRow_2[32] = String.valueOf(row11.alt);

					} //

					if (row11.url_circuit != null) { //
						row_tLogRow_2[33] = String.valueOf(row11.url_circuit);

					} //

					if (row11.driverRef != null) { //
						row_tLogRow_2[34] = String.valueOf(row11.driverRef);

					} //

					if (row11.number_driver != null) { //
						row_tLogRow_2[35] = String.valueOf(row11.number_driver);

					} //

					if (row11.code != null) { //
						row_tLogRow_2[36] = String.valueOf(row11.code);

					} //

					if (row11.forename != null) { //
						row_tLogRow_2[37] = String.valueOf(row11.forename);

					} //

					if (row11.surname != null) { //
						row_tLogRow_2[38] = String.valueOf(row11.surname);

					} //

					if (row11.dob != null) { //
						row_tLogRow_2[39] = String.valueOf(row11.dob);

					} //

					if (row11.nationality != null) { //
						row_tLogRow_2[40] = String.valueOf(row11.nationality);

					} //

					if (row11.url != null) { //
						row_tLogRow_2[41] = String.valueOf(row11.url);

					} //

					if (row11.GID != null) { //
						row_tLogRow_2[42] = String.valueOf(row11.GID);

					} //

					if (row11.GRP_SIZE != null) { //
						row_tLogRow_2[43] = String.valueOf(row11.GRP_SIZE);

					} //

					if (row11.MASTER != null) { //
						row_tLogRow_2[44] = String.valueOf(row11.MASTER);

					} //

					if (row11.SCORE != null) { //
						row_tLogRow_2[45] = FormatterUtils.formatUnwithE(row11.SCORE);

					} //

					if (row11.GRP_QUALITY != null) { //
						row_tLogRow_2[46] = FormatterUtils.formatUnwithE(row11.GRP_QUALITY);

					} //

					util_tLogRow_2.addRow(row_tLogRow_2);
					nb_line_tLogRow_2++;
					log.info("tLogRow_2 - Content of row " + nb_line_tLogRow_2 + ": "
							+ TalendString.unionString("|", row_tLogRow_2));
//////

//////                    

///////////////////////    			

					row13 = row11;

					tos_count_tLogRow_2++;

					/**
					 * [tLogRow_2 main ] stop
					 */

					/**
					 * [tLogRow_2 process_data_begin ] start
					 */

					currentComponent = "tLogRow_2";

					/**
					 * [tLogRow_2 process_data_begin ] stop
					 */

					/**
					 * [tMap_2 main ] start
					 */

					currentComponent = "tMap_2";

					runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row13");

					if (log.isTraceEnabled()) {
						log.trace("row13 - " + (row13 == null ? "" : row13.toLogString()));
					}

					boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;

					// ###############################
					// # Input tables (lookups)
					boolean rejectedInnerJoin_tMap_2 = false;
					boolean mainRowRejected_tMap_2 = false;

					// ###############################
					{ // start of Var scope

						// ###############################
						// # Vars tables

						Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
						// ###############################
						// # Output tables

						copyOfout1 = null;
						copyOfout4_0 = null;

// # Output table : 'copyOfout1'
						count_copyOfout1_tMap_2++;

						copyOfout1_tmp.Id_Result = row13.resultId;
						copyOfout1_tmp.Id_Driver = row13.driverId;
						copyOfout1_tmp.Id_Constructor = row13.constructorId;
						copyOfout1_tmp.Id_Race = row13.raceId;
						copyOfout1_tmp.Id_circuit = row13.circuitId;
						copyOfout1_tmp.Id_Status = row13.statusId;
						copyOfout1_tmp.DriverRef = row13.driverRef;
						copyOfout1_tmp.DriverNumber = row13.number_driver;
						copyOfout1_tmp.Code = row13.code;
						copyOfout1_tmp.Forename = row13.forename;
						copyOfout1_tmp.Surname = row13.surname;
						copyOfout1_tmp.Dob = row13.dob;
						copyOfout1_tmp.Nationality = row13.nationality;
						copyOfout1_tmp.Number = row13.number;
						copyOfout1_tmp.Grid = row13.grid;
						copyOfout1_tmp.Position = row13.position;
						copyOfout1_tmp.PositionText = row13.positionText;
						copyOfout1_tmp.PositionOrder = row13.positionOrder;
						copyOfout1_tmp.Points = row13.points;
						copyOfout1_tmp.Laps = row13.laps;
						copyOfout1_tmp.Time = row13.time;
						copyOfout1_tmp.Milliseconds = row13.milliseconds;
						copyOfout1_tmp.FastestLap = row13.fastestLap;
						copyOfout1_tmp.Rank = row13.rank;
						copyOfout1_tmp.FastestLapTime = row13.fastestLapTime;
						copyOfout1_tmp.FastestLapSpeed = row13.fastestLapSpeed;
						copyOfout1_tmp.FastLapandTime = row13.FastLapandTime;
						copyOfout1_tmp.RaceName = row13.raceName;
						copyOfout1_tmp.RaceYear = row13.year;
						copyOfout1_tmp.Round = row13.round;
						copyOfout1_tmp.RaceDate = row13.date;
						copyOfout1_tmp.RaceTime = row13.time_race;
						copyOfout1_tmp.CircuitRef = row13.circuitRef;
						copyOfout1_tmp.CircuitName = row13.circuitName;
						copyOfout1_tmp.CircuitLocation = row13.location;
						copyOfout1_tmp.CircuitCountry = row13.country;
						copyOfout1_tmp.Lat = row13.lat;
						copyOfout1_tmp.Lng = row13.lng;
						copyOfout1_tmp.Alt = row13.alt;
						copyOfout1 = copyOfout1_tmp;
						log.debug("tMap_2 - Outputting the record " + count_copyOfout1_tMap_2
								+ " of the output table 'copyOfout1'.");

// # Output table : 'copyOfout4_0'
						count_copyOfout4_0_tMap_2++;

						copyOfout4_0_tmp.Id_Result = row13.resultId;
						copyOfout4_0_tmp.Id_Driver = row13.driverId;
						copyOfout4_0_tmp.Id_Constructor = row13.constructorId;
						copyOfout4_0_tmp.Id_Race = row13.raceId;
						copyOfout4_0_tmp.Id_circuit = row13.circuitId;
						copyOfout4_0_tmp.Id_Status = row13.statusId;
						copyOfout4_0_tmp.DriverRef = row13.driverRef;
						copyOfout4_0_tmp.DriverNumber = row13.number_driver;
						copyOfout4_0_tmp.Code = row13.code;
						copyOfout4_0_tmp.Forename = row13.forename;
						copyOfout4_0_tmp.Surname = row13.surname;
						copyOfout4_0_tmp.Dob = row13.dob;
						copyOfout4_0_tmp.Nationality = row13.nationality;
						copyOfout4_0_tmp.Number = row13.number;
						copyOfout4_0_tmp.Grid = row13.grid;
						copyOfout4_0_tmp.Position = row13.position;
						copyOfout4_0_tmp.PositionText = row13.positionText;
						copyOfout4_0_tmp.PositionOrder = row13.positionOrder;
						copyOfout4_0_tmp.Points = row13.points;
						copyOfout4_0_tmp.Laps = row13.laps;
						copyOfout4_0_tmp.Time = row13.time;
						copyOfout4_0_tmp.Milliseconds = row13.milliseconds;
						copyOfout4_0_tmp.FastestLap = row13.fastestLap;
						copyOfout4_0_tmp.Rank = row13.rank;
						copyOfout4_0_tmp.FastestLapTime = row13.fastestLapTime;
						copyOfout4_0_tmp.FastestLapSpeed = row13.fastestLapSpeed;
						copyOfout4_0_tmp.FastLapandTime = row13.FastLapandTime;
						copyOfout4_0_tmp.RaceName = row13.raceName;
						copyOfout4_0_tmp.RaceYear = row13.year;
						copyOfout4_0_tmp.Round = row13.round;
						copyOfout4_0_tmp.RaceDate = row13.date;
						copyOfout4_0_tmp.RaceTime = row13.time_race;
						copyOfout4_0_tmp.CircuitRef = row13.circuitRef;
						copyOfout4_0_tmp.CircuitName = row13.circuitName;
						copyOfout4_0_tmp.CircuitLocation = row13.location;
						copyOfout4_0_tmp.CircuitCountry = row13.country;
						copyOfout4_0_tmp.Lat = row13.lat;
						copyOfout4_0_tmp.Lng = row13.lng;
						copyOfout4_0_tmp.Alt = row13.alt;
						copyOfout4_0 = copyOfout4_0_tmp;
						log.debug("tMap_2 - Outputting the record " + count_copyOfout4_0_tMap_2
								+ " of the output table 'copyOfout4_0'.");

// ###############################

					} // end of Var scope

					rejectedInnerJoin_tMap_2 = false;

					tos_count_tMap_2++;

					/**
					 * [tMap_2 main ] stop
					 */

					/**
					 * [tMap_2 process_data_begin ] start
					 */

					currentComponent = "tMap_2";

					/**
					 * [tMap_2 process_data_begin ] stop
					 */
// Start of branch "copyOfout1"
					if (copyOfout1 != null) {

						/**
						 * [tLogRow_4 main ] start
						 */

						currentComponent = "tLogRow_4";

						runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "copyOfout1");

						if (log.isTraceEnabled()) {
							log.trace("copyOfout1 - " + (copyOfout1 == null ? "" : copyOfout1.toLogString()));
						}

///////////////////////		

						String[] row_tLogRow_4 = new String[39];

						row_tLogRow_4[0] = String.valueOf(copyOfout1.Id_Result);

						row_tLogRow_4[1] = String.valueOf(copyOfout1.Id_Driver);

						row_tLogRow_4[2] = String.valueOf(copyOfout1.Id_Constructor);

						row_tLogRow_4[3] = String.valueOf(copyOfout1.Id_Race);

						row_tLogRow_4[4] = String.valueOf(copyOfout1.Id_circuit);

						row_tLogRow_4[5] = String.valueOf(copyOfout1.Id_Status);

						if (copyOfout1.DriverRef != null) { //
							row_tLogRow_4[6] = String.valueOf(copyOfout1.DriverRef);

						} //

						if (copyOfout1.DriverNumber != null) { //
							row_tLogRow_4[7] = String.valueOf(copyOfout1.DriverNumber);

						} //

						if (copyOfout1.Code != null) { //
							row_tLogRow_4[8] = String.valueOf(copyOfout1.Code);

						} //

						if (copyOfout1.Forename != null) { //
							row_tLogRow_4[9] = String.valueOf(copyOfout1.Forename);

						} //

						if (copyOfout1.Surname != null) { //
							row_tLogRow_4[10] = String.valueOf(copyOfout1.Surname);

						} //

						if (copyOfout1.Dob != null) { //
							row_tLogRow_4[11] = String.valueOf(copyOfout1.Dob);

						} //

						if (copyOfout1.Nationality != null) { //
							row_tLogRow_4[12] = String.valueOf(copyOfout1.Nationality);

						} //

						row_tLogRow_4[13] = String.valueOf(copyOfout1.Number);

						row_tLogRow_4[14] = String.valueOf(copyOfout1.Grid);

						row_tLogRow_4[15] = String.valueOf(copyOfout1.Position);

						if (copyOfout1.PositionText != null) { //
							row_tLogRow_4[16] = String.valueOf(copyOfout1.PositionText);

						} //

						if (copyOfout1.PositionOrder != null) { //
							row_tLogRow_4[17] = String.valueOf(copyOfout1.PositionOrder);

						} //

						if (copyOfout1.Points != null) { //
							row_tLogRow_4[18] = String.valueOf(copyOfout1.Points);

						} //

						if (copyOfout1.Laps != null) { //
							row_tLogRow_4[19] = String.valueOf(copyOfout1.Laps);

						} //

						if (copyOfout1.Time != null) { //
							row_tLogRow_4[20] = String.valueOf(copyOfout1.Time);

						} //

						if (copyOfout1.Milliseconds != null) { //
							row_tLogRow_4[21] = String.valueOf(copyOfout1.Milliseconds);

						} //

						if (copyOfout1.FastestLap != null) { //
							row_tLogRow_4[22] = String.valueOf(copyOfout1.FastestLap);

						} //

						if (copyOfout1.Rank != null) { //
							row_tLogRow_4[23] = String.valueOf(copyOfout1.Rank);

						} //

						if (copyOfout1.FastestLapTime != null) { //
							row_tLogRow_4[24] = String.valueOf(copyOfout1.FastestLapTime);

						} //

						if (copyOfout1.FastestLapSpeed != null) { //
							row_tLogRow_4[25] = String.valueOf(copyOfout1.FastestLapSpeed);

						} //

						if (copyOfout1.FastLapandTime != null) { //
							row_tLogRow_4[26] = String.valueOf(copyOfout1.FastLapandTime);

						} //

						if (copyOfout1.RaceName != null) { //
							row_tLogRow_4[27] = String.valueOf(copyOfout1.RaceName);

						} //

						row_tLogRow_4[28] = String.valueOf(copyOfout1.RaceYear);

						row_tLogRow_4[29] = String.valueOf(copyOfout1.Round);

						if (copyOfout1.RaceDate != null) { //
							row_tLogRow_4[30] = String.valueOf(copyOfout1.RaceDate);

						} //

						if (copyOfout1.RaceTime != null) { //
							row_tLogRow_4[31] = String.valueOf(copyOfout1.RaceTime);

						} //

						if (copyOfout1.CircuitRef != null) { //
							row_tLogRow_4[32] = String.valueOf(copyOfout1.CircuitRef);

						} //

						if (copyOfout1.CircuitName != null) { //
							row_tLogRow_4[33] = String.valueOf(copyOfout1.CircuitName);

						} //

						if (copyOfout1.CircuitLocation != null) { //
							row_tLogRow_4[34] = String.valueOf(copyOfout1.CircuitLocation);

						} //

						if (copyOfout1.CircuitCountry != null) { //
							row_tLogRow_4[35] = String.valueOf(copyOfout1.CircuitCountry);

						} //

						if (copyOfout1.Lat != null) { //
							row_tLogRow_4[36] = String.valueOf(copyOfout1.Lat);

						} //

						if (copyOfout1.Lng != null) { //
							row_tLogRow_4[37] = String.valueOf(copyOfout1.Lng);

						} //

						if (copyOfout1.Alt != null) { //
							row_tLogRow_4[38] = String.valueOf(copyOfout1.Alt);

						} //

						util_tLogRow_4.addRow(row_tLogRow_4);
						nb_line_tLogRow_4++;
						log.info("tLogRow_4 - Content of row " + nb_line_tLogRow_4 + ": "
								+ TalendString.unionString("|", row_tLogRow_4));
//////

//////                    

///////////////////////    			

						row12_0 = copyOfout1;

						tos_count_tLogRow_4++;

						/**
						 * [tLogRow_4 main ] stop
						 */

						/**
						 * [tLogRow_4 process_data_begin ] start
						 */

						currentComponent = "tLogRow_4";

						/**
						 * [tLogRow_4 process_data_begin ] stop
						 */

						/**
						 * [tFileOutputDelimited_1 main ] start
						 */

						currentComponent = "tFileOutputDelimited_1";

						runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row12_0");

						if (log.isTraceEnabled()) {
							log.trace("row12_0 - " + (row12_0 == null ? "" : row12_0.toLogString()));
						}

						StringBuilder sb_tFileOutputDelimited_1 = new StringBuilder();
						sb_tFileOutputDelimited_1.append(row12_0.Id_Result);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Id_Driver);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Id_Constructor);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Id_Race);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Id_circuit);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Id_Status);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.DriverRef != null) {
							sb_tFileOutputDelimited_1.append(row12_0.DriverRef);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.DriverNumber != null) {
							sb_tFileOutputDelimited_1.append(row12_0.DriverNumber);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Code != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Code);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Forename != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Forename);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Surname != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Surname);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Dob != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Dob);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Nationality != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Nationality);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Number);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Grid);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Position);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.PositionText != null) {
							sb_tFileOutputDelimited_1.append(row12_0.PositionText);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.PositionOrder != null) {
							sb_tFileOutputDelimited_1.append(row12_0.PositionOrder);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Points != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Points);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Laps != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Laps);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Time != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Time);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Milliseconds != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Milliseconds);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.FastestLap != null) {
							sb_tFileOutputDelimited_1.append(row12_0.FastestLap);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Rank != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Rank);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.FastestLapTime != null) {
							sb_tFileOutputDelimited_1.append(row12_0.FastestLapTime);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.FastestLapSpeed != null) {
							sb_tFileOutputDelimited_1.append(row12_0.FastestLapSpeed);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.FastLapandTime != null) {
							sb_tFileOutputDelimited_1.append(row12_0.FastLapandTime);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.RaceName != null) {
							sb_tFileOutputDelimited_1.append(row12_0.RaceName);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.RaceYear);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						sb_tFileOutputDelimited_1.append(row12_0.Round);
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.RaceDate != null) {
							sb_tFileOutputDelimited_1.append(row12_0.RaceDate);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.RaceTime != null) {
							sb_tFileOutputDelimited_1.append(row12_0.RaceTime);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.CircuitRef != null) {
							sb_tFileOutputDelimited_1.append(row12_0.CircuitRef);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.CircuitName != null) {
							sb_tFileOutputDelimited_1.append(row12_0.CircuitName);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.CircuitLocation != null) {
							sb_tFileOutputDelimited_1.append(row12_0.CircuitLocation);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.CircuitCountry != null) {
							sb_tFileOutputDelimited_1.append(row12_0.CircuitCountry);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Lat != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Lat);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Lng != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Lng);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_tFileOutputDelimited_1);
						if (row12_0.Alt != null) {
							sb_tFileOutputDelimited_1.append(row12_0.Alt);
						}
						sb_tFileOutputDelimited_1.append(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);

						nb_line_tFileOutputDelimited_1++;
						resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

						outtFileOutputDelimited_1.write(sb_tFileOutputDelimited_1.toString());
						log.debug(
								"tFileOutputDelimited_1 - Writing the record " + nb_line_tFileOutputDelimited_1 + ".");

						tos_count_tFileOutputDelimited_1++;

						/**
						 * [tFileOutputDelimited_1 main ] stop
						 */

						/**
						 * [tFileOutputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileOutputDelimited_1";

						/**
						 * [tFileOutputDelimited_1 process_data_begin ] stop
						 */

						/**
						 * [tFileOutputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileOutputDelimited_1";

						/**
						 * [tFileOutputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tLogRow_4 process_data_end ] start
						 */

						currentComponent = "tLogRow_4";

						/**
						 * [tLogRow_4 process_data_end ] stop
						 */

					} // End of branch "copyOfout1"

// Start of branch "copyOfout4_0"
					if (copyOfout4_0 != null) {

						/**
						 * [tLogRow_3 main ] start
						 */

						currentComponent = "tLogRow_3";

						runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "copyOfout4_0");

						if (log.isTraceEnabled()) {
							log.trace("copyOfout4_0 - " + (copyOfout4_0 == null ? "" : copyOfout4_0.toLogString()));
						}

///////////////////////		

						String[] row_tLogRow_3 = new String[39];

						row_tLogRow_3[0] = String.valueOf(copyOfout4_0.Id_Result);

						row_tLogRow_3[1] = String.valueOf(copyOfout4_0.Id_Driver);

						row_tLogRow_3[2] = String.valueOf(copyOfout4_0.Id_Constructor);

						row_tLogRow_3[3] = String.valueOf(copyOfout4_0.Id_Race);

						row_tLogRow_3[4] = String.valueOf(copyOfout4_0.Id_circuit);

						row_tLogRow_3[5] = String.valueOf(copyOfout4_0.Id_Status);

						if (copyOfout4_0.DriverRef != null) { //
							row_tLogRow_3[6] = String.valueOf(copyOfout4_0.DriverRef);

						} //

						if (copyOfout4_0.DriverNumber != null) { //
							row_tLogRow_3[7] = String.valueOf(copyOfout4_0.DriverNumber);

						} //

						if (copyOfout4_0.Code != null) { //
							row_tLogRow_3[8] = String.valueOf(copyOfout4_0.Code);

						} //

						if (copyOfout4_0.Forename != null) { //
							row_tLogRow_3[9] = String.valueOf(copyOfout4_0.Forename);

						} //

						if (copyOfout4_0.Surname != null) { //
							row_tLogRow_3[10] = String.valueOf(copyOfout4_0.Surname);

						} //

						if (copyOfout4_0.Dob != null) { //
							row_tLogRow_3[11] = String.valueOf(copyOfout4_0.Dob);

						} //

						if (copyOfout4_0.Nationality != null) { //
							row_tLogRow_3[12] = String.valueOf(copyOfout4_0.Nationality);

						} //

						row_tLogRow_3[13] = String.valueOf(copyOfout4_0.Number);

						row_tLogRow_3[14] = String.valueOf(copyOfout4_0.Grid);

						row_tLogRow_3[15] = String.valueOf(copyOfout4_0.Position);

						if (copyOfout4_0.PositionText != null) { //
							row_tLogRow_3[16] = String.valueOf(copyOfout4_0.PositionText);

						} //

						if (copyOfout4_0.PositionOrder != null) { //
							row_tLogRow_3[17] = String.valueOf(copyOfout4_0.PositionOrder);

						} //

						if (copyOfout4_0.Points != null) { //
							row_tLogRow_3[18] = String.valueOf(copyOfout4_0.Points);

						} //

						if (copyOfout4_0.Laps != null) { //
							row_tLogRow_3[19] = String.valueOf(copyOfout4_0.Laps);

						} //

						if (copyOfout4_0.Time != null) { //
							row_tLogRow_3[20] = String.valueOf(copyOfout4_0.Time);

						} //

						if (copyOfout4_0.Milliseconds != null) { //
							row_tLogRow_3[21] = String.valueOf(copyOfout4_0.Milliseconds);

						} //

						if (copyOfout4_0.FastestLap != null) { //
							row_tLogRow_3[22] = String.valueOf(copyOfout4_0.FastestLap);

						} //

						if (copyOfout4_0.Rank != null) { //
							row_tLogRow_3[23] = String.valueOf(copyOfout4_0.Rank);

						} //

						if (copyOfout4_0.FastestLapTime != null) { //
							row_tLogRow_3[24] = String.valueOf(copyOfout4_0.FastestLapTime);

						} //

						if (copyOfout4_0.FastestLapSpeed != null) { //
							row_tLogRow_3[25] = String.valueOf(copyOfout4_0.FastestLapSpeed);

						} //

						if (copyOfout4_0.FastLapandTime != null) { //
							row_tLogRow_3[26] = String.valueOf(copyOfout4_0.FastLapandTime);

						} //

						if (copyOfout4_0.RaceName != null) { //
							row_tLogRow_3[27] = String.valueOf(copyOfout4_0.RaceName);

						} //

						row_tLogRow_3[28] = String.valueOf(copyOfout4_0.RaceYear);

						row_tLogRow_3[29] = String.valueOf(copyOfout4_0.Round);

						if (copyOfout4_0.RaceDate != null) { //
							row_tLogRow_3[30] = String.valueOf(copyOfout4_0.RaceDate);

						} //

						if (copyOfout4_0.RaceTime != null) { //
							row_tLogRow_3[31] = String.valueOf(copyOfout4_0.RaceTime);

						} //

						if (copyOfout4_0.CircuitRef != null) { //
							row_tLogRow_3[32] = String.valueOf(copyOfout4_0.CircuitRef);

						} //

						if (copyOfout4_0.CircuitName != null) { //
							row_tLogRow_3[33] = String.valueOf(copyOfout4_0.CircuitName);

						} //

						if (copyOfout4_0.CircuitLocation != null) { //
							row_tLogRow_3[34] = String.valueOf(copyOfout4_0.CircuitLocation);

						} //

						if (copyOfout4_0.CircuitCountry != null) { //
							row_tLogRow_3[35] = String.valueOf(copyOfout4_0.CircuitCountry);

						} //

						if (copyOfout4_0.Lat != null) { //
							row_tLogRow_3[36] = String.valueOf(copyOfout4_0.Lat);

						} //

						if (copyOfout4_0.Lng != null) { //
							row_tLogRow_3[37] = String.valueOf(copyOfout4_0.Lng);

						} //

						if (copyOfout4_0.Alt != null) { //
							row_tLogRow_3[38] = String.valueOf(copyOfout4_0.Alt);

						} //

						util_tLogRow_3.addRow(row_tLogRow_3);
						nb_line_tLogRow_3++;
						log.info("tLogRow_3 - Content of row " + nb_line_tLogRow_3 + ": "
								+ TalendString.unionString("|", row_tLogRow_3));
//////

//////                    

///////////////////////    			

						row11_0 = copyOfout4_0;

						tos_count_tLogRow_3++;

						/**
						 * [tLogRow_3 main ] stop
						 */

						/**
						 * [tLogRow_3 process_data_begin ] start
						 */

						currentComponent = "tLogRow_3";

						/**
						 * [tLogRow_3 process_data_begin ] stop
						 */

						/**
						 * [tDataStewardshipTaskOutput_1 main ] start
						 */

						currentComponent = "tDataStewardshipTaskOutput_1";

						runStat.updateStatAndLog(execStat, enableLogStash, iterateId, 1, 1, "row11_0");

						if (log.isTraceEnabled()) {
							log.trace("row11_0 - " + (row11_0 == null ? "" : row11_0.toLogString()));
						}

						boolean shouldCreateRuntimeSchemaForIncomingNode = false;
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_Result") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_Result",
									((Object) row11_0.Id_Result).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_Driver") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_Driver",
									((Object) row11_0.Id_Driver).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_Constructor") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_Constructor",
									((Object) row11_0.Id_Constructor).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_Race") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_Race",
									((Object) row11_0.Id_Race).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_circuit") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_circuit",
									((Object) row11_0.Id_circuit).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Id_Status") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Id_Status",
									((Object) row11_0.Id_Status).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("DriverRef") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("DriverRef",
									((Object) row11_0.DriverRef).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("DriverNumber") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("DriverNumber",
									((Object) row11_0.DriverNumber).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Code") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Code",
									((Object) row11_0.Code).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Forename") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Forename",
									((Object) row11_0.Forename).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Surname") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Surname",
									((Object) row11_0.Surname).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Dob") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Dob",
									((Object) row11_0.Dob).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Nationality") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Nationality",
									((Object) row11_0.Nationality).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Number") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Number",
									((Object) row11_0.Number).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Grid") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Grid",
									((Object) row11_0.Grid).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Position") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Position",
									((Object) row11_0.Position).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("PositionText") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("PositionText",
									((Object) row11_0.PositionText).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("PositionOrder") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("PositionOrder",
									((Object) row11_0.PositionOrder).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Points") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Points",
									((Object) row11_0.Points).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Laps") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Laps",
									((Object) row11_0.Laps).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Time") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Time",
									((Object) row11_0.Time).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("Milliseconds") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Milliseconds",
									((Object) row11_0.Milliseconds).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("FastestLap") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("FastestLap",
									((Object) row11_0.FastestLap).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Rank") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Rank",
									((Object) row11_0.Rank).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("FastestLapTime") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("FastestLapTime",
									((Object) row11_0.FastestLapTime).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("FastestLapSpeed") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("FastestLapSpeed",
									((Object) row11_0.FastestLapSpeed).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("FastLapandTime") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("FastLapandTime",
									((Object) row11_0.FastLapandTime).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("RaceName") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("RaceName",
									((Object) row11_0.RaceName).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("RaceYear") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("RaceYear",
									((Object) row11_0.RaceYear).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Round") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Round",
									((Object) row11_0.Round).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("RaceDate") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("RaceDate",
									((Object) row11_0.RaceDate).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("RaceTime") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("RaceTime",
									((Object) row11_0.RaceTime).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("CircuitRef") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("CircuitRef",
									((Object) row11_0.CircuitRef).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("CircuitName") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("CircuitName",
									((Object) row11_0.CircuitName).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("CircuitLocation") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("CircuitLocation",
									((Object) row11_0.CircuitLocation).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema()
								.getField("CircuitCountry") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("CircuitCountry",
									((Object) row11_0.CircuitCountry).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Lat") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Lat",
									((Object) row11_0.Lat).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Lng") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Lng",
									((Object) row11_0.Lng).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getDesignSchema().getField("Alt") == null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.addIncomingNodeField("Alt",
									((Object) row11_0.Alt).getClass().getCanonicalName());
							shouldCreateRuntimeSchemaForIncomingNode = true;
						}
						if (shouldCreateRuntimeSchemaForIncomingNode) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.createRuntimeSchema();
						}
						incomingEnforcer_tDataStewardshipTaskOutput_1.createNewRecord();
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_Result") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_Result", row11_0.Id_Result);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_Driver") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_Driver", row11_0.Id_Driver);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_Constructor") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_Constructor", row11_0.Id_Constructor);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_Race") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_Race", row11_0.Id_Race);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_circuit") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_circuit", row11_0.Id_circuit);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Id_Status") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Id_Status", row11_0.Id_Status);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("DriverRef") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("DriverRef", row11_0.DriverRef);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("DriverNumber") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("DriverNumber", row11_0.DriverNumber);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Code") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Code", row11_0.Code);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Forename") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Forename", row11_0.Forename);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Surname") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Surname", row11_0.Surname);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Dob") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Dob", row11_0.Dob);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Nationality") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Nationality", row11_0.Nationality);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Number") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Number", row11_0.Number);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Grid") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Grid", row11_0.Grid);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Position") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Position", row11_0.Position);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("PositionText") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("PositionText", row11_0.PositionText);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("PositionOrder") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("PositionOrder", row11_0.PositionOrder);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Points") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Points", row11_0.Points);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Laps") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Laps", row11_0.Laps);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Time") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Time", row11_0.Time);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Milliseconds") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Milliseconds", row11_0.Milliseconds);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("FastestLap") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("FastestLap", row11_0.FastestLap);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Rank") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Rank", row11_0.Rank);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("FastestLapTime") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("FastestLapTime", row11_0.FastestLapTime);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("FastestLapSpeed") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("FastestLapSpeed",
									row11_0.FastestLapSpeed);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("FastLapandTime") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("FastLapandTime", row11_0.FastLapandTime);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("RaceName") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("RaceName", row11_0.RaceName);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("RaceYear") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("RaceYear", row11_0.RaceYear);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("Round") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Round", row11_0.Round);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("RaceDate") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("RaceDate", row11_0.RaceDate);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("RaceTime") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("RaceTime", row11_0.RaceTime);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("CircuitRef") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("CircuitRef", row11_0.CircuitRef);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("CircuitName") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("CircuitName", row11_0.CircuitName);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("CircuitLocation") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("CircuitLocation",
									row11_0.CircuitLocation);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema()
								.getField("CircuitCountry") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("CircuitCountry", row11_0.CircuitCountry);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Lat") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Lat", row11_0.Lat);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Lng") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Lng", row11_0.Lng);
						}
						// skip the put action if the input column doesn't appear in component runtime
						// schema
						if (incomingEnforcer_tDataStewardshipTaskOutput_1.getRuntimeSchema().getField("Alt") != null) {
							incomingEnforcer_tDataStewardshipTaskOutput_1.put("Alt", row11_0.Alt);
						}
						org.apache.avro.generic.IndexedRecord data_tDataStewardshipTaskOutput_1 = incomingEnforcer_tDataStewardshipTaskOutput_1
								.getCurrentRecord();

						writer_tDataStewardshipTaskOutput_1.write(data_tDataStewardshipTaskOutput_1);

						nb_line_tDataStewardshipTaskOutput_1++;

						tos_count_tDataStewardshipTaskOutput_1++;

						/**
						 * [tDataStewardshipTaskOutput_1 main ] stop
						 */

						/**
						 * [tDataStewardshipTaskOutput_1 process_data_begin ] start
						 */

						currentComponent = "tDataStewardshipTaskOutput_1";

						/**
						 * [tDataStewardshipTaskOutput_1 process_data_begin ] stop
						 */

						/**
						 * [tDataStewardshipTaskOutput_1 process_data_end ] start
						 */

						currentComponent = "tDataStewardshipTaskOutput_1";

						/**
						 * [tDataStewardshipTaskOutput_1 process_data_end ] stop
						 */

						/**
						 * [tLogRow_3 process_data_end ] start
						 */

						currentComponent = "tLogRow_3";

						/**
						 * [tLogRow_3 process_data_end ] stop
						 */

					} // End of branch "copyOfout4_0"

					/**
					 * [tMap_2 process_data_end ] start
					 */

					currentComponent = "tMap_2";

					/**
					 * [tMap_2 process_data_end ] stop
					 */

					/**
					 * [tLogRow_2 process_data_end ] start
					 */

					currentComponent = "tLogRow_2";

					/**
					 * [tLogRow_2 process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn process_data_end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

					/**
					 * [tSortRow_1_SortIn process_data_end ] stop
					 */

					/**
					 * [tSortRow_1_SortIn end ] start
					 */

					currentVirtualComponent = "tSortRow_1";

					currentComponent = "tSortRow_1_SortIn";

				}

				globalMap.put("tSortRow_1_SortIn_NB_LINE", nb_line_tSortRow_1_SortIn);

				if (log.isDebugEnabled())
					log.debug("tSortRow_1_SortIn - " + ("Done."));

				ok_Hash.put("tSortRow_1_SortIn", true);
				end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());

				/**
				 * [tSortRow_1_SortIn end ] stop
				 */

				/**
				 * [tLogRow_2 end ] start
				 */

				currentComponent = "tLogRow_2";

//////

				java.io.PrintStream consoleOut_tLogRow_2 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_2);
				}

				consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
				consoleOut_tLogRow_2.flush();
//////
				globalMap.put("tLogRow_2_NB_LINE", nb_line_tLogRow_2);
				if (log.isInfoEnabled())
					log.info("tLogRow_2 - " + ("Printed row count: ") + (nb_line_tLogRow_2) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11", 2, 0,
						talendJobLog, "tSortRow_1_SortIn", "tSortIn", "tLogRow_2", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Done."));

				ok_Hash.put("tLogRow_2", true);
				end_Hash.put("tLogRow_2", System.currentTimeMillis());

				/**
				 * [tLogRow_2 end ] stop
				 */

				/**
				 * [tMap_2 end ] start
				 */

				currentComponent = "tMap_2";

// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'copyOfout1': " + count_copyOfout1_tMap_2 + ".");
				log.debug("tMap_2 - Written records count in the table 'copyOfout4_0': " + count_copyOfout4_0_tMap_2
						+ ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row13", 2, 0,
						talendJobLog, "tLogRow_2", "tLogRow", "tMap_2", "tMap", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_2 - " + ("Done."));

				ok_Hash.put("tMap_2", true);
				end_Hash.put("tMap_2", System.currentTimeMillis());

				/**
				 * [tMap_2 end ] stop
				 */

				/**
				 * [tLogRow_4 end ] start
				 */

				currentComponent = "tLogRow_4";

//////

				java.io.PrintStream consoleOut_tLogRow_4 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_4 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_4 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_4);
				}

				consoleOut_tLogRow_4.println(util_tLogRow_4.format().toString());
				consoleOut_tLogRow_4.flush();
//////
				globalMap.put("tLogRow_4_NB_LINE", nb_line_tLogRow_4);
				if (log.isInfoEnabled())
					log.info("tLogRow_4 - " + ("Printed row count: ") + (nb_line_tLogRow_4) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "copyOfout1", 2, 0,
						talendJobLog, "tMap_2", "tMap", "tLogRow_4", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_4 - " + ("Done."));

				ok_Hash.put("tLogRow_4", true);
				end_Hash.put("tLogRow_4", System.currentTimeMillis());

				/**
				 * [tLogRow_4 end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (outtFileOutputDelimited_1 != null) {
					outtFileOutputDelimited_1.flush();
					outtFileOutputDelimited_1.close();
				}

				globalMap.put("tFileOutputDelimited_1_NB_LINE", nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				log.debug("tFileOutputDelimited_1 - Written records count: " + nb_line_tFileOutputDelimited_1 + " .");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row12_0", 2, 0,
						talendJobLog, "tLogRow_4", "tLogRow", "tFileOutputDelimited_1", "tFileOutputDelimited",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFileOutputDelimited_1 - " + ("Done."));

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */

				/**
				 * [tLogRow_3 end ] start
				 */

				currentComponent = "tLogRow_3";

//////

				java.io.PrintStream consoleOut_tLogRow_3 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_3 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_3 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_3);
				}

				consoleOut_tLogRow_3.println(util_tLogRow_3.format().toString());
				consoleOut_tLogRow_3.flush();
//////
				globalMap.put("tLogRow_3_NB_LINE", nb_line_tLogRow_3);
				if (log.isInfoEnabled())
					log.info("tLogRow_3 - " + ("Printed row count: ") + (nb_line_tLogRow_3) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "copyOfout4_0", 2, 0,
						talendJobLog, "tMap_2", "tMap", "tLogRow_3", "tLogRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_3 - " + ("Done."));

				ok_Hash.put("tLogRow_3", true);
				end_Hash.put("tLogRow_3", System.currentTimeMillis());

				/**
				 * [tLogRow_3 end ] stop
				 */

				/**
				 * [tDataStewardshipTaskOutput_1 end ] start
				 */

				currentComponent = "tDataStewardshipTaskOutput_1";

// end of generic

				resourceMap.put("finish_tDataStewardshipTaskOutput_1", Boolean.TRUE);

				org.talend.components.api.component.runtime.Result resultObject_tDataStewardshipTaskOutput_1 = (org.talend.components.api.component.runtime.Result) writer_tDataStewardshipTaskOutput_1
						.close();
				final java.util.Map<String, Object> resultMap_tDataStewardshipTaskOutput_1 = writer_tDataStewardshipTaskOutput_1
						.getWriteOperation().finalize(
								java.util.Arrays.<org.talend.components.api.component.runtime.Result>asList(
										resultObject_tDataStewardshipTaskOutput_1),
								container_tDataStewardshipTaskOutput_1);
				if (resultMap_tDataStewardshipTaskOutput_1 != null) {
					for (java.util.Map.Entry<String, Object> entry_tDataStewardshipTaskOutput_1 : resultMap_tDataStewardshipTaskOutput_1
							.entrySet()) {
						switch (entry_tDataStewardshipTaskOutput_1.getKey()) {
						case org.talend.components.api.component.ComponentDefinition.RETURN_ERROR_MESSAGE:
							container_tDataStewardshipTaskOutput_1.setComponentData("tDataStewardshipTaskOutput_1",
									"ERROR_MESSAGE", entry_tDataStewardshipTaskOutput_1.getValue());
							break;
						case org.talend.components.api.component.ComponentDefinition.RETURN_TOTAL_RECORD_COUNT:
							container_tDataStewardshipTaskOutput_1.setComponentData("tDataStewardshipTaskOutput_1",
									"NB_LINE", entry_tDataStewardshipTaskOutput_1.getValue());
							break;
						case org.talend.components.api.component.ComponentDefinition.RETURN_SUCCESS_RECORD_COUNT:
							container_tDataStewardshipTaskOutput_1.setComponentData("tDataStewardshipTaskOutput_1",
									"NB_SUCCESS", entry_tDataStewardshipTaskOutput_1.getValue());
							break;
						case org.talend.components.api.component.ComponentDefinition.RETURN_REJECT_RECORD_COUNT:
							container_tDataStewardshipTaskOutput_1.setComponentData("tDataStewardshipTaskOutput_1",
									"NB_REJECT", entry_tDataStewardshipTaskOutput_1.getValue());
							break;
						default:
							StringBuilder studio_key_tDataStewardshipTaskOutput_1 = new StringBuilder();
							for (int i_tDataStewardshipTaskOutput_1 = 0; i_tDataStewardshipTaskOutput_1 < entry_tDataStewardshipTaskOutput_1
									.getKey().length(); i_tDataStewardshipTaskOutput_1++) {
								char ch_tDataStewardshipTaskOutput_1 = entry_tDataStewardshipTaskOutput_1.getKey()
										.charAt(i_tDataStewardshipTaskOutput_1);
								if (Character.isUpperCase(ch_tDataStewardshipTaskOutput_1)
										&& i_tDataStewardshipTaskOutput_1 > 0) {
									studio_key_tDataStewardshipTaskOutput_1.append('_');
								}
								studio_key_tDataStewardshipTaskOutput_1.append(ch_tDataStewardshipTaskOutput_1);
							}
							container_tDataStewardshipTaskOutput_1.setComponentData(
									"tDataStewardshipTaskOutput_1", studio_key_tDataStewardshipTaskOutput_1.toString()
											.toUpperCase(java.util.Locale.ENGLISH),
									entry_tDataStewardshipTaskOutput_1.getValue());
							break;
						}
					}
				}

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row11_0", 2, 0,
						talendJobLog, "tLogRow_3", "tLogRow", "tDataStewardshipTaskOutput_1",
						"tDataStewardshipTaskOutput", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tDataStewardshipTaskOutput_1", true);
				end_Hash.put("tDataStewardshipTaskOutput_1", System.currentTimeMillis());

				/**
				 * [tDataStewardshipTaskOutput_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			te.setVirtualComponentName(currentVirtualComponent);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tSortRow_1_SortIn"
			globalMap.remove("tSortRow_1");

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupOut finally ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupOut";

				/**
				 * [tMatchGroup_1_GroupOut finally ] stop
				 */

				/**
				 * [tMatchGroup_1_GroupIn finally ] start
				 */

				currentVirtualComponent = "tMatchGroup_1";

				currentComponent = "tMatchGroup_1_GroupIn";

				/**
				 * [tMatchGroup_1_GroupIn finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				try {
					if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
						java.sql.PreparedStatement pstmtToClose_tDBOutput_1 = null;
						if ((pstmtToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
								.remove("pstmt_tDBOutput_1")) != null) {
							pstmtToClose_tDBOutput_1.close();
						}
					}
				} finally {
					if (resourceMap.get("finish_tDBOutput_1") == null) {
						java.sql.Connection ctn_tDBOutput_1 = null;
						if ((ctn_tDBOutput_1 = (java.sql.Connection) resourceMap.get("conn_tDBOutput_1")) != null) {
							try {
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Closing the connection to the database."));
								ctn_tDBOutput_1.close();
								if (log.isDebugEnabled())
									log.debug("tDBOutput_1 - " + ("Connection to the database has closed."));
							} catch (java.sql.SQLException sqlEx_tDBOutput_1) {
								String errorMessage_tDBOutput_1 = "failed to close the connection in tDBOutput_1 :"
										+ sqlEx_tDBOutput_1.getMessage();
								log.error("tDBOutput_1 - " + (errorMessage_tDBOutput_1));
								System.err.println(errorMessage_tDBOutput_1);
							}
						}
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				/**
				 * [tLogRow_1 finally ] stop
				 */

				/**
				 * [tSortRow_1_SortOut finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortOut";

				/**
				 * [tSortRow_1_SortOut finally ] stop
				 */

				/**
				 * [tSortRow_1_SortIn finally ] start
				 */

				currentVirtualComponent = "tSortRow_1";

				currentComponent = "tSortRow_1_SortIn";

				/**
				 * [tSortRow_1_SortIn finally ] stop
				 */

				/**
				 * [tLogRow_2 finally ] start
				 */

				currentComponent = "tLogRow_2";

				/**
				 * [tLogRow_2 finally ] stop
				 */

				/**
				 * [tMap_2 finally ] start
				 */

				currentComponent = "tMap_2";

				/**
				 * [tMap_2 finally ] stop
				 */

				/**
				 * [tLogRow_4 finally ] start
				 */

				currentComponent = "tLogRow_4";

				/**
				 * [tLogRow_4 finally ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_1");
					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */

				/**
				 * [tLogRow_3 finally ] start
				 */

				currentComponent = "tLogRow_3";

				/**
				 * [tLogRow_3 finally ] stop
				 */

				/**
				 * [tDataStewardshipTaskOutput_1 finally ] start
				 */

				currentComponent = "tDataStewardshipTaskOutput_1";

// finally of generic

				if (resourceMap.get("finish_tDataStewardshipTaskOutput_1") == null) {
					if (resourceMap.get("writer_tDataStewardshipTaskOutput_1") != null) {
						try {
							((org.talend.components.api.component.runtime.Writer) resourceMap
									.get("writer_tDataStewardshipTaskOutput_1")).close();
						} catch (java.io.IOException e_tDataStewardshipTaskOutput_1) {
							String errorMessage_tDataStewardshipTaskOutput_1 = "failed to release the resource in tDataStewardshipTaskOutput_1 :"
									+ e_tDataStewardshipTaskOutput_1.getMessage();
							System.err.println(errorMessage_tDataStewardshipTaskOutput_1);
						}
					}
				}

				/**
				 * [tDataStewardshipTaskOutput_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.logging.audit.Context log_context_talendJobLog = null;
					if (jcm.component_name == null) {// job level log
						if (jcm.status == null) {// job start
							log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create()
									.jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
									.timestamp(jcm.moment).build();
							auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
						} else {// job end
							long timeMS = jcm.end_time - jcm.start_time;
							String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0) / 1000);

							log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create()
									.jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
									.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
							auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
						}
					} else if (jcm.current_connector == null) {// component log
						log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name)
								.jobId(jcm.job_id).jobVersion(jcm.job_version).connectorType(jcm.component_name)
								.connectorId(jcm.component_id).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else {// component connector meter log
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0) / 1000);

						if (jcm.current_connector_as_input) {// log current component input line
							log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create()
									.jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
									.connectorType(jcm.component_name).connectorId(jcm.component_id)
									.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
									.rows(jcm.total_row_number).duration(duration).build();
							auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
						} else {// log current component output/reject line
							log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create()
									.jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
									.connectorType(jcm.component_name).connectorId(jcm.component_id)
									.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
									.rows(jcm.total_row_number).duration(duration).build();
							auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
						}
					}
				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	private PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	private final org.talend.components.common.runtime.SharedConnectionsPool connectionPool = new org.talend.components.common.runtime.SharedConnectionsPool() {
		public java.sql.Connection getDBConnection(String dbDriver, String url, String userName, String password,
				String dbConnectionName) throws ClassNotFoundException, java.sql.SQLException {
			return SharedDBConnection.getDBConnection(dbDriver, url, userName, password, dbConnectionName);
		}

		public java.sql.Connection getDBConnection(String dbDriver, String url, String dbConnectionName)
				throws ClassNotFoundException, java.sql.SQLException {
			return SharedDBConnection.getDBConnection(dbDriver, url, dbConnectionName);
		}
	};

	private static final String GLOBAL_CONNECTION_POOL_KEY = "GLOBAL_CONNECTION_POOL";

	{
		globalMap.put(GLOBAL_CONNECTION_POOL_KEY, connectionPool);
	}

	public static void main(String[] args) {
		final pruebas3 pruebas3Class = new pruebas3();

		int exitCode = pruebas3Class.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'pruebas3' - Done.");
		}

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}
		log.info("TalendJob: 'pruebas3' - Start.");

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream()
					.filter(it -> it.startsWith("monitoring.audit.logger.properties."))
					.forEach(key -> properties_talendJobLog.setProperty(
							key.substring("monitoring.audit.logger.properties.".length()), System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator.setLevel("audit", org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = pruebas3.class.getClassLoader()
					.getResourceAsStream("talend_demo_project/pruebas3_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = pruebas3.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				// defaultProps is in order to keep the original context value
				if (context != null && context.isEmpty()) {
					defaultProps.load(inContext);
					context = new ContextProperties(defaultProps);
				}

				inContext.close();
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBInput_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBInput_1) {
			globalMap.put("tDBInput_1_SUBPROCESS_STATE", -1);

			e_tDBInput_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : pruebas3");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;
		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 688555 characters generated by Talend Real-time Big Data Platform on the 7 de
 * abril de 2021 17:41:26 CEST
 ************************************************************************************************/